package com.capgemini.surveymanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveymanagementsystem.bean.Admin;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this class contains dummy data of admin
 * 
 * @author Admin
 *
 */
public class AdminRepository {


	protected static List<Admin> adminList = new ArrayList<Admin>();

	public List<Admin> getAdminList() {

		Admin adminInfo = Factory.adminInfoInstance();
		adminInfo.setName("vinay reddy");
		adminInfo.setPhoneNumber(8528528528l);
		adminInfo.setMail("vinay20@gmail.com");
		adminInfo.setLoginId("vinay-reddy");
		adminInfo.setPassword("Vinay@123");

		adminList.add(adminInfo);

		return adminList;
	}

}
