package com.capgemini.surveymanagementsystem.bean;

import java.io.Serializable;

public class Respondent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8388782554157256664L;

	public Respondent() {

	}

	private String name;
	private String mail;
	private String loginId;
	private String password;
	private String surveyId1;
	private String surveyId2;
	private long phoneNumber;

	/**
	 * this method is used to get name
	 * 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * this method is used to set name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * this method is used to get mail
	 * 
	 * @return String
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * this method is used to set mail
	 * 
	 * @param mail
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * this method is used to get loginId
	 * 
	 * @return String
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * this method is used to set loginId
	 * 
	 * @param loginId
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	/**
	 * this method is used to get password
	 * 
	 * @return String
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * this method is used to set password
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * this method is used to get surveyId1
	 * 
	 * @return String
	 */
	public String getSurveyId1() {
		return surveyId1;
	}

	/**
	 * this method is used to set surveyId1
	 * 
	 * @param surveyId1
	 */
	public void setSurveyId1(String surveyId1) {
		this.surveyId1 = surveyId1;
	}

	/**
	 * this method is used to get surveyId2
	 * 
	 * @return String
	 */
	public String getSurveyId2() {
		return surveyId2;
	}

	/**
	 * this method is used to set surveyId2
	 * 
	 * @param surveyId2
	 */
	public void setSurveyId2(String surveyId2) {
		this.surveyId2 = surveyId2;
	}

	/**
	 * this method is used to get phoneNumber
	 * 
	 * @return long
	 */
	public long getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * this method is used to set phoneNumber
	 * 
	 * @param phoneNumber
	 */
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "\n" + " ---------------------------------------------------" + "\n 1.name = " + name + "\n"
				+ " 2.phone number = " + phoneNumber + "\n" + " 3.gmail = " + mail + "\n" + " 4.LoginId = " + loginId
				+ "\n" + " 5.Password = " + password + "\n";
	}
	

}
