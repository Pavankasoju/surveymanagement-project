package com.capgemini.surveymanagementsystem.repository;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this class contains dummy data of Distribution surveys
 * 
 * @author Admin
 *
 */
public class SurveyDistributionRepository {

	protected static List<SurveyDistribution> surveyDistributionList = new LinkedList<SurveyDistribution>();

	public List<SurveyDistribution> getSurveyDistributionList() {

		SurveyDistribution surveyDistributionInfo1 = Factory.surveyDistributionInfoInstance();
		SurveyDistribution surveyDistributionInfo2 = Factory.surveyDistributionInfoInstance();
		SurveyDistribution surveyDistributionInfo3 = Factory.surveyDistributionInfoInstance();
		SurveyDistribution surveyDistributionInfo4 = Factory.surveyDistributionInfoInstance();

		surveyDistributionInfo1.setSurveyId("snapdeal555");
		surveyDistributionInfo1.setSurveyName("snapdeal survey");
		surveyDistributionInfo1.setDescription("the survey wants to know about the Website review");
		surveyDistributionInfo1.setFromDate(LocalDate.of(2020, 05, 06));
		surveyDistributionInfo1.setToDate(LocalDate.of(2020, 05, 21));

		surveyDistributionInfo2.setSurveyId("pepperfry555");
		surveyDistributionInfo2.setSurveyName("pepperfry survey");
		surveyDistributionInfo2.setDescription("the survey wants to know about the Website review");
		surveyDistributionInfo2.setFromDate(LocalDate.of(2020, 05, 06));
		surveyDistributionInfo2.setToDate(LocalDate.of(2020, 05, 21));

		surveyDistributionInfo3.setSurveyId("ebay555");
		surveyDistributionInfo3.setSurveyName("ebay survey");
		surveyDistributionInfo3.setDescription("the survey wants to know about the Website review");
		surveyDistributionInfo3.setFromDate(LocalDate.of(2020, 05, 06));
		surveyDistributionInfo3.setToDate(LocalDate.of(2020, 05, 21));

		surveyDistributionInfo4.setSurveyId("shopclues555");
		surveyDistributionInfo4.setSurveyName("shopclues survey");
		surveyDistributionInfo4.setDescription("the survey wants to know about the Website review");
		surveyDistributionInfo4.setFromDate(LocalDate.of(2020, 05, 06));
		surveyDistributionInfo4.setToDate(LocalDate.of(2020, 05, 21));

		surveyDistributionList.add(surveyDistributionInfo1);
		surveyDistributionList.add(surveyDistributionInfo2);
		surveyDistributionList.add(surveyDistributionInfo3);
		surveyDistributionList.add(surveyDistributionInfo4);

		return surveyDistributionList;

	}

}
