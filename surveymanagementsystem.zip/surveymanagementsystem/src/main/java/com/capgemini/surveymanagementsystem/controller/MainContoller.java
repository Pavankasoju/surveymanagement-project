package com.capgemini.surveymanagementsystem.controller;

import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveymanagementsystem.dao.Dao;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * program starts here
 * @author Pavan Kumar
 */
import com.capgemini.surveymanagementsystem.service.Service;

public class MainContoller {
	static final Logger logger = Logger.getLogger(MainContoller.class);
	static Dao dao = Factory.daoInstance();

	private MainContoller() {
	}

	/**
	 * main method starts here
	 * 
	 * @param array of string arguments
	 * @exception it throws IOException
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Service service = Factory.serviceInstance();
		boolean flag = true;
		do {
			logger.info("Welcome To Survey Management System");
			logger.info("====================================");
			logger.info("	  Login as");
			logger.info("1.Admin");
			logger.info("2.Surveyor");
			logger.info("3.Respondent");
			logger.info("4.Exit App");
			String choose = scanner.nextLine();
			while (!service.validateChoice(choose)) {
				logger.error("please enter valid numbers from [1-4]");
				choose = scanner.nextLine();
			}
			int select = Integer.parseInt(choose);
			switch (select) {
			case 1:
				AdminController.admin();
				break;
			case 2:
				SurveyorController.surveyor();
				break;
			case 3:
				RespondentController.respondent();
				break;
			case 4:
				logger.info("Thanks for using Survey Management System");
				flag = false;
				break;
			default:
				logger.error("please enter valid choice from [1-4] ");
				break;
			}
		} while (flag);
		scanner.close();
	}
}
