package com.capgemini.surveymanagementsystem.controller;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.SurveyReport;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.exceptions.InvalidSurveyorException;
import com.capgemini.surveymanagementsystem.exceptions.SurveyNotFoundException;
import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.service.AdminService;
import com.capgemini.surveymanagementsystem.service.RespondentService;
import com.capgemini.surveymanagementsystem.service.Service;
import com.capgemini.surveymanagementsystem.service.SurveyorService;

/**
 * @author Admin
 * 
 *         this method is used to access surveyor module with login credintials
 * @SurveyNotFoundException
 * @SurveyorNotFoundException
 * @InvalidRespondentException
 */
public class SurveyorController {
	private SurveyorController() {

	}

	static Scanner scanner = new Scanner(System.in);
	static final Logger logger = Logger.getLogger(SurveyorController.class);
	static Service service = Factory.serviceInstance();
	static SurveyorService surveyorService = Factory.surveyorServiceInstance();
	static RespondentService respondentService = Factory.respondentServiceInstance();
	static AdminService adminService = Factory.adminServiceInstance();

	public static void surveyor() {
		logger.info("Enter loginId");
		String loginId = scanner.nextLine();
		while (!service.validateLoginId(loginId)) {
			logger.error("enter valid loginId [length must contain 5-18 (no space)]");
			loginId = scanner.nextLine();
		}
		logger.info("Enter your Password");
		String password = scanner.nextLine();
		while (!service.validatePassword(password)) {
			logger.error("enter valid password [should contain caps,small,@]");
			password = scanner.nextLine();
		}
			if (surveyorService.requestLogin(loginId, password)) {
				boolean flag = true;
				boolean check1 = true;
				int serial2 = 0;
				do {
					
					while (check1) {
						for (String notifications : surveyorService.requestNewNotification()) {
							serial2++;
							notifications.chars();
						}
						check1 = false;
					}
					
					logger.info("============================");
					logger.info("1.Notifications(" + serial2 + ")");
					logger.info("2.Organise Surveys");
					logger.info("3.Survey status");
					logger.info("4.All Surveys details");
					logger.info("5.View results");
					logger.info("6.Distribute survey");
					logger.info("7.Update my details & Respondent eligible surveys");
					logger.info("8.Logout");
					logger.info("=============================");
					String choose = scanner.nextLine();
					while (!service.validateChoice(choose)) {
						logger.error(" enter valid choice  ");
						choose = scanner.nextLine();
					}
					int select = Integer.parseInt(choose);
					switch (select) {
					case 1:
						
						logger.info("------------New------------");
						if (surveyorService.requestNewNotification().isEmpty()) {
							logger.info("Empty");
						} else {
							int serial = 0;
							for (String notifications : surveyorService.requestNewNotification()) {
								serial++;
								logger.info(serial + ". " + notifications);
							}
						}
						serial2 = 0;
						logger.info("---------------------------\n ");
						check1 = false;
						boolean notify1 = true;
						do {
							logger.info("1.All notifications");
							logger.info("2.Delete notifications");
							logger.info("3.Back");
							String choose11 = scanner.nextLine();
							while (!service.validateChoice(choose11)) {
								logger.error("enter valid choice[1-3]");
								choose11 = scanner.nextLine();
							}
							int set = Integer.parseInt(choose11);
							switch (set) {
							case 1:
								logger.info("-------------All-----------");
								Collections.reverse(surveyorService.requestOldNotification());
								if (surveyorService.requestOldNotification().isEmpty()) {
									logger.info("Empty");
								} else {
									int serial = 0;
									for (String notifications : surveyorService.requestOldNotification()) {
										serial++;
										logger.info(serial + ". " + notifications);
									}
								}
								Collections.reverse(surveyorService.requestOldNotification());
								logger.info("---------------------------\n ");
								break;
							case 2:
								if (surveyorService.requestOldNotification().isEmpty()) {
									logger.info("notifications box is empty\n ");
								} else {
									if (surveyorService.requestDeleteNotifications()) {
										logger.info("notifications deleted successfully\n ");
									} else {
										logger.info("notifications deleted failed");
									}
								}
								break;
							case 3:
								notify1 = false;
								break;
							default:
								logger.info("enter valid choice[1-3]");
								break;
							}
						} while (notify1);
						
						break;
					case 2:
						boolean check = true;
						do {
						logger.info("1.create survey");
						logger.info("2.update survey");
						logger.info("3.delete survey");
						logger.info("4.back");
						String choose1 = scanner.nextLine();
						while (!service.validateChoice(choose1)) {
							logger.error(" enter valid choice  ");
							choose1 = scanner.nextLine();
						}
						int select1 = Integer.parseInt(choose1);
						switch (select1) {
						case 1:
							createSurvey();
							break;
						case 2:
							updateSurvey();
							break;
						case 3:
							deleteSurvey();
							break;
						case 4:
							check = false;
							break;
							default:
								logger.error("enter valid choice [1-4]");
								break;
						}
						}while(check);
						break;
					case 3:
						logger.info("enter surveyId to view");
						String surveyId4 = scanner.nextLine();
						while (!service.validateLoginId(surveyId4)) {
							logger.error("enter valid surveyId");
							surveyId4 = scanner.nextLine();
						}
						logger.info("list of respondents eligible for this survey");
						List<Respondent> showEligible = respondentService.requestSurveyEligible(surveyId4);
						if (showEligible.isEmpty()) {
							logger.info("Zero respondents are eligible for this survey");
						} else {
							for (Respondent respondentInfo : showEligible) {
								logger.info(respondentInfo.getName());
							}
						}
						logger.info("            ");
						logger.info("list of respondents gave response to this survey");
						if (surveyorService.requestSurveyRespondedRespondents(surveyId4) == null) {
							logger.info("not yet responded by any respondent");
						} else {
							for (String responded : surveyorService.requestSurveyRespondedRespondents(surveyId4)) {
								logger.info(responded);
							}
						}
						break;
					case 4:
						viewSurvey();
						break;
					case 5:
						viewResult();
						break;
					case 6:
						logger.info(" List of surveys to Distribute ");
						for (SurveyDistribution surveyDistributionInfo : surveyorService
								.requestGetDistributionSurveys()) {
							logger.info(surveyDistributionInfo.getSurveyName() + "----"
									+ surveyDistributionInfo.getSurveyId());
						}
						boolean seven = true;
						do {
							logger.info("1.distribute survey");
							logger.info("2.back");
							String choose7 = scanner.nextLine();
							while (!service.validateChoice(choose7)) {
								logger.error("enter valid choice");
								choose7 = scanner.nextLine();
							}
							int select7 = Integer.parseInt(choose7);
							switch (select7) {
							case 1:
								logger.info("enter surveyId to distribute");
								String surveyId7 = scanner.nextLine();
								while (!service.validateLoginId(surveyId7)) {
									logger.error("enter valid survey ID [must contains length 5 to 14]");
									surveyId7 = scanner.nextLine();
								}
								String surveyName = null;
								for (SurveyDistribution surveyDistributionInfo : surveyorService
										.requestGetDistributionSurveys()) {
									if(surveyDistributionInfo.getSurveyId().contentEquals(surveyId7)) {
										 surveyName = surveyDistributionInfo.getSurveyName();
									}
								}
								if (surveyorService.requestDistributeSurveys(surveyId7)) {
									logger.info("survey distributed successfully");
					
									String notify = "Survey : "+surveyName+"("+surveyId7+")"+" is distributed successfully on "+LocalDate.now();
									adminService.notification(notify);
									
								} else {
									logger.error("survey Not Found (or) distribution failed");
								}
								break;
							case 2:
								seven = false;
								break;
							default:
								logger.error("enter valid choice");
								break;
							}
						} while (seven);
						break;
					case 7:
						boolean eight = true;
						do {
							logger.info("1.update my details");
							logger.info("2.update survey Eligible Respondents ");
							logger.info("3.back");
							String choice8 = scanner.nextLine();
							while (!service.validateChoice(choice8)) {
								logger.error("enter valid choice");
								choice8 = scanner.nextLine();
							}
							int select8 = Integer.parseInt(choice8);
							switch (select8) {
							case 1:
								update(loginId);
								break;
							case 2:
								logger.info("enter respondent loginId to update respondent eligible surveys");
								String loginId8 = scanner.nextLine();
								while (!service.validateLoginId(loginId8)) {
									logger.error("enter valid loginId");
									loginId8 = scanner.nextLine();
								}
								logger.info("list of surveys eligible");
								logger.info("-------------------------");
								SurveyTopics survey1 = respondentService.requestRespondentEligibleSurveys1(loginId8);
								logger.info(survey1.getSurveyName() + "----" + survey1.getSurveyId());
								SurveyTopics survey2 = respondentService.requestRespondentEligibleSurveys2(loginId8);
								logger.info(survey2.getSurveyName() + "----" + survey2.getSurveyId());
								logger.info("-------------------------");
								logger.info("enter new surveyId1 to update");
								String surveyId81 = scanner.nextLine();
								while (!service.validateLoginId(surveyId81)) {
									logger.error("enter valid loginId");
									surveyId81 = scanner.nextLine();
								}
								while (surveyorService.requestVerifySurvey(surveyId81)) {
									logger.error("survey not found try different surveyId");
									surveyId81 = scanner.nextLine();
									while (!service.validateLoginId(surveyId81)) {
										logger.error("enter valid surveyId [length must contains [5-18]");
										surveyId81 = scanner.nextLine();
									}
								}
								logger.info("enter new surveyId2 to update");
								String surveyId82 = scanner.nextLine();
								while (!service.validateLoginId(surveyId82)) {
									logger.error("enter valid loginId");
									surveyId82 = scanner.nextLine();
								}
								while (surveyId81.contentEquals(surveyId82)) {
									logger.error("Already assigned set another surveyId");
									surveyId82 = scanner.nextLine();
									while (!service.validateLoginId(surveyId82)) {
										logger.error("enter valid surveyId [length must contains [5-18]");
										surveyId82 = scanner.nextLine();
									}
								}
								while (surveyorService.requestVerifySurvey(surveyId82)) {
									logger.error("survey not found try different surveyId");
									surveyId82 = scanner.nextLine();
									while (!service.validateLoginId(surveyId82)) {
										logger.error("enter valid surveyId [length must contains [5-18]");
										surveyId82 = scanner.nextLine();
									}
								}
								if (respondentService.requestUpdateSurveyEligible(loginId8, surveyId81, surveyId82)) {
									logger.info("surveys updated successfully");
								} else {
									logger.error("surveys not found");
								}
								break;
							case 3:
								eight = false;
								break;
							default:
								logger.error("enter valid choice");
								break;
							}
						} while (eight);
						break;
					case 8:
						flag = false;
						break;
					default:
						logger.error("please enter valid choice [1-9]");
						break;
					}
				} while (flag);
			} else {
				logger.info("Invalid details");
			
		boolean forgot = true;
		do {
			logger.info("1.Login again");
			logger.info("2.Forgot password");
			logger.info("3.Home");
			String choose = scanner.nextLine();
			while (!service.validateChoice(choose)) {
				logger.error("enter valid choice from [1-3]");
				choose = scanner.nextLine();
			}
			int select = Integer.parseInt(choose);
			switch (select) {
			case 1:
				surveyor();
				forgot = false;
				break;
			case 2:
				logger.info("Enter loginId");
				String loginId2 = scanner.nextLine();
				while (!service.validateLoginId(loginId2)) {
					logger.error("enter valid loginId [length must contains 5-18 (no space)]");
					loginId2 = scanner.nextLine();
				}
				logger.info("enter your mailId");
				String mailId = scanner.nextLine();
				while (!service.validateGmail(mailId)) {
					logger.error("enter valid mail ID");
					mailId = scanner.nextLine();
				}
				if (surveyorService.requestForgotPassword(loginId2, mailId)) {
					logger.info("enter new password");
					String newPassword = scanner.nextLine();
					while (!service.validatePassword(newPassword)) {
						logger.error("enter valid password [should contain caps,small-char,@ symbol]");
						newPassword = scanner.nextLine();
					}
					if (surveyorService.requestSetPassword(loginId2, mailId, newPassword)) {
						logger.info("your password changed successfully");
						logger.info("login with your new Password");
						surveyor();
						forgot = false;
						break;
					} else {
						logger.error("failed to change password");
					}
				} else {
					logger.error("input details not matched with system records");
					forgot = false;
					break;
				}
				break;
			case 3:
				
				forgot = false;
				break;
			default:
				logger.error("enter valid choice");
				break;
			}
		} while (forgot);
		
			}
	}

	public static void update(String loginId) {

		try {
			if (!surveyorService.requestVerifyLoginId(loginId)) {
				logger.info("enter your name [should be first and last name (only chars)]");
				String name = scanner.nextLine();
				while (!service.validateName(name)) {
					logger.error("enter valid name [should be first and last name (only chars)]");
					name = scanner.nextLine();
				}
				logger.info("enter your Phone Number [must contains 10 digits]");
				String number = scanner.nextLine();
				while (!service.validatePhoneNumber(number)) {
					logger.error("enter valid phone number [must contains 10 digits]");
					number = scanner.nextLine();
				}
				long phoneNumber = Long.parseLong(number);
				logger.info("enter your Gmail [ ex: survey@gmail.com ]");
				String gmail = scanner.nextLine();
				while (!service.validateGmail(gmail)) {
					logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
					gmail = scanner.nextLine();
				}

				logger.info("enter valid password[must contains Symbol,digit,first char Caps & length [6-20]]");
				String newPassword = scanner.nextLine();
				while (!service.validatePassword(newPassword)) {
					logger.error("enter valid password[must contains Symbol,digit,first char Caps & length [6-20]]");
					newPassword = scanner.nextLine();
				}
				if (surveyorService.requestUpdate(loginId, name, phoneNumber, gmail, loginId, newPassword)) {
					logger.info("details updated successfully");
					
					String notify = " Surveyor : "+name+"("+loginId+")"+" updated his/her details on "+ LocalDate.now();
					adminService.notification(notify);
					
				} else {
					logger.error("details failed to update");
				}
			} else {
				throw new InvalidSurveyorException();
			}
		} catch (InvalidSurveyorException exception) {
			logger.error(exception.getMessage());
		}
	}

	public static void createSurvey() {
		logger.info("Create new Surveys");
		logger.info("enter new surveyId [must contains length 5 to 14]");
		String surveyId = scanner.nextLine();
		while (!service.validateLoginId(surveyId)) {
			logger.error("enter valid surveyId [must contains length 5 to 14]");
			surveyId = scanner.nextLine();
		}
		while (!surveyorService.requestVerifySurvey(surveyId)) {
			logger.error("surveyId exists with this name try different surveyId");
			surveyId = scanner.nextLine();
			while (!service.validateLoginId(surveyId)) {
				logger.error("enter valid surveyId [must contains length 5 to 14]");
				surveyId = scanner.nextLine();
			}
		}
		logger.info("enter Survey Title [length must be 5-30]");
		String surveyName = scanner.nextLine();
		while (!service.validateTitle(surveyName)) {
			logger.error("enter valid survey Title [length must be 5-30]");
			surveyName = scanner.nextLine();
		}
		logger.info("enter description  [length must be 10 - 400] ");
		String description = scanner.nextLine();
		while (!service.validateDescription(description)) {
			logger.error("enter valid description [length must be 10 - 400] ");
			description = scanner.nextLine();
		}

		LocalDate fromDate = null;
		LocalDate toDate = null;
		boolean coin = true;
		while (coin) {
			logger.info("enter Startingdate[format : YYYY-MM-DD]");
			String startDate = scanner.nextLine();
			while (!service.validateDate(startDate)) {
				logger.error("enter valid date [format : YYYY-MM-DD]");
				startDate = scanner.nextLine();
			}
			try {
				fromDate = LocalDate.parse(startDate);
				while (fromDate.isBefore(LocalDate.now())) {
					logger.error("enter valid date it should be present date or future date");
					startDate = scanner.nextLine();
					while (!service.validateDate(startDate)) {
						logger.error("enter valid date [format : YYYY-MM-DD]");
						startDate = scanner.nextLine();
					}
					fromDate = LocalDate.parse(startDate);
				}

				fromDate = LocalDate.parse(startDate);
				coin = false;
			} catch (DateTimeParseException exception) {
				logger.error("your Entered date " + startDate + " is invalid Please enter valid date");
				coin = true;
			}
		}

		coin = true;
		while (coin) {
			logger.info("enter Ending date [format : YYYY-MM-DD]");
			String endDate = scanner.nextLine();
			while (!service.validateDate(endDate)) {
				logger.error("enter valid date[format : YYYY-MM-DD]");
				endDate = scanner.nextLine();
			}
			try {
				toDate = LocalDate.parse(endDate);
				while (toDate.isBefore(fromDate)) {
					logger.error("enter valid date should be Starting date or future date");
					endDate = scanner.nextLine();
					while (!service.validateDate(endDate)) {
						logger.error("enter valid date");
						endDate = scanner.nextLine();
					}
					toDate = LocalDate.parse(endDate);
				}
				toDate = LocalDate.parse(endDate);
				coin = false;
			} catch (DateTimeParseException exception) {
				logger.error("your Entered date " + endDate + " is invalid Please enter valid date");
				coin = true;
			}
		}

		if (surveyorService.requestAddSurvey(surveyId, surveyName, description, fromDate, toDate)) {
			logger.info("survey created successfully");
			
			String notify = " A new survey : "+surveyName+"("+surveyId+")"+" Created on "+ LocalDate.now();
			adminService.notification(notify);

			logger.info("Create Questions");
			logger.info("There are four questions to create");
			logger.info("Each question consists of four options");
			int count1 = 0;
			for (int i = 1; i <= 4; i++) {
				logger.info("Write " + i + "." + "Question here [length must be 10 - 200]");
				String question = scanner.nextLine();
				while (!service.validateQuestion(question)) {
					logger.error("enter valid question [length must be 10 - 200]");
					question = scanner.nextLine();
				}
				logger.info("Write a.option [length must be 1 - 200 ]");
				String option1 = scanner.nextLine();
				while (!service.validateOption(option1)) {
					logger.error("enter valid option [length must be 1 - 200 ]");
					option1 = scanner.nextLine();
				}
				logger.info("Write b.option [length must be 1 - 200 ] ");
				String option2 = scanner.nextLine();
				while (!service.validateOption(option2)) {
					logger.error("enter valid option [length must be 1 - 200 ]");
					option2 = scanner.nextLine();
				}
				logger.info("Write c.option [length must be 1 - 200 ] ");
				String option3 = scanner.nextLine();
				while (!service.validateOption(option3)) {
					logger.error("enter valid option [length must be 1 - 200 ]");
					option3 = scanner.nextLine();
				}
				logger.info("Write d.option [length must be 1 - 200 ] ");
				String option4 = scanner.nextLine();
				while (!service.validateOption(option4)) {
					logger.error("enter valid option [length must be 1 - 200 ]");
					option4 = scanner.nextLine();
				}
				if (surveyorService.createQuestions(surveyId, i, question, option1, option2, option3, option4)) {
					count1++;
				}
			}
			if (count1 == 0) {
				logger.error("Questions not created");
			} else {
				logger.info("questions created successfully");
			}
		} else {
			logger.error("survey not created");
		}
	}

	public static void updateSurvey() {

		logger.info("list of surveys to update");
		logger.info("  surveys         survey Id's  ");
		for (SurveyDistribution surveyDistributionInfo : surveyorService.requestGetDistributionSurveys()) {
			logger.info(surveyDistributionInfo.getSurveyName() + "----" + surveyDistributionInfo.getSurveyId());
		}
		logger.info("---------------------------");
		logger.info("enter surveyId to update details");

		String surveyId = scanner.nextLine();
		while (!service.validateLoginId(surveyId)) {
			logger.info("enter valid surveyId");
			surveyId = scanner.nextLine();
		}

		if (surveyorService.requestSurveyUpdateVerify(surveyId)) {
			logger.info("update Survey title [length must be 5-30]");
			String surveyName1 = scanner.nextLine();
			while (!service.validateTitle(surveyName1)) {
				logger.error("enter valid survey title [length must be 5-30]");
				surveyName1 = scanner.nextLine();
			}
			logger.info("Update Description");
			logger.info("enter description  [length must be 10 - 400]");
			String description1 = scanner.nextLine();
			while (!service.validateDescription(description1)) {
				logger.error("enter valid description [length must be 10 - 400] ");
				description1 = scanner.nextLine();
			}
			logger.info("update survey Date");

			LocalDate fromDate1 = null;
			LocalDate toDate1 = null;
			boolean coin1 = true;
			while (coin1) {
				logger.info("enter Startingdate[format : YYYY-MM-DD]");
				String startDate1 = scanner.nextLine();
				while (!service.validateDate(startDate1)) {
					logger.error("enter valid date [format : YYYY-MM-DD]");
					startDate1 = scanner.nextLine();
				}
				try {
					fromDate1 = LocalDate.parse(startDate1);
					while (fromDate1.isBefore(LocalDate.now())) {
						logger.error("enter valid date it should be present date or future date");
						startDate1 = scanner.nextLine();
						while (!service.validateDate(startDate1)) {
							logger.error("enter valid date [format : YYYY-MM-DD]");
							startDate1 = scanner.nextLine();
						}
						fromDate1 = LocalDate.parse(startDate1);
					}

					fromDate1 = LocalDate.parse(startDate1);
					coin1 = false;
				} catch (DateTimeParseException exception) {
					logger.error("your Entered date " + startDate1 + " is Invalid Please enter valid date");
					coin1 = true;
				}
			}

			coin1 = true;
			while (coin1) {
				logger.info("enter Ending date [format : YYYY-MM-DD]");
				String endDate1 = scanner.nextLine();
				while (!service.validateDate(endDate1)) {
					logger.error("enter valid date[format : YYYY-MM-DD]");
					endDate1 = scanner.nextLine();
				}
				try {
					toDate1 = LocalDate.parse(endDate1);
					while (toDate1.isBefore(fromDate1)) {
						logger.error("enter valid date should be starting date or future date");
						endDate1 = scanner.nextLine();
						while (!service.validateDate(endDate1)) {
							logger.error("enter valid date");
							endDate1 = scanner.nextLine();
						}
						toDate1 = LocalDate.parse(endDate1);
					}
					toDate1 = LocalDate.parse(endDate1);
					coin1 = false;
				} catch (DateTimeParseException exception) {
					logger.error("your Entered date " + endDate1 + " is invalid Please enter valid date");
					coin1 = true;
				}
			}

			if (surveyorService.requestSurveyUpdate(surveyId, surveyName1, description1, fromDate1, toDate1)) {
				logger.info("survey updated successfully");
				
				String notify = "Survey : "+surveyName1+"("+surveyId+")"+" updated on "+ LocalDate.now();
				adminService.notification(notify);
				
				boolean two = true;
				do {
					logger.info("1.update by question number[1-4]");
					logger.info("2.back");
					String choose1 = scanner.nextLine();
					while (!service.validateChoice(choose1)) {
						logger.error("enter valid choice");
						choose1 = scanner.nextLine();
					}
					int select1 = Integer.parseInt(choose1);
					switch (select1) {
					case 1:
						logger.info("enter question number [range must be 1- 4 ]");
						String questionNumber = scanner.nextLine();
						while (!service.validateQuestionNumber(questionNumber)) {
							logger.error("enter valid Question number  [range must be 1- 4 ]");
							questionNumber = scanner.nextLine();
						}
						int questionNo = Integer.parseInt(questionNumber);
						logger.info("enter question  [length must be 10 - 200]");
						String question = scanner.nextLine();
						while (!service.validateQuestion(question)) {
							logger.error("enter valid question [length must be 10 - 200]");
							question = scanner.nextLine();
						}
						logger.info("enter option1 [length must be 1 - 200 ]");
						String option1 = scanner.nextLine();
						while (!service.validateOption(option1)) {
							logger.error("enter valid option [length must be 1 - 200 ]");
							option1 = scanner.nextLine();
						}
						logger.info("enter option2 [length must be 1 - 200 ]");
						String option2 = scanner.nextLine();
						while (!service.validateOption(option2)) {
							logger.error("enter valid option [length must be 1 - 200 ]");
							option2 = scanner.nextLine();
						}
						logger.info("enter option3 [length must be 1 - 200 ]");
						String option3 = scanner.nextLine();
						while (!service.validateOption(option3)) {
							logger.error("enter valid option [length must be 1 - 200 ]");
							option3 = scanner.nextLine();
						}
						logger.info("enter option4 [length must be 1 - 200 ]");
						String option4 = scanner.nextLine();
						while (!service.validateOption(option4)) {
							logger.error("enter valid option [length must be 1 - 200 ]");
							option4 = scanner.nextLine();
						}
						if (surveyorService.updateQuestions(surveyId, questionNo, question, option1, option2, option3,
								option4)) {
							logger.info("questions updated successfully");
						} else {
							logger.error("questions updation failed ");
						}
						break;
					case 2:
						two = false;
						break;
					default:
						logger.error("enter valid choice");
					}
				} while (two);
			} else {
				logger.error("survey failed to update ");
			}
		} else {
			logger.error("Survey not found (or) Survey already distributed you cant update now");
		}
	}

	public static void deleteSurvey() {
		logger.info("list of surveys to delete");
		logger.info("  surveys         survey Id's");
		for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
			logger.info(surveyTopicsInfo.getSurveyName() + "----" + surveyTopicsInfo.getSurveyId());
		}
		logger.info("------------------------");
		logger.info("enter surveyId to delete");

		String surveyId3 = scanner.nextLine();
		while (!service.validateLoginId(surveyId3)) {
			logger.error("enter valid surveyId");
			surveyId3 = scanner.nextLine();
		}
		String surveyName = null;
		for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
			if(surveyTopicsInfo.getSurveyId().contentEquals(surveyId3)) {
			surveyName = surveyTopicsInfo.getSurveyName();
			}
		}
		try {
			if (surveyorService.deleteSurvey(surveyId3)) {
				logger.info("Survey deleted successfully");
				
				String notify = "Survey : "+surveyName+"("+surveyId3+")"+" deleted on "+LocalDate.now();
				adminService.notification(notify);
				
			} else {
				throw new SurveyNotFoundException("Survey not found");
			}
		} catch (SurveyNotFoundException e) {
			logger.error(e.getMessage());
		}
	}

	public static void viewSurvey() {
		boolean flag4 = true;
		do {
			logger.info("1.view Survey Topics");
			logger.info("2.view Survey Topics with full details");
			logger.info("3.back");
			String choose5 = scanner.nextLine();
			while (!service.validateChoice(choose5)) {
				logger.error("enter valid choice [1-3]");
				choose5 = scanner.nextLine();
			}
			int select5 = Integer.parseInt(choose5);
			switch (select5) {
			case 1:
				for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
					logger.info(surveyTopicsInfo.getSurveyName() + "----" + surveyTopicsInfo.getSurveyId());
				}
				logger.info("enter surveyId to view full details");
				String surveyId4 = scanner.nextLine();
				while (!service.validateLoginId(surveyId4)) {
					logger.error("enter valid surveyId");
					surveyId4 = scanner.nextLine();
				}
				int count4 = 0;
				for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
					if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId4)) {
						count4++;
						logger.info(surveyTopicsInfo);
					}
				}
				if (count4 == 0) {
					logger.error("survey not found");
				}
				break;
			case 2:
				for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
					logger.info(surveyTopicsInfo);
				}
				break;
			case 3:
				flag4 = false;
				break;
			default:
				logger.error("enter valid choice [1-3]");
				break;
			}
		} while (flag4);
	}

	public static void viewResult() {
		boolean flag4 = true;
		do {
			logger.info("1.view reports of specific respondent");
			logger.info("2.view reports of surveys");
			logger.info("3.back");
			String choice4 = scanner.nextLine();
			while (!service.validateChoice(choice4)) {
				logger.error("enter valid choice");
				choice4 = scanner.nextLine();
			}
			int select4 = Integer.parseInt(choice4);
			switch (select4) {
			case 1:
				logger.info("list of respondents");
				logger.info("respondents         respondent Id's");
				for (Respondent respondentInfo : respondentService.requestGetRespondentList()) {
					logger.info(respondentInfo.getName() + "----" + respondentInfo.getLoginId());
				}
				logger.info("-------------------------");
				logger.info("enter respondentId");
				String respondentId = scanner.nextLine();
				while (!service.validateLoginId(respondentId)) {
					logger.error("enter valid respondentId");
					respondentId = scanner.nextLine();
				}
				int count5 = 0;
				for (Respondent respondentInfo : respondentService.requestGetRespondentList()) {
					if (respondentInfo.getLoginId().contentEquals(respondentId)) {
						count5++;
					}
				}
				if (count5 > 0) {
					if (surveyorService.result(respondentId) == null) {
						logger.info("not yet given response for any survey");
					} else {
						logger.info(surveyorService.result(respondentId));
					}
				} else {
					logger.error("respondent not found");
				}
				break;
			case 2:
				logger.info("list of surveys");
				logger.info("survey         survey Id's");
				for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
					logger.info(surveyTopicsInfo.getSurveyName() + "----" + surveyTopicsInfo.getSurveyId());
				}
				logger.info("                     ");
				logger.info("enter surveyId");
				String surveyId = scanner.nextLine();
				while (!service.validateLoginId(surveyId)) {
					logger.error("enter valid surveyId");
					surveyId = scanner.nextLine();
				}
				int count55 = 0;
				for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
					if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId)) {
						count55++;
					}
				}
				double countEligible = 0;
				int counts = 0;
				List<Respondent> showEligible2 = respondentService.requestSurveyEligible(surveyId);
				for (Respondent respondentInfo : showEligible2) {
					counts++;
					countEligible++;
					respondentInfo.getName();
				}
				if (counts == 0) {
					countEligible = 100;
				}
				double result = 100 / countEligible;
				int percentage = (int) result;
				if (count55 > 0) {
					if (surveyorService.report(surveyId) == null) {
						logger.info("no response found for this survey");
					} else {
						logger.info(" -----------------Final Results------------------");
						for (SurveyReport surveyReportInfo : surveyorService.report(surveyId)) {
							logger.info("#.surveyId = " + surveyReportInfo.getSurveyId() + "\n"
									+ surveyReportInfo.getQuestionNumber() + "." + surveyReportInfo.getQuestion() + "\n"
									+ surveyReportInfo.getOptionA() + " = " + surveyReportInfo.getOption1() * percentage
									+ "%" + "\n" + surveyReportInfo.getOptionB() + "= "
									+ surveyReportInfo.getOption2() * percentage + "%" + "\n"
									+ surveyReportInfo.getOptionC() + "= " + surveyReportInfo.getOption3() * percentage
									+ "%" + "\n" + surveyReportInfo.getOptionD() + " = "
									+ surveyReportInfo.getOption4() * percentage + "%" + "\n");
							logger.info("-----------------------------------------------");
						}
					}
				} else {
					logger.error("Survey not found");
				}
				break;
			case 3:
				flag4 = false;
				break;
			default:
				logger.error("enter valid choice");
				break;
			}
		} while (flag4);
	}

}