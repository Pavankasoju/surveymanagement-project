package com.capgemini.surveymanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagementsystem.bean.Surveyor;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this class contains dummy data of Surveyor
 * 
 * @author Admin
 *
 */
public class SurveyorRepository {

	protected static List<Surveyor> surveyorList = new ArrayList<Surveyor>();

	public List<Surveyor> getSurveyList() {

		Surveyor info = Factory.surveyorInfoInstance();
		info.setName("shiva reddy");
		info.setPhoneNumber(7897897897l);
		info.setMail("shiva90@gmail.com");
		info.setLoginId("shiva-reddy");
		info.setPassword("Shiva@123");

		surveyorList.add(info);
		return surveyorList;
	}

}
