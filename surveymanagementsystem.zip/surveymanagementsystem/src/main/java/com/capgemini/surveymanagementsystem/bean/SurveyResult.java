package com.capgemini.surveymanagementsystem.bean;

import java.io.Serializable;

public class SurveyResult implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5179457451328678223L;

	public SurveyResult() {

	}

	private String surveyId;
	private String respondentId;
	private String question;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private int option1;
	private int option2;
	private int option3;
	private int option4;
	private int questionNumber;

	/**
	 * this method is used to get questionNumber
	 * 
	 * @return integer
	 */
	public int getQuestionNumber() {
		return questionNumber;
	}

	/**
	 * this method is used to set questionNumber
	 * 
	 * @param questionNumber
	 */
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}

	/**
	 * this method is used to get surveyId
	 * 
	 * @return String
	 */
	public String getSurveyId() {
		return surveyId;
	}

	/**
	 * this method is used to set surveyId
	 * 
	 * @param surveyId
	 */
	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}

	/**
	 * this method is used to get respondentId
	 * 
	 * @return String
	 */
	public String getRespondentId() {
		return respondentId;
	}

	/**
	 * this method is used to set respondentId
	 * 
	 * @param respondentId
	 */
	public void setRespondentId(String respondentId) {
		this.respondentId = respondentId;
	}

	/**
	 * this method is used to get question
	 * 
	 * @return String
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * this method is used to set question
	 * 
	 * @param question
	 */
	public void setQuestion(String question) {
		this.question = question;
	}

	/**
	 * this method is used to get opt1Name
	 * 
	 * @return String
	 */
	public String getOptionA() {
		return optionA;
	}

	/**
	 * this method is used to set opt1Name
	 * 
	 * @param optionA
	 */
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	/**
	 * this method is used to get opt2Name
	 * 
	 * @return String
	 */
	public String getOptionB() {
		return optionB;
	}

	/**
	 * this method is used to set opt2Name
	 * 
	 * @param optionB
	 */
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	/**
	 * this method is used to get opt3Name
	 * 
	 * @return String
	 */
	public String getOptionC() {
		return optionC;
	}

	/**
	 * this method is used to set opt3Name
	 * 
	 * @param optionC
	 */
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	/**
	 * this method is used to get opt4Name
	 * 
	 * @return String
	 */
	public String getOptionD() {
		return optionD;
	}

	/**
	 * this method is used to set opt4Name
	 * 
	 * @param optionD
	 */
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	/**
	 * this method is used to get option1
	 * 
	 * @return integer
	 */
	public int getOption1() {
		return option1;
	}

	/**
	 * this method is used to set option1
	 * 
	 * @param option1
	 */
	public void setOption1(int option1) {
		this.option1 = option1;
	}

	/**
	 * this method is used to get option2
	 * 
	 * @return integer
	 */
	public int getOption2() {
		return option2;
	}

	/**
	 * this method is used to set option2
	 * 
	 * @param option2
	 */
	public void setOption2(int option2) {
		this.option2 = option2;
	}

	/**
	 * this method is used to get option3
	 * 
	 * @return integer
	 */
	public int getOption3() {
		return option3;
	}

	/**
	 * this method is used to set option3
	 * 
	 * @param option3
	 */
	public void setOption3(int option3) {
		this.option3 = option3;
	}

	/**
	 * this method is used to get option4
	 * 
	 * @return
	 */
	public int getOption4() {
		return option4;
	}

	/**
	 * this method is used to set option4
	 * 
	 * @param option4
	 */
	public void setOption4(int option4) {
		this.option4 = option4;
	}

	@Override
	public String toString() {
		return "\n" + " -----------------Results------------------" + "\n #.surveyId = " + surveyId
				+ "\n #.respondentId = " + respondentId + "\n" + questionNumber + "." + question + "\n" + optionA + "="
				+ option1 + "\n" + optionB + "  = " + option2 + "\n" + optionC + "= " + option3 + "\n" + optionD + " = "
				+ option4 + "\n" + "-----------------------------------------------";
	}

}
