package com.capgemini.surveymanagementsystem.service;

import java.io.IOException;
import java.util.ArrayList;

import com.capgemini.surveymanagementsystem.dao.Dao;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this is the implementation class of AdminService it contains all method
 * implementations
 * this class is used to get the information from respective controllers and send information to Dao
 * 
 * @author Pavan Kumar
 *
 */
public class AdminServiceImplementation implements AdminService {
	Dao dao = Factory.daoInstance();
	/**
	 * this method is used to login admin
	 * @param loginId
	 * @param passwors
	 * @return true or false
	 */
	@Override
	public boolean requestLogin(String loginId, String password) throws IOException {

		return dao.adminLogin(loginId, password);
	}

	/**
	 * this method is used to verifies the admin password 
	 * @param loginId
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean requestForgotPassword(String loginId, String gmail) {

		return dao.adminForgotPassword(loginId, gmail);
	}

	/**
	 * this method is used to set new password for surveyor
	 * @param loginId
	 * @param gmail
	 * @param password
	 * @return true or false
	 * @throws IOException 
	 */
	@Override
	public boolean requestSetPassword(String loginId, String gmail, String password) throws IOException {

		return dao.adminSetPassword(loginId, gmail, password);
	}

	/**
	 * this method is used to verify surveyor loginId
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public boolean adminVerifyLoginId(String loginId) {

		return dao.adminVerifyLoginId(loginId);
	}

	/**
	 * this method is used to update details of admin
	 * @param oldLoginId
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true or false
	 * @throws IOException 
	 *
	 */
	@Override
	public boolean requestUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) throws IOException {

		return dao.adminUpdate(oldLoginId, name, phoneNumber, gmail, loginId, password);
	}

	@Override
	public ArrayList<String> requestNewNotification() {
		return dao.getAdminNewNotifications();
	}

	@Override
	public boolean requestDeleteNotifications() {
		return dao.deleteAdminNotifications();
	}

	@Override
	public ArrayList<String> requestOldNotification() {
		return dao.getAdminOldNotifications();
	}


	@Override
	public boolean notification(String notificaton) {
		return dao.adminNotification(notificaton);
	}

}
