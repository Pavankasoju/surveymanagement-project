package com.capgemini.surveymanagementsystem.validations;

/**
 * this is an interface for ValidationsImpl, it contains twelve abstract methods
 * 
 * @author Pavan kumar
 *
 */
public interface Validations {

	public boolean nameValidation(String name);

	public boolean gmailValidation(String gmail);

	public boolean phoneNumberValidation(String phoneNumber);

	public boolean dateValidation(String date);

	public boolean choiceValidate(String choice);

	public boolean passwordValidation(String password);

	public boolean loginIdValidation(String loginId);

	public boolean surveyTitleValidation(String title);

	public boolean surveyDescriptionValidation(String description);

	public boolean questionValidation(String question);

	public boolean optionValidation(String option);

	public boolean questionNumberValidate(String questionNumber);

}
