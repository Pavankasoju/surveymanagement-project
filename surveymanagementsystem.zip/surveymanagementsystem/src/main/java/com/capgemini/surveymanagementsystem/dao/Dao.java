package com.capgemini.surveymanagementsystem.dao;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.SurveyReport;
import com.capgemini.surveymanagementsystem.bean.SurveyResult;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.bean.Surveyor;

/**
 * 
 * @author Admin
 *
 *         this is an interface for DaoImpl class , it contains abstract methods
 */
public interface Dao {

	// respondent

	public boolean respondentLogin(String loginId, String password);

	public boolean respondentForgotPassword(String loginId, String gmail);

	public boolean respondentSetPassword(String loginId, String gmail, String password);

	public SurveyTopics respondentEligibleSurveys1(String loginId);

	public SurveyTopics respondentEligibleSurveys2(String loginId);

	public List<SurveyTopics> respondentResponsedSurveys(String loginId);

	public boolean responseVerification(String loginId, String surveyId);

	public boolean respondentTest(String loginId, String surveyId);

	public boolean respondentVerifyLoginId(String loginId);

	public boolean respondentVerifyGmail(String gmail);

	public boolean respondentVerifyContact(long phoneNumber);

	public boolean respondentUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password);

	public List<Respondent> respondentSurveyEligible(String surveyId);

	public boolean respondentUpdateSurveyEligible(String loginId, String surveyId1, String surveyId2);

	public boolean respondentRegestration(Respondent respondent);

	public List<Respondent> getRespondentList();

	public boolean respondentDelete(String loginId);

	// SurveyTopics

	public boolean surveyTest(String surveyId, String loginId);

	public boolean verifySurvey(String surveyId);

	public boolean addSurvey(SurveyDistribution surveyDistribution);

	public boolean surveyUpdateVerify(String surveyId);

	public boolean surveyUpdate(String surveyId, String title, String description, LocalDate fromDate,
			LocalDate toDate);

	public boolean deleteSurvey(String surveyId);

	public List<SurveyTopics> getAllSurveys();

	// distributed surveys

	public List<SurveyDistribution> getDistributionSurveys();

	public boolean distributeSurveys(String surveyId);

	public boolean deleteDistributedSurvey(String surveyId);

	// Questions

	public List<Questions> questionsTest(String surveyId, String respondentId);

	public boolean createQuestions(Questions questionsInfo);

	public boolean updateQuestions(String surveyId, int questionNumber, String question, String option1, String option2,
			String option3, String option4);

	public boolean deleteQuestions(String surveyId);

	// results

	public boolean getResult(int questionNumber, String surveyId, String question, String option1, String option2,
			String option3, String option4, String respondentId, int count1, int count2, int count3, int count4);

	public List<SurveyResult> result(String respondentId);

	public ArrayList<String> surveyRespondedRespondents(String surveyId);

	// reports

	public List<SurveyReport> report(String surveyId);

	public boolean finalReport(String surveyId, String question, String option1, String option2, String option3,
			String option4, int count1, int count2, int count3, int count4, int questionNumber);

	public List<SurveyReport> getFinalReport(String surveyId);

	// Surveyor

	public boolean surveyorLogin(String loginId, String password);

	public boolean surveyorForgotPassword(String loginId, String gmail);

	public boolean surveyorSetPassword(String loginId, String gmail, String password);

	public boolean surveyorVerifyLoginId(String loginId);

	public boolean surveyorUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password);

	public boolean surveyorRegestration(Surveyor surveyor);

	public List<Surveyor> getSurveyorList();

	public boolean surveyorDelete(String loginId);
	
	public boolean surveyorNotification(String notification);

	public ArrayList<String> getSurveyorNewNotifications();

	public ArrayList<String> getSurveyorOldNotifications();

	public boolean deleteSurveyorNotifications();

	////// admin

	public boolean adminLogin(String loginId, String password) throws IOException;

	public boolean adminForgotPassword(String loginId, String gmail);

	public boolean adminSetPassword(String loginId, String gmail, String password) throws IOException;

	public boolean adminVerifyLoginId(String loginId);

	public boolean adminUpdate(String oldLoginId, String name, Long phNumber, String gmail, String loginId,
			String password) throws IOException;

	public boolean adminNotification(String notification);

	public ArrayList<String> getAdminNewNotifications();

	public ArrayList<String> getAdminOldNotifications();

	public boolean deleteAdminNotifications();

}
