package com.capgemini.surveymanagementsystem.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;
import com.capgemini.surveymanagementsystem.bean.Admin;
import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.SurveyReport;
import com.capgemini.surveymanagementsystem.bean.SurveyResult;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.bean.Surveyor;
import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.repository.AdminRepository;
import com.capgemini.surveymanagementsystem.repository.QuestionsRepository;
import com.capgemini.surveymanagementsystem.repository.RespondentRepository;
import com.capgemini.surveymanagementsystem.repository.SurveyDistributionRepository;
import com.capgemini.surveymanagementsystem.repository.SurveyTopicsRepository;
import com.capgemini.surveymanagementsystem.repository.SurveyorRepository;

/**
 * 
 * @author Admin
 *
 * this is an implementation class of Dao interface, it contains implementation for all Dao meethods
 * this class performs various operations based on request from service layers
 */
public class DaoImplementation implements Dao {

	static List<Respondent> respondentList = new RespondentRepository().getRespondentList();
	static List<SurveyTopics> surveyTopicsList = new SurveyTopicsRepository().getSurveyTopicsList();
	static List<SurveyDistribution> surveyDistributionList = new SurveyDistributionRepository()
			.getSurveyDistributionList();
	static List<SurveyResult> surveyResultList = new ArrayList<SurveyResult>();
	static List<SurveyReport> surveyReportList = new ArrayList<SurveyReport>();
	static List<Questions> questionsList = new QuestionsRepository().getQuestionsList();
	static List<Surveyor> surveyorList = new SurveyorRepository().getSurveyList();
	static List<Admin> adminList = new AdminRepository().getAdminList();
	static ArrayList<String> adminNewNotifyList = new ArrayList<String>();
	static ArrayList<String> adminOldNotifyList = new ArrayList<String>();
	static ArrayList<String> surveyornewNotifyList = new ArrayList<String>();
	static ArrayList<String> surveyoroldNotifyList = new ArrayList<String>();
	Properties properties;
	
	/// respondents
	
	/**
	 * this method is used to login respondent module

	 * @param loginId
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean respondentLogin(String loginId, String password) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)
					&& respondentInfo.getPassword().contentEquals(password)) {
				count++;
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to verifies the responded password 
	 * @param loginId
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean respondentForgotPassword(String loginId, String gmail) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId) && respondentInfo.getMail().contentEquals(gmail)) {
				count++;
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to set new password for respondent
	 * @param loginId
	 * @param gmail
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean respondentSetPassword(String loginId, String gmail, String password) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId) && respondentInfo.getMail().contentEquals(gmail)) {
				count++;
				respondentInfo.setPassword(password);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to get respondent eligible surveyId1
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public SurveyTopics respondentEligibleSurveys1(String loginId) {
		SurveyTopics one = null;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)) {

				for (SurveyTopics surveyTopicsInfo : surveyTopicsList) {
					if (surveyTopicsInfo.getSurveyId().contentEquals(respondentInfo.getSurveyId1())) {
						one = surveyTopicsInfo;
					}
				}

			}
		}
		return one;
	}

	/**
	 * this method is used to get respondent eligible surveyId1
	 * @paramloginId
	 * @return true or false
	 */
	@Override
	public SurveyTopics respondentEligibleSurveys2(String loginId) {
		SurveyTopics two = null;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)) {
				for (SurveyTopics surveyTopicsInfo : surveyTopicsList) {
					if (surveyTopicsInfo.getSurveyId().contentEquals(respondentInfo.getSurveyId2())) {
						two = surveyTopicsInfo;
					}
				}
			}
		}
		return two;
	}

	/**
	 * this method is used to get result of survey responded respondents
	 * @paramloginId
	 * @return true or false
	 */
	@Override
	public List<SurveyTopics> respondentResponsedSurveys(String loginId) {
		List<SurveyTopics> showResponseList = new ArrayList<SurveyTopics>();
		int count = 0;
		ArrayList<String> respondedlist = new ArrayList<String>();
		for (SurveyResult surveyResultInfo : surveyResultList) {
			if (surveyResultInfo.getRespondentId().contentEquals(loginId)) {
				count++;
				respondedlist.add(surveyResultInfo.getSurveyId());
			}
		}
		for (int i = 3; i < count; i += 4) {
			for (SurveyTopics surveyTopicsInfo : surveyTopicsList) {
				if (surveyTopicsInfo.getSurveyId().contentEquals(respondedlist.get(i))) {
					showResponseList.add(surveyTopicsInfo);
				}
			}
		}
		if(count==0) {
			return null;
		}else {
			return showResponseList;
		}
	}

	/**
	 * this method is used to check whether the respondent gave response to the specific survey
	 * @param loginId
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean responseVerification(String loginId, String surveyId) {
		int count = 0;
		for (SurveyResult surveyResultInfo : surveyResultList) {
			if (surveyResultInfo.getRespondentId().contentEquals(loginId)
					&& surveyResultInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to access Survey test
	 * @param loginId
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean respondentTest(String loginId, String surveyId) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)
					&& respondentInfo.getSurveyId1().contentEquals(surveyId)) {
				count++;
				surveyTest(surveyId, loginId);
			}
		}
		
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)
					&& respondentInfo.getSurveyId2().contentEquals(surveyId)) {
				count++;
				surveyTest(surveyId, loginId);
			}
		}
		return count==0?false:true;
	}

	

	/**
	 * this method is used to verify respondent loginId
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public boolean respondentVerifyLoginId(String loginId) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to verify respondent gMail
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean respondentVerifyGmail(String gmail) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getMail().contentEquals(gmail)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to verify respondent phone number
	 * @param phoneNumber
	 * @return true or false
	 */
	@Override
	public boolean respondentVerifyContact(long phoneNumber) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getPhoneNumber() == phoneNumber) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to update details of respondent
	 * @param oldLoginId
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true or false
	 *
	 */
	@Override
	public boolean respondentUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(oldLoginId)) {
				count++;
				respondentInfo.setName(name);
				respondentInfo.setMail(gmail);
				respondentInfo.setLoginId(loginId);
				respondentInfo.setPassword(password);
				respondentInfo.setPhoneNumber(phoneNumber);
			}

		}
		return count==0?false:true;
	}

	/**
	 * this method is used to check the respondents who are eligible for specific survey
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public List<Respondent> respondentSurveyEligible(String surveyId) {
		int count = 0;
		List<Respondent> showEligible = new ArrayList<Respondent>();
		for (Respondent respondentInfo1 : respondentList) {
			if (respondentInfo1.getSurveyId1().contentEquals(surveyId)) {
				count++;
				showEligible.add(respondentInfo1);
			}
		}
		for (Respondent respondentInfo2 : respondentList) {
			if (respondentInfo2.getSurveyId2().contentEquals(surveyId)) {
				count++;
				showEligible.add(respondentInfo2);
			}
		}
		if(count==0) {
			return null;
		}else {
			return showEligible;
		}
	}

	/**
	 * this method is used to update eligible surveys for specific respondents
	 * @ loginId
	 * @ surveyId1
	 * @ surveyId2
	 * @return true or false
	 */
	@Override
	public boolean respondentUpdateSurveyEligible(String loginId, String surveyId1, String surveyId2) {
		int count = 0;
		for (Respondent respondentInfo : respondentList) {
			if (respondentInfo.getLoginId().contentEquals(loginId)) {
				count++;
				respondentInfo.setSurveyId1(surveyId1);
				respondentInfo.setSurveyId2(surveyId2);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to register the respondent
	 * @return true
	 */
	@Override
	public boolean respondentRegestration(Respondent respondentInfo) {
		if(respondentInfo==null) {
			return false;
		}else {
			respondentList.add(respondentInfo);
		return true;
		}
	}

	/**
	 * this method is used to get respondent List
	 * @return List
	 */
	@Override
	public List<Respondent> getRespondentList() {
		return respondentList;
	}
	
	@Override
	public boolean respondentDelete(String loginId) {
		int count = 0;
		ListIterator<Respondent> respondentInfo = respondentList.listIterator();
		while (respondentInfo.hasNext()) {
			Respondent info = respondentInfo.next();
			if (info.getLoginId().contentEquals(loginId)) {
				count++;
				respondentInfo.remove();
			}
		}
		
		return count==0?false:true;
	}
	

	

	// surveys

	/**
	 * this method is used to access survey Test
	 * @param surveyId
	 * @param loginId
	 * @return true or false
	 * 
	 */
	@Override
	public boolean surveyTest(String surveyId, String loginId) {
		int count = 0;
		for (SurveyTopics surveyTopicsInfo : surveyTopicsList) {
			if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
				questionsTest(surveyId, loginId);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to verify surveyId
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean verifySurvey(String surveyId) {
		int count = 0;
		for (SurveyTopics surveyTopicsInfo : surveyTopicsList) {
			if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
			}
		}
		for (SurveyDistribution surveyDistributionInfo : surveyDistributionList) {
			if (surveyDistributionInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to create distribution survey
	 * @return true
	 */
	@Override
	public boolean addSurvey(SurveyDistribution surveyDistributionInfo) {
		if(surveyDistributionInfo==null) {
			return false;
		}else {
			surveyDistributionList.add(surveyDistributionInfo);
		return true;
		}
	}

	/**
	 * this method is used to verify survey to access update operation
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean surveyUpdateVerify(String surveyId) {
		int count = 0;
		for (SurveyTopics surveyTopicsInfo : surveyTopicsList) {
			if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to update survey
	 * @param surveyId
	 * @param title
	 * @param description
	 * @param fromDate
	 * @param toDate
	 * @return true or false
	 */
	@Override
	public boolean surveyUpdate(String surveyId, String title, String description, LocalDate fromDate,
			LocalDate toDate) {
		int count = 0;
		for (SurveyDistribution surveyDistributionInfo : surveyDistributionList) {
			if (surveyDistributionInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
				surveyDistributionInfo.setSurveyName(title);
				surveyDistributionInfo.setDescription(description);
				surveyDistributionInfo.setFromDate(fromDate);
				surveyDistributionInfo.setToDate(toDate);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to delete an specific survey
	 * @param surveyId
	 * @return true or false
	 * 
	 */
	@Override
	public boolean deleteSurvey(String surveyId) {
		int count = 0;
		ListIterator<SurveyTopics> surveyTopicsInfo = surveyTopicsList.listIterator();
		while (surveyTopicsInfo.hasNext()) {
			SurveyTopics info = surveyTopicsInfo.next();
			if (info.getSurveyId().contentEquals(surveyId)) {
				count++;
				surveyTopicsInfo.remove();
			}
		}
		
		return count==0?false:deleteQuestions(surveyId);
	}

	/**
	 * this method is used to get surveyTopicsList
	 * @return surveyTopicsList
	 */
	@Override
	public List<SurveyTopics> getAllSurveys() {
		return surveyTopicsList;
	}

	// distributed surveys

	/**
	 * this method is used to get surveyDistributionList
	 * @return surveyDistributionList
	 */
	@Override
	public List<SurveyDistribution> getDistributionSurveys() {
		return surveyDistributionList;
	}

	/**
	 * this method is used to distribute the survey and delete the survey
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean distributeSurveys(String surveyId) {
		int count=0;
		for(SurveyDistribution surveyDistributionInfo : surveyDistributionList) {
			if(surveyDistributionInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
				SurveyTopics surveyTopicsInfo = Factory.surveyTopicsInfoInstance();
				surveyTopicsInfo.setSurveyId(surveyDistributionInfo.getSurveyId());
				surveyTopicsInfo.setSurveyName(surveyDistributionInfo.getSurveyName());
				surveyTopicsInfo.setDescription(surveyDistributionInfo.getDescription());
				surveyTopicsInfo.setFromDate(surveyDistributionInfo.getFromDate());
				surveyTopicsInfo.setToDate(surveyDistributionInfo.getToDate());
				surveyTopicsList.add(surveyTopicsInfo);
			}
	}
		return count==0?false:deleteDistributedSurvey(surveyId);
	}
	
	/**
	 * this method is used to delete distributed survey
	 * @param surveyId
	 * return true or false
	 */
	public boolean deleteDistributedSurvey(String surveyId) {
		int count = 0;
		
			Iterator<SurveyDistribution> surveyDistributionInfo2 = surveyDistributionList.iterator();
			while (surveyDistributionInfo2.hasNext()) {
				SurveyDistribution info = surveyDistributionInfo2.next();
				if (info.getSurveyId().contentEquals(surveyId)) {
					count++;
					surveyDistributionInfo2.remove();				
					}
			}
		return count==0?false:true;
	}

	// questions

	/**
	 * this method is used to access surveyTest
	 * @param surveyId
	 * @param respondentId
	 * @return testQuestionsList
	 */
	@Override
	public List<Questions> questionsTest(String surveyId, String respondentId) {
		int questionNo = 0;
		List<Questions> testQuestionsList = new ArrayList<Questions>();
		for (Questions questionsInfo : questionsList) {
			questionNo++;
			if (questionNo == 5) {
				questionNo = 1;
			}
			if (questionsInfo.getSurveyId().contentEquals(surveyId)
					&& questionsInfo.getQuestionNumber() == questionNo) {

				testQuestionsList.add(questionsInfo);
			}
		}
		return testQuestionsList;
	}

	/**
	 * this method is used to create questions for surveys
	 * @param Object
	 * @return true
	 */
	@Override
	public boolean createQuestions(Questions questions) {
		if(questions==null) {
			return false;
		}else {
			questionsList.add(questions);
		return true;
		}
	}

	/**
	 * this method is used to update questions
	 * @param surveyId
	 * @param questionNumber
	 * @param question
	 * @param option1
	 * @param option2
	 * @param option3
	 * @param option4
	 * @return true or false
	 */
	@Override
	public boolean updateQuestions(String surveyId, int questionNumber, String question, String option1, String option2,
			String option3, String option4) {
		int count=0;
		for (Questions questionsInfo : questionsList) {
			if (questionsInfo.getSurveyId().contentEquals(surveyId)
					&& questionsInfo.getQuestionNumber() == questionNumber) {
				count++;
				questionsInfo.setQuestion(question);
				questionsInfo.setOptionA(option1);
				questionsInfo.setOptionB(option2);
				questionsInfo.setOptionC(option3);
				questionsInfo.setOptionD(option4);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to delete the questions
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean deleteQuestions(String surveyId) {
		int count = 0;
		ListIterator<Questions> questionInfo = questionsList.listIterator();
		while (questionInfo.hasNext()) {
			Questions info = questionInfo.next();
			if (info.getSurveyId().contentEquals(surveyId)) {
				count++;
				questionInfo.remove();
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to generate survey results
	 * @return true
	 */
	@Override
	public boolean getResult(int questionNumber, String surveyId, String question, String option1, String option2, String option3, String option4,
			String respondentId, int count1, int count2, int count3, int count4) {

		SurveyResult surveyResultInfo0 = Factory.surveyResultInfoInstance();
		surveyResultInfo0.setQuestionNumber(questionNumber);
		surveyResultInfo0.setSurveyId(surveyId);
		surveyResultInfo0.setQuestion(question);
		surveyResultInfo0.setRespondentId(respondentId);
		surveyResultInfo0.setOption1(count1);
		surveyResultInfo0.setOption2(count2);
		surveyResultInfo0.setOption3(count3);
		surveyResultInfo0.setOption4(count4);
		surveyResultInfo0.setOptionA(option1);
		surveyResultInfo0.setOptionB(option2);
		surveyResultInfo0.setOptionC(option3);
		surveyResultInfo0.setOptionD(option4);
		surveyResultList.add(surveyResultInfo0);
		return true;
	}

	/**
	 * this method is used to generate result of specific respondent
	 * @param respondentId
	 * @return List
	 */
	@Override
	public List<SurveyResult> result(String respondentId) {
		int count = 0;
		List<SurveyResult> showResults = new ArrayList<SurveyResult>();
		for (SurveyResult surveyResultInfo : surveyResultList) {
			if (surveyResultInfo.getRespondentId().contentEquals(respondentId)) {
				count++;
				showResults.add(surveyResultInfo);
			}
		}
		if(count==0) {
			return null;
		}else {
			return showResults;
		}
	}

	/**
	 * this method is used to retrieve survey responded respondents of specific survey
	 * @return List  
	 */
	@Override
	public ArrayList<String> surveyRespondedRespondents(String surveyId) {
		int count = 0;
		ArrayList<String> respondedlist = new ArrayList<String>();
		ArrayList<String> respondedlist2 = new ArrayList<String>();
		for (SurveyResult surveyResultInfo : surveyResultList) {
			if (surveyResultInfo.getSurveyId().contentEquals(surveyId)) {
				for (Respondent respondentInfo : respondentList) {
					if (respondentInfo.getLoginId().contentEquals(surveyResultInfo.getRespondentId())) {
						count++;
						respondedlist.add(respondentInfo.getName());
					}
				}
			}
		}
		for (int i = 3; i < count; i += 4) {
			respondedlist2.add(respondedlist.get(i));
		}
		if(count==0) {
			return null;
		}else {
			return respondedlist2;
		}
	}

	/// reports
	
	/**
	 * this method is used to generate reports of specific surveyId
	 * @param surveyId
	 * @return List
	 */
	@Override
	public List<SurveyReport> report(String surveyId) {
		int count = 0;
	for(int questionNumber=1;questionNumber<5;questionNumber++) {
		String	question = null;
		String optionA = null;
		String optionB = null;
		String optionC = null;
		String optionD = null;
		int option1 = 0;
		int option2 = 0;
		int option3 = 0;
		int option4 = 0;
		for (SurveyResult surveyResultInfo : surveyResultList) {
			if (surveyResultInfo.getSurveyId().contentEquals(surveyId)
					&& surveyResultInfo.getQuestionNumber() == questionNumber) {
				count++;
					question = surveyResultInfo.getQuestion();
				 optionA = surveyResultInfo.getOptionA();
				 optionB = surveyResultInfo.getOptionB();
				 optionC = surveyResultInfo.getOptionC();
				 optionD = surveyResultInfo.getOptionD();
				 option1 = option1 + surveyResultInfo.getOption1();
				 option2 = option2 + surveyResultInfo.getOption2();
				 option3 = option3 + surveyResultInfo.getOption3();
				 option4 = option4 + surveyResultInfo.getOption4();
			}
	}
			finalReport(surveyId, question, optionA, optionB, optionC, optionD, option1, option2, option3, option4, questionNumber);
		}
	if(count==0) {
		return null;
	}else {
		return getFinalReport(surveyId);
	}
	}

	/**
	 * this method is used to generate Survey reports
	 * @return true
	 */
	@Override
	public boolean finalReport(String surveyId, String question, String optionA, String optionB,
			String optionC, String optionD, int option1, int option2, int option3,
			int option4, int questionNumber) {
		SurveyReport surveyReportInfo = new SurveyReport();
		surveyReportInfo.setQuestionNumber(questionNumber);
		surveyReportInfo.setSurveyId(surveyId);
		surveyReportInfo.setQuestion(question);
		surveyReportInfo.setOption1(option1);
		surveyReportInfo.setOption2(option2);
		surveyReportInfo.setOption3(option3);
		surveyReportInfo.setOption4(option4);
		surveyReportInfo.setOptionA(optionA);
		surveyReportInfo.setOptionB(optionB);
		surveyReportInfo.setOptionC(optionC);
		surveyReportInfo.setOptionD(optionD);
		surveyReportList.add(surveyReportInfo);
		return true;
	}

	/**
	 * this method is used to get final report of specific survey
	 * @return List 
	 */
	@Override
	public List<SurveyReport> getFinalReport(String surveyId) {
		
		List<SurveyReport> showReports = new ArrayList<SurveyReport>();
		List<SurveyReport> report = new ArrayList<SurveyReport>();
		int count = 0;
		for (SurveyReport surveyReportInfo : surveyReportList) {
			if (surveyReportInfo.getSurveyId().contentEquals(surveyId)) {
				showReports.add(surveyReportInfo);
			}
		}
		for(SurveyReport surveyReportInfo : showReports) {
			if(surveyReportInfo.getSurveyId().contentEquals(surveyId)) {
				count++;
			}
		}
		if (count == 0) {
			return null;	
	}else {
		count = count - 4;
		report.add((showReports.get(count)));
		count++;
		report.add((showReports.get(count)));
		count++;
		report.add((showReports.get(count)));
		count++;
		report.add((showReports.get(count)));
		return report;
	}
}

	////// surveyor
	
	/**
	 * this method is used to login surveyor
	 * @param loginId
	 * @param passwors
	 * @return true or false
	 */
	@Override
	public boolean surveyorLogin(String loginId, String password) {
		int count = 0;
		for (Surveyor surveyorInfo : surveyorList) {
			if (surveyorInfo.getLoginId().contentEquals(loginId)
					&& surveyorInfo.getPassword().contentEquals(password)) {
				count++;
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to verifies the surveyor password 
	 * @param loginId
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean surveyorForgotPassword(String loginId, String gmail) {
		int count = 0;
		for (Surveyor surveyorInfo : surveyorList) {
			if (surveyorInfo.getLoginId().contentEquals(loginId) && surveyorInfo.getMail().contentEquals(gmail)) {
				count++;
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to set new password for surveyor
	 * @param loginId
	 * @param gmail
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean surveyorSetPassword(String loginId, String gmail, String password) {
		int count = 0;
		for (Surveyor surveyorInfo : surveyorList) {
			if (surveyorInfo.getLoginId().contentEquals(loginId) && surveyorInfo.getMail().contentEquals(gmail)) {
				count++;
				surveyorInfo.setPassword(password);
			}
		}
		return count==0?false:true;
	}


	/**
	 * this method is used to verify surveyor loginId
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public boolean surveyorVerifyLoginId(String loginId) {
		int count = 0;
		for (Surveyor surveyorInfo : surveyorList) {
			if (surveyorInfo.getLoginId().contentEquals(loginId)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * this method is used to update details of surveyor
	 * @param oldLoginId
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true or false
	 *
	 */
	@Override
	public boolean surveyorUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) {
		int count = 0;
		for (Surveyor surveyorInfo : surveyorList) {
			if (surveyorInfo.getLoginId().contentEquals(oldLoginId)) {
				count++;
				surveyorInfo.setLoginId(loginId);
				surveyorInfo.setMail(gmail);
				surveyorInfo.setName(name);
				surveyorInfo.setPassword(password);
				surveyorInfo.setPhoneNumber(phoneNumber);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to register the surveyor
	 * @return true
	 */
	@Override
	public boolean surveyorRegestration(Surveyor surveyor) {
		if(surveyor==null) {
			return false;
		}else {
		surveyorList.add(surveyor);
		return true;
		}
	}

	/**
	 * this method is used to get Surveyor List
	 * @return List
	 */
	@Override
	public List<Surveyor> getSurveyorList() {
		return surveyorList;
	}
	
	@Override
	public boolean surveyorDelete(String loginId) {
		int count = 0;
		ListIterator<Surveyor> surveyorInfo = surveyorList.listIterator();
		while (surveyorInfo.hasNext()) {
			Surveyor info = surveyorInfo.next();
			if (info.getLoginId().contentEquals(loginId)) {
				count++;
				surveyorInfo.remove();
			}
		}
		
		return count==0?false:true;
	}

	@Override
	public boolean surveyorNotification(String notification) {
		surveyornewNotifyList.add(notification);
		return true;
	}

	@Override
	public ArrayList<String> getSurveyorNewNotifications() {
		return surveyornewNotifyList;
	}

	@Override
	public ArrayList<String> getSurveyorOldNotifications() {
		surveyoroldNotifyList.addAll(surveyornewNotifyList);
		surveyornewNotifyList.clear();
		return surveyoroldNotifyList;
	}

	@Override
	public boolean deleteSurveyorNotifications() {
		surveyoroldNotifyList.clear();
		int count = 0;
		if(surveyoroldNotifyList.isEmpty()) {
			count++;
		}
		return count==0?false:true;
	}


	////// admin

	/**
	 * this method is used to login admin
	 * @param loginId
	 * @param passwors
	 * @return true or false
	 */
	@Override
	public boolean adminLogin(String loginId, String password) throws IOException {
		
		properties = new Properties();
		FileInputStream fileInputStream = new FileInputStream("db.properties");
		properties.load(fileInputStream);
		String propertyLoginId = properties.getProperty("adminUserName");
		String propertyPassword = properties.getProperty("adminPassword");
		int count = 0;
			if (propertyLoginId.contentEquals(loginId) && propertyPassword.contentEquals(password)) {
				count++;
			}
		return count==0?false:true;
	}

	/**
	 * this method is used to verifies the admin password 
	 * @param loginId
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean adminForgotPassword(String loginId, String gmail) {
		int count = 0;
		for (Admin adminInfo : adminList) {
			if (adminInfo.getLoginId().contentEquals(loginId) && adminInfo.getMail().contentEquals(gmail)) {
				count++;
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to set new password for surveyor
	 * @param loginId
	 * @param gmail
	 * @param password
	 * @return true or false
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	@Override
	public boolean adminSetPassword(String loginId, String gmail, String password) throws IOException {
		int count = 0;
		for (Admin adminInfo : adminList) {
			if (adminInfo.getLoginId().contentEquals(loginId) && adminInfo.getMail().contentEquals(gmail)) {
				count++;
				properties.setProperty("adminPassword", password);
				properties.store(new FileOutputStream("db.properties"), "db.properties");
				adminInfo.setPassword(password);
			}
		}
		return count==0?false:true;
	}

	/**
	 * this method is used to verify surveyor loginId
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public boolean adminVerifyLoginId(String loginId) {
		int count = 0;
		for (Admin adminInfo : adminList) {
			if (adminInfo.getLoginId().contentEquals(loginId)) {
				count++;
			}
		}
		return count==0?true:false;
	}

	/**
	 * @throws IOException 
	 * this method is used to update details of admin
	 * @param oldLoginId
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true or false
	 * @throws  
	 *
	 */
	@Override
	public boolean adminUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) throws IOException {
		
		
		int count = 0;
		for (Admin adminInfo : adminList) {
			if (adminInfo.getLoginId().contentEquals(oldLoginId)) {
				count++;
				properties.setProperty("adminUserName", loginId);
				properties.setProperty("adminPassword", password);
				properties.store(new FileOutputStream("db.properties"), "db.properties");
				adminInfo.setLoginId(loginId);
				adminInfo.setMail(gmail);
				adminInfo.setName(name);
				adminInfo.setPassword(password);
				adminInfo.setPhoneNumber(phoneNumber);
			}
		}
		return count==0?false:true;
	}

	
	@Override
	public boolean adminNotification(String notification) {
		adminNewNotifyList.add(notification);
		return true;
	}

	@Override
	public ArrayList<String> getAdminNewNotifications() {
		return adminNewNotifyList;
	}
	
	@Override
	public ArrayList<String> getAdminOldNotifications() {
		adminOldNotifyList.addAll(adminNewNotifyList);
		adminNewNotifyList.clear();
		return adminOldNotifyList;
	}

	@Override
	public boolean deleteAdminNotifications() {
		adminOldNotifyList.clear();
		int count = 0;
		if(adminOldNotifyList.isEmpty()) {
			count++;
		}
		return count==0?false:true;
	}

	
}
