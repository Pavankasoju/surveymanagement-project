package com.capgemini.surveymanagementsystem.factory;

import com.capgemini.surveymanagementsystem.bean.Admin;
import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.SurveyResult;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.bean.Surveyor;
import com.capgemini.surveymanagementsystem.dao.Dao;
import com.capgemini.surveymanagementsystem.dao.DaoImplementation;
import com.capgemini.surveymanagementsystem.repository.AdminRepository;
import com.capgemini.surveymanagementsystem.repository.QuestionsRepository;
import com.capgemini.surveymanagementsystem.repository.RespondentRepository;
import com.capgemini.surveymanagementsystem.repository.SurveyDistributionRepository;
import com.capgemini.surveymanagementsystem.repository.SurveyTopicsRepository;
import com.capgemini.surveymanagementsystem.repository.SurveyorRepository;
import com.capgemini.surveymanagementsystem.service.AdminService;
import com.capgemini.surveymanagementsystem.service.AdminServiceImplementation;
import com.capgemini.surveymanagementsystem.service.RespondentService;
import com.capgemini.surveymanagementsystem.service.RespondentServiceImplementation;
import com.capgemini.surveymanagementsystem.service.Service;
import com.capgemini.surveymanagementsystem.service.ServiceImplementation;
import com.capgemini.surveymanagementsystem.service.SurveyorService;
import com.capgemini.surveymanagementsystem.service.SurveyorServiceImplementation;
import com.capgemini.surveymanagementsystem.validations.Validations;
import com.capgemini.surveymanagementsystem.validations.ValidationsImplementation;

/**
 * this class contain multiple methods to create respective class objects and
 * return their objects
 * 
 * @author Pavan Kumar
 *
 */
public class Factory {
	
	private Factory() {
		
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Respondent respondentInfoInstance() {
		return new Respondent();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Surveyor surveyorInfoInstance() {
		return new Surveyor();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Admin adminInfoInstance() {
		return new Admin();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyTopics surveyTopicsInfoInstance() {
		return new SurveyTopics();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Questions questionsInfoInstance() {
		return new Questions();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyResult surveyResultInfoInstance() {
		return new SurveyResult();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyDistribution surveyDistributionInfoInstance() {
		return new SurveyDistribution();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static RespondentService respondentServiceInstance() {
			return new RespondentServiceImplementation();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyorService surveyorServiceInstance() {
		return new SurveyorServiceImplementation();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Service serviceInstance() {
		return new ServiceImplementation();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static AdminService adminServiceInstance() {
		return new AdminServiceImplementation();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Validations validationsInstance() {
		return new ValidationsImplementation();
	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static AdminRepository adminRepositoryInstance() {
		return new AdminRepository();

	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static QuestionsRepository questionsRepositoryInstance() {
		return new QuestionsRepository();

	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static RespondentRepository respondentRepositoryInstance() {
		return new RespondentRepository();

	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyorRepository surveyorRepositoryInstance() {
		return new SurveyorRepository();

	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyTopicsRepository surveyTopicsRepositoryInstance() {
		return new SurveyTopicsRepository();

	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static SurveyDistributionRepository surveyDistributionRepositoryInstance() {
		return new SurveyDistributionRepository();

	}

	/**
	 * this method is used to create specific class object and return its object
	 * 
	 * @return Object
	 */
	public static Dao daoInstance() {
		return new DaoImplementation();

	}

}
