package com.capgemini.surveymanagementsystem.exceptions;

public class InvalidAdminException extends RuntimeException {
	/**
	 * this is the customized exceptions created by the programmer and handle the
	 * exceptions
	 */

	private static final long serialVersionUID = 1L;
	String message = "Access Denied Wrong Credintials";

	/**
	 * this constructor will get call when exception throws and initialize exception
	 * message to respective variable
	 * 
	 * @param message
	 */

	public InvalidAdminException() {

	}

	public InvalidAdminException(String message) {
		super();
		this.message = message;
	}

	/**
	 * this method will get call whenever throw the exception
	 */
	@Override
	public String getMessage() {
		return message;
	}

}
