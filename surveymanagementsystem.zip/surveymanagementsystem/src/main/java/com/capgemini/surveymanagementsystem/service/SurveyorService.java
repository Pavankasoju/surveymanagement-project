package com.capgemini.surveymanagementsystem.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.SurveyReport;
import com.capgemini.surveymanagementsystem.bean.SurveyResult;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.bean.Surveyor;

/**
 * this is an interface for SurveyorServiceImpl class, it contains multiple
 * abstract methods
 * 
 * @author Admin
 *
 */
public interface SurveyorService {

	public boolean requestLogin(String loginId, String password);

	public boolean requestForgotPassword(String loginId, String gmail);

	public boolean requestSetPassword(String loginId, String gmail, String password);

	public boolean requestVerifyLoginId(String loginId);

	public boolean requestUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password);

	public boolean requestRegestration(String name, String gmail, Long phoneNumber, String loginId, String password);

	public List<Surveyor> requestGetSurveyorList();

	public boolean requestDelete(String loginId);

	public boolean notification(String notificaton);

	public ArrayList<String> requestNewNotification();

	public ArrayList<String> requestOldNotification();

	public boolean requestDeleteNotifications();

	// surveys

	public boolean requestVerifySurvey(String surveyId);

	public boolean requestAddSurvey(String surveyId, String title, String description, LocalDate fromDate,
			LocalDate toDate);

	public boolean requestSurveyUpdateVerify(String surveyId);

	public boolean requestSurveyUpdate(String surveyId, String title, String description, LocalDate fromDate,
			LocalDate toDate);

	public boolean deleteSurvey(String surveyId);

	public List<SurveyTopics> requestGetAllSurveys();

	// distibution surveys

	public List<SurveyDistribution> requestGetDistributionSurveys();

	public boolean requestDistributeSurveys(String surveyId);
	// questions

	public List<Questions> questionsTest(String surveyId, String respondentId);

	public boolean createQuestions(String surveyId, int questionNumber, String question, String option1, String option2,
			String option3, String option4);

	public boolean updateQuestions(String surveyId, int questionNumber, String question, String option1, String option2,
			String option3, String option4);

	public boolean requestDeleteQuestions(String surveyId);

	// results
	public boolean getResult(int questionNumber, String surveyId, String question, String optionA, String optionB,
			String optionC, String optionD, String respondentId, int option1, int option2, int option3, int option4);

	public List<SurveyResult> result(String respondentId);

	public ArrayList<String> requestSurveyRespondedRespondents(String surveyId);

	// reports
	public List<SurveyReport> report(String surveyId);

}
