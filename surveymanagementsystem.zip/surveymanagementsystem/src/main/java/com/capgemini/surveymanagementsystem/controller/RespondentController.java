package com.capgemini.surveymanagementsystem.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.exceptions.InvalidRespondentException;
import com.capgemini.surveymanagementsystem.exceptions.NotEligibleForSurveyException;
import com.capgemini.surveymanagementsystem.exceptions.SurveyNotFoundException;
import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.service.AdminService;
import com.capgemini.surveymanagementsystem.service.RespondentService;
import com.capgemini.surveymanagementsystem.service.Service;
import com.capgemini.surveymanagementsystem.service.SurveyorService;

public class RespondentController {
	static Scanner scanner = new Scanner(System.in);
	static Service service = Factory.serviceInstance();
	static final Logger logger = Logger.getLogger(RespondentController.class);
	static RespondentService respondentService = Factory.respondentServiceInstance();
	static SurveyorService surveyorService = Factory.surveyorServiceInstance();
	static AdminService adminService = Factory.adminServiceInstance();

	private RespondentController() {
	}

	/**
	 * this method is used to access respondent module with login credentials
	 * 
	 * @RespondentNotFoundException
	 * 
	 */

	public static void respondent() {
		int count = 0;
		logger.info("Enter loginId");
		String loginId = scanner.nextLine();
		while (!service.validateLoginId(loginId)) {
			logger.error("enter valid loginId [length must contains 5-18 (no space)]");
			loginId = scanner.nextLine();
		}
		logger.info("Enter your Password");
		String password = scanner.nextLine();
		while (!service.validatePassword(password)) {
			logger.error("enter valid password [should contain caps,small-char,@ symbol]");
			password = scanner.nextLine();
		}
		if (respondentService.requestLogin(loginId, password)) {

			logger.info("Login successful");
			boolean flag = true;
			do {
				logger.info("1.list of surveys");
				logger.info("2.update details");
				logger.info("3.logout");
				String choose = scanner.nextLine();
				while (!service.validateChoice(choose)) {
					logger.error(" enter valid choice  ");
					choose = scanner.nextLine();
				}
				int select = Integer.parseInt(choose);
				switch (select) {
				case 1:
					logger.info("list of surveys eligible");
					logger.info("-------------------------");
					logger.info("Survey names	   SurveyId's     Survey Start date     Survey Expired date");
					SurveyTopics survey1 = respondentService.requestRespondentEligibleSurveys1(loginId);
					if (survey1 == null) {
						logger.info(" not assigned ");
					} else {
						logger.info(survey1.getSurveyName() + "   " + survey1.getSurveyId() + "          "
								+ survey1.getFromDate() + "          " + survey1.getToDate());
					}
					SurveyTopics survey2 = respondentService.requestRespondentEligibleSurveys2(loginId);
					if (survey2 == null) {
						logger.info(" not assigned ");
					} else {
						logger.info(survey2.getSurveyName() + "   " + survey2.getSurveyId() + "          "
								+ survey2.getFromDate() + "          " + survey2.getToDate());
					}
					logger.info("                                 ");
					logger.info("list of responded surveys");
					List<SurveyTopics> survey3 = respondentService.requestResponsedSurveys(loginId);
					if (survey3 == null) {
						logger.info("not yet responded any surveys");
					} else {
						for (SurveyTopics surveyTopicsInfo : survey3) {
							logger.info(surveyTopicsInfo.getSurveyName() + "    " + surveyTopicsInfo.getSurveyId());
						}
					}
					logger.info("---------------------------");
					logger.info("enter surveyId [length must contains 5-18 (no space)]");
					String surveyId = scanner.nextLine();
					while (!service.validateLoginId(surveyId)) {
						logger.error("enter valid surveyId [length must contains 5-18 (no space)]");
						surveyId = scanner.nextLine();
					}
					int count1 = 0;
					int count11 = 0;
					int count111 = 0;
					int expires = 0;
					String surveyName = null;
					for (SurveyTopics surveyTopicsInfo : surveyorService.requestGetAllSurveys()) {
						if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId)) {
							surveyName = surveyTopicsInfo.getSurveyName();
						}
						if (surveyTopicsInfo.getSurveyId().contentEquals(surveyId)) {
							count111++;
							if (!LocalDate.now().isAfter(surveyTopicsInfo.getToDate())
									&& !LocalDate.now().isBefore(surveyTopicsInfo.getFromDate())) {
								expires++;
								if (respondentService.requestResponseVerification(loginId, surveyId)) {
									count1++;
									if (respondentService.requestTest(loginId, surveyId)) {
										count11++;
										List<Questions> testQuestionsList = surveyorService.questionsTest(surveyId,
												loginId);
										int questionNo = 0;
										for (Questions questionsInfo : testQuestionsList) {
											int option1 = 0;
											int option2 = 0;
											int option3 = 0;
											int option4 = 0;
											String question = null;
											String optionA = null;
											String optionB = null;
											String optionC = null;
											String optionD = null;
											questionNo++;
											if (questionNo == 5) {
												questionNo = 1;
											}
											if (questionsInfo.getSurveyId().contentEquals(surveyId)
													&& questionsInfo.getQuestionNumber() == questionNo) {
												question = questionsInfo.getQuestion();
												optionA = "a." + questionsInfo.getOptionA();
												optionB = "b." + questionsInfo.getOptionB();
												optionC = "c." + questionsInfo.getOptionC();
												optionD = "d." + questionsInfo.getOptionD();
												logger.info(questionNo + "." + questionsInfo.getQuestion());
												logger.info("      ");
												logger.info("1." + questionsInfo.getOptionA());
												logger.info("2." + questionsInfo.getOptionB());
												logger.info("3." + questionsInfo.getOptionC());
												logger.info("4." + questionsInfo.getOptionD());
												logger.info("            ");
												logger.info("choose your option");
												String choose2 = scanner.nextLine();
												while (!service.validateQuestionNumber(choose2)) {
													logger.error("enter valid choicen [1-4]");
													choose2 = scanner.nextLine();
												}
												int select2 = Integer.parseInt(choose2);
												switch (select2) {
												case 1:
													option1++;
													break;
												case 2:
													option2++;
													break;
												case 3:
													option3++;
													break;
												case 4:
													option4++;
													break;
												default:
													logger.error("enter valid choice");
													break;
												}
												surveyorService.getResult(questionNo, surveyId, question, optionA,
														optionB, optionC, optionD, loginId, option1, option2, option3,
														option4);

											}
										}
										logger.info("survey completed your answers saved");
										String respondentName = null;
										for (Respondent respondentInfo : respondentService.requestGetRespondentList()) {
											if (respondentInfo.getLoginId().contentEquals(loginId)) {
												respondentName = respondentInfo.getName();
											}
										}
										String notify = surveyName + " got response from respondent: " + respondentName+"("+loginId+")"
												+ " on " + LocalDate.now();
										adminService.notification(notify);
										surveyorService.notification(notify);
									} else {
										try {
											if (count11 == 0) {
												throw new SurveyNotFoundException(
														"you are not eligible for this Survey");
											}
										} catch (SurveyNotFoundException e) {
											logger.error(e.getMessage());
										}
									}
								} else {
									try {
										if (count1 == 0) {
											throw new NotEligibleForSurveyException(
													"you already gave responce to this survey");
										}
									} catch (NotEligibleForSurveyException e) {
										logger.error(e.getMessage());
									}
								}
							}
							if (expires == 0) {
								if (!LocalDate.now().isBefore(surveyTopicsInfo.getFromDate())) {
									logger.info("survey expired");
								}
								if (!LocalDate.now().isAfter(surveyTopicsInfo.getToDate())) {
									logger.info("survey not yet started");
								}
							}
						}
					}
					if (count111 == 0) {
						logger.error("survey not found");
					}
					break;
				case 2:
					update(loginId);
					break;
				case 3:
					logger.info("logged out");
					flag = false;
					break;
				default:
					logger.error("please enter valid choice from [1-3]");
					break;
				}
			} while (flag);
		} else {
			try {
				if (count == 0) {
					throw new InvalidRespondentException("login failed");
				}
			} catch (InvalidRespondentException e) {
				logger.error(e.getMessage());
			}
			boolean forgot = true;
			do {
				logger.info("1.Try login again");
				logger.info("2.forgot password");
				logger.info("3.home");
				String choose = scanner.nextLine();
				while (!service.validateChoice(choose)) {
					logger.error("enter valid choice from [1-3]");
					choose = scanner.nextLine();
				}
				int select = Integer.parseInt(choose);
				switch (select) {
				case 1:
					respondent();
					forgot = false;
					break;
				case 2:
					logger.info("Enter loginId");
					String loginId2 = scanner.nextLine();
					while (!service.validateLoginId(loginId2)) {
						logger.error("enter valid loginId [length must contains 5-18 (no space)]");
						loginId2 = scanner.nextLine();
					}
					logger.info("enter mailId");
					String mailId = scanner.nextLine();
					while (!service.validateGmail(mailId)) {
						logger.error("enter valid mail ID");
						mailId = scanner.nextLine();
					}
					if (respondentService.requestForgotPassword(loginId2, mailId)) {
						logger.info("enter new password");
						String newPassword = scanner.nextLine();
						while (!service.validatePassword(newPassword)) {
							logger.error("enter valid password [should contain caps,small-char,@ symbol]");
							newPassword = scanner.nextLine();
						}
						if (respondentService.requestSetPassword(loginId2, mailId, newPassword)) {
							logger.info("your password changed successfully");
							logger.info("login with your new Password");
							respondent();
							forgot = false;
							break;
						} else {
							logger.info("failed to change password");
						}
					} else {
						logger.error("input details not matched with system records");
						forgot = false;
						break;
					}
					break;
				case 3:
					forgot = false;
					break;
				default:
					logger.error("enter valid choice");
					break;
				}
			} while (forgot);
		}
	}

	public static void update(String loginId) {
		try {
			if (!respondentService.requestVerifyLoginId(loginId)) {
				logger.info("enter name [should be first and last name (only chars)]");
				String name = scanner.nextLine();
				while (!service.validateName(name)) {
					logger.error("enter valid name [should be first and last name (only chars)]");
					name = scanner.nextLine();
				}
				logger.info("enter Phone Number [must contains 10 digits]");
				String number = scanner.nextLine();
				while (!service.validatePhoneNumber(number)) {
					logger.error("enter valid phone number [must contains 10 digits]");
					number = scanner.nextLine();
				}
				long phoneNumber = Long.parseLong(number);
				while (!respondentService.requestVerifyContact(phoneNumber)) {
					logger.error("Phone number already exists try different number");
					number = scanner.nextLine();
					while (!service.validatePhoneNumber(number)) {
						logger.error("enter valid phone number [must contains 10 digits]");
						number = scanner.nextLine();
					}
					phoneNumber = Long.parseLong(number);
				}
				logger.info("enter Gmail [ ex: survey@gmail.com ]");
				String gmail = scanner.nextLine();
				while (!service.validateGmail(gmail)) {
					logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
					gmail = scanner.nextLine();
				}
				while (!respondentService.requestVerifyGmail(gmail)) {
					logger.error("gmail already exists try different gmail");
					gmail = scanner.nextLine();
					while (!service.validateGmail(gmail)) {
						logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
						gmail = scanner.nextLine();
					}
				}
				logger.info("enter password[must contains Symbol,digit,first char Caps & length [6-20]]");
				String newPassword = scanner.nextLine();
				while (!service.validatePassword(newPassword)) {
					logger.error("enter valid password[must contains Symbol,digit,first char Caps & length [6-20]]");
					newPassword = scanner.nextLine();
				}
				if (respondentService.requestUpdate(loginId, name, phoneNumber, gmail, loginId, newPassword)) {
					logger.info("details updated successfully");
					String notify = "Respondent : "+name+"("+loginId+")"+" updated his/her details on "+ LocalDate.now();
					adminService.notification(notify);
					surveyorService.notification(notify);
				} else {
					logger.info("failed to update details");
				}
			} else {
				throw new InvalidRespondentException("Respondent not found");
			}
		} catch (InvalidRespondentException e) {
			logger.error(e.getMessage());
		}
	}

}
