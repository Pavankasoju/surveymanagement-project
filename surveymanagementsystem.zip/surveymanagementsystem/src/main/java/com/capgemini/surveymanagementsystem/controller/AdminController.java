package com.capgemini.surveymanagementsystem.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.Surveyor;
import com.capgemini.surveymanagementsystem.exceptions.InvalidAdminException;
import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.service.AdminService;
import com.capgemini.surveymanagementsystem.service.RespondentService;
import com.capgemini.surveymanagementsystem.service.Service;
import com.capgemini.surveymanagementsystem.service.SurveyorService;

/**
 * 
 * this method is used to access the admin module operations by admin
 * credentials
 * 
 * @author Pavan Kumar
 * @IOException
 * @AdminNotFoundException
 *
 */
public class AdminController {

	private AdminController() {
	}

	static Scanner scanner = new Scanner(System.in);
	static final Logger logger = Logger.getLogger(AdminController.class);
	static Service service = Factory.serviceInstance();
	static AdminService adminService = Factory.adminServiceInstance();
	static RespondentService respondentService = Factory.respondentServiceInstance();
	static SurveyorService surveyorService = Factory.surveyorServiceInstance();

	public static void admin() {
		int count = 0;
		logger.info("Enter loginId");
		String loginId = scanner.nextLine();
		while (!service.validateLoginId(loginId)) {
			logger.error("enter valid loginId [length must contains 5-18 (no space)]");
			loginId = scanner.nextLine();
		}
		logger.info("Enter your Password");
		String password = scanner.nextLine();
		while (!service.validatePassword(password)) {
			logger.error("enter valid password [should contain caps,small-char,@ symbol]");
			password = scanner.nextLine();
		}
		try {
			if (adminService.requestLogin(loginId, password)) {
				logger.info(" Login successful");
				boolean flag = true;
				boolean check = true;
				int serial2 = 0;
				do {
					
					while (check) {
						for (String notifications : adminService.requestNewNotification()) {
							serial2++;
							notifications.chars();
						}
						check = false;
					}

					logger.info("==========================");
					logger.info("1.notifications(" + serial2 + ")");
					logger.info("2.organise Respondents");
					logger.info("3.organise Surveyors");
					logger.info("4.Organise Surveys");
					logger.info("5.view survey reports");
					logger.info("6.update my details");
					logger.info("7.logout");
					logger.info("==========================");
					String choice = scanner.nextLine();
					while (!service.validateChoice(choice)) {
						logger.error("enter valid choice [1-6]");
						choice = scanner.nextLine();
					}
					int select = Integer.parseInt(choice);
					boolean flag1 = true;
					switch (select) {
					case 1:

						logger.info("------------New------------");
						if (adminService.requestNewNotification().isEmpty()) {
							logger.info("Empty");
						} else {
							int serial = 0;
							for (String notifications : adminService.requestNewNotification()) {
								serial++;
								logger.info(serial + ". " + notifications);
							}
						}
						serial2 = 0;
						logger.info("---------------------------\n ");
						check = false;
						boolean notify = true;
						do {
							logger.info("1.All notifications");
							logger.info("2.delete notifications");
							logger.info("3.back");
							String choose = scanner.nextLine();
							while (!service.validateChoice(choose)) {
								logger.error("enter valid choice[1-3]");
								choose = scanner.nextLine();
							}
							int set = Integer.parseInt(choose);
							switch (set) {
							case 1:
								logger.info("-------------All-----------");
								Collections.reverse(adminService.requestOldNotification());
								if (adminService.requestOldNotification().isEmpty()) {
									logger.info("Empty");
								} else {
									int serial = 0;
									for (String notifications : adminService.requestOldNotification()) {
										serial++;
										logger.info(serial + ". " + notifications);
									}
								}
								Collections.reverse(adminService.requestOldNotification());
								logger.info("---------------------------\n ");
								break;
							case 2:
								if (adminService.requestOldNotification().isEmpty()) {
									logger.info("notifications box is empty\n ");
								} else {
									if (adminService.requestDeleteNotifications()) {
										logger.info("notifications deleted successfully\n ");
									} else {
										logger.info("notifications deleted failed");
									}
								}
								break;
							case 3:
								notify = false;
								break;
							default:
								logger.info("enter valid choice[1-3]");
								break;
							}
						} while (notify);
						break;

					case 2:
						do {
							logger.info("1.Add respondent");
							logger.info("2.view respondents");
							logger.info("3.update respondents");
							logger.info("4.delete respondent");
							logger.info("5.login as respondent");
							logger.info("6.back");
							String choice1 = scanner.nextLine();
							while (!service.validateChoice(choice1)) {
								logger.error("enter valid choice  ");
								choice1 = scanner.nextLine();
							}
							int select1 = Integer.parseInt(choice1);
							switch (select1) {
							case 1:
								logger.info("Respodent Registration");
								logger.info("                      ");
								logger.info("enter name [should be first and last name (only chars) ]");
								String name = scanner.nextLine();
								while (!service.validateName(name)) {
									logger.error("enter valid name [should be first and last name (only chars) ]");
									name = scanner.nextLine();
								}
								logger.info("enter Phone Number [must contains 10 digits]");
								String number = scanner.nextLine();
								while (!service.validatePhoneNumber(number)) {
									logger.error("enter valid phone number [must contains 10 digits]");
									number = scanner.nextLine();
								}
								long phoneNumber = Long.parseLong(number);
								while (!respondentService.requestVerifyContact(phoneNumber)) {
									logger.error("Phone number already exists try different number");
									number = scanner.nextLine();
									while (!service.validatePhoneNumber(number)) {
										logger.error("enter valid phone number [must contains 10 digits]");
										number = scanner.nextLine();
									}
									phoneNumber = Long.parseLong(number);
								}
								logger.info("enter Gmail [ ex: survey@gmail.com ]");
								String gmail = scanner.nextLine();
								while (!service.validateGmail(gmail)) {
									logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
									gmail = scanner.nextLine();
								}
								while (!respondentService.requestVerifyGmail(gmail)) {
									logger.error("Gmail already exists try different gmail");
									gmail = scanner.nextLine();
									while (!service.validateGmail(gmail)) {
										logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
										gmail = scanner.nextLine();
									}
								}
								logger.info("enter loginId [length must contains [5-18]");
								String newLoginId = scanner.nextLine();
								while (!service.validateLoginId(newLoginId)) {
									logger.error("enter valid loginId [length must contains [5-18]");
									newLoginId = scanner.nextLine();
								}
								while (!respondentService.requestVerifyLoginId(newLoginId)) {
									logger.error("loginId already exists try different loginId");
									newLoginId = scanner.nextLine();
									while (!service.validateLoginId(newLoginId)) {
										logger.error("enter valid loginId [length must contains [5-18]");
										newLoginId = scanner.nextLine();
									}
								}
								logger.info(
										"enter  password [must contains Symbol,digit,first char Caps & length [6-20]]");
								String newPassword = scanner.nextLine();
								while (!service.validatePassword(newPassword)) {
									logger.error(
											"enter valid password[must contains Symbol,digit,first char Caps & length [6-20]]");
									newPassword = scanner.nextLine();
								}
								logger.info("enter respondent eligible surveyId1 [length must contains [5-18]");
								String surveyId1 = scanner.nextLine();
								while (!service.validateLoginId(surveyId1)) {
									logger.error("enter valid surveyId [length must contains [5-18]");
									surveyId1 = scanner.nextLine();
								}
								while (surveyorService.requestVerifySurvey(surveyId1)) {
									logger.error("survey not found, enter valid surveyId");
									surveyId1 = scanner.nextLine();
									while (!service.validateLoginId(surveyId1)) {
										logger.error("enter valid surveyId [length must contains [5-18]");
										surveyId1 = scanner.nextLine();
									}
								}
								logger.info("enter respondent eligible surveyId2 [length must contains [5-18]");
								String surveyId2 = scanner.nextLine();
								while (!service.validateLoginId(surveyId2)) {
									logger.error("enter valid surveyId [length must contains [5-18]");
									surveyId2 = scanner.nextLine();
								}
								while (surveyId1.contentEquals(surveyId2)) {
									logger.error("Already assigned set another surveyId");
									surveyId2 = scanner.nextLine();
									while (!service.validateLoginId(surveyId2)) {
										logger.error("enter valid surveyId [length must contains [5-18]");
										surveyId2 = scanner.nextLine();
									}
								}
								while (surveyorService.requestVerifySurvey(surveyId2)) {
									logger.error("survey not found, Enter valid surveyId");
									surveyId2 = scanner.nextLine();
									while (!service.validateLoginId(surveyId2)) {
										logger.error("enter valid surveyId [length must contains [5-18]");
										surveyId2 = scanner.nextLine();
									}
								}
								if (respondentService.requestRegestration(name, gmail, phoneNumber, newLoginId,
										newPassword, surveyId1, surveyId2)) {
									logger.info("respondent regestration successfull");
								} else {
									logger.info("regestration failed");
								}
								break;
							case 2:
								boolean two = true;
								do {
									logger.info("1.view Respondents");
									logger.info("2.view Respondent with full details");
									logger.info("3.back   ");
									String choose22 = scanner.nextLine();
									while (!service.validateChoice(choose22)) {
										logger.error("enter valid choice   ");
										choose22 = scanner.nextLine();
									}
									int select22 = Integer.parseInt(choose22);
									switch (select22) {
									case 1:
										logger.info("respondent Id's");
										logger.info("-----------------------");
										for (Respondent respondent : respondentService.requestGetRespondentList()) {
											logger.error(respondent.getLoginId());
										}
										logger.info("-----------------------");

										logger.info("enter loginId to view full details");
										String loginId2 = scanner.nextLine();
										while (!service.validateLoginId(loginId2)) {
											logger.error("enter your loginId [length must contains [5-18]");
											loginId2 = scanner.nextLine();
										}
										int count2 = 0;
										for (Respondent respondent : respondentService.requestGetRespondentList()) {
											if (respondent.getLoginId().contentEquals(loginId2)) {
												count2++;
												logger.info(respondent);
												logger.info("#.Eligible surveys : " + respondent.getSurveyId1());
												logger.info("#.Eligible surveys : " + respondent.getSurveyId2()+"\n");
												
											}
										}
										if (count2 == 0) {
											logger.error("respondent not found");
										}

										break;
									case 2:
										logger.info("list of respondents with full details");
										for (Respondent respondent : respondentService.requestGetRespondentList()) {
											logger.info(respondent);
											logger.info("eligible surveys : " + respondent.getSurveyId1());
											logger.info("eligible surveys : " + respondent.getSurveyId2());
										}
										logger.info("-------------------------------------");
										break;
									case 3:
										two = false;
										break;
									default:
										logger.error("enter valid choice [1-3]");
										break;
									}
								} while (two);
								break;
							case 3:
								logger.info("list of respondents");
								logger.info("respondents         respondent Id's");
								for (Respondent respondent : respondentService.requestGetRespondentList()) {
									logger.info(respondent.getName() + "----" + respondent.getLoginId());
								}
								logger.info("-----------------------------------");
								logger.info("              ");
								logger.info("enter respondent loginId");
								String loginId13 = scanner.nextLine();
								while (!service.validateLoginId(loginId13)) {
									logger.error("enter valid loginId");
									loginId13 = scanner.nextLine();
								}
								RespondentController.update(loginId13);
								break;
							case 4:
								logger.info("enter respondent loginId to delete");
								String loginId14 = scanner.nextLine();
								while (!service.validateLoginId(loginId14)) {
									logger.error("enter valid loginId");
									loginId14 = scanner.nextLine();
								}
								if (respondentService.requestDelete(loginId14)) {
									logger.info("deleted successfully");
								} else {
									logger.info("failed to delete");
								}
								break;
							case 5:
								logger.info("respondent Id's          password ");
								logger.info("-----------------------");
								for (Respondent respondent : respondentService.requestGetRespondentList()) {
									logger.error(respondent.getLoginId() + "      " + respondent.getPassword());
								}
								logger.info("-----------------------");
								RespondentController.respondent();
								break;
							case 6:
								flag1 = false;
								break;
							default:
								logger.error("enter valid choice [1-4]");
								break;
							}
						} while (flag1);
						break;
					case 3:
						boolean flag2 = true;
						do {
							logger.info("1.Add surveyor");
							logger.info("2.view surveyors");
							logger.info("3.update surveyor");
							logger.info("4.delete surveyor");
							logger.info("5.login as surveyor");
							logger.info("6.back");
							String choice2 = scanner.nextLine();
							while (!service.validateChoice(choice2)) {
								logger.error("enter valid choice");
								choice2 = scanner.nextLine();
							}
							int select2 = Integer.parseInt(choice2);
							switch (select2) {
							case 1:
								logger.info("surveyor Registration");
								logger.info("                      ");
								logger.info("enter name [should be first and last name (only chars)]");
								String name = scanner.nextLine();
								while (!service.validateName(name)) {
									logger.error("enter valid name [should be first and last name (only chars)]");
									name = scanner.nextLine();
								}
								logger.info("enter Phone Number [must contains 10 digits]");
								String number = scanner.nextLine();
								while (!service.validatePhoneNumber(number)) {
									logger.error("enter valid phone number [must contains 10 digits]");
									number = scanner.nextLine();
								}
								long phoneNumber = Long.parseLong(number);
								logger.info("enter Gmail [ ex: survey@gmail.com ]");
								String gmail = scanner.nextLine();
								while (!service.validateGmail(gmail)) {
									logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
									gmail = scanner.nextLine();
								}
								logger.info("enter loginId [length must contains [5-18]");
								String newLoginId = scanner.nextLine();
								while (!service.validateLoginId(newLoginId)) {
									logger.error("enter valid loginId [length must contains [5-18]");
									newLoginId = scanner.nextLine();
								}
								while (!surveyorService.requestVerifyLoginId(newLoginId)) {
									logger.error("loginId already exists try different loginId");
									newLoginId = scanner.nextLine();
									while (!service.validateLoginId(newLoginId)) {
										logger.error("enter valid loginId [length must contains [5-18]");
										newLoginId = scanner.nextLine();
									}
								}
								logger.info(
										"enter password[must contains Symbol,digit,first char Caps & length [6-20]]");
								String newPassword = scanner.nextLine();
								while (!service.validatePassword(newPassword)) {
									logger.error(
											"enter valid password[must contains Symbol,digit,first char Caps & length [6-20]]");
									newPassword = scanner.nextLine();
								}
								if (surveyorService.requestRegestration(name, gmail, phoneNumber, newLoginId,
										newPassword)) {
									logger.info("Surveyor regestration successfull");
								} else {
									logger.info("regestration failed");
								}
								break;
							case 2:
								boolean two = true;
								logger.info("list of surveyors");
								do {
									logger.info("1.view Surveyors");
									logger.info("2.view Surveyors with full details");
									logger.info("3.back     ");
									String choose22 = scanner.nextLine();
									while (!service.validateChoice(choose22)) {
										logger.error("enter valid choice");
										choose22 = scanner.nextLine();
									}
									int select22 = Integer.parseInt(choose22);
									switch (select22) {
									case 1:
										for (Surveyor surveyor : surveyorService.requestGetSurveyorList()) {
											logger.info(surveyor.getName() + "----" + surveyor.getLoginId());
										}
										logger.info("enter surveyId to view full details");
										String surveyId = scanner.nextLine();
										while (!service.validateLoginId(surveyId)) {
											logger.error("enter valid loginId");
											surveyId = scanner.nextLine();
										}
										int count22 = 0;
										for (Surveyor surveyor : surveyorService.requestGetSurveyorList()) {
											if (surveyor.getLoginId().contentEquals(surveyId)) {
												count22++;
												logger.info(surveyor);
											}
										}
										if (count22 == 0) {
											logger.info("survey not found");
										}
										break;
									case 2:
										for (Surveyor surveyor : surveyorService.requestGetSurveyorList()) {
											logger.info(surveyor);
										}
										break;
									case 3:
										two = false;
										break;
									default:
										logger.error("enter valid choice [1-3]");
										break;
									}
								} while (two);
								break;
							case 3:
								logger.info("list of surveyors");
								logger.info("surveyors         surveyor Id's");
								for (Surveyor surveyor : surveyorService.requestGetSurveyorList()) {
									logger.info(surveyor.getName() + "----" + surveyor.getLoginId());
								}
								logger.info("       ");
								logger.info("please enter surveyor loginId");
								String loginId23 = scanner.nextLine();
								while (!service.validateLoginId(loginId23)) {
									logger.error("enter valid loginId");
									loginId23 = scanner.nextLine();
								}
								SurveyorController.update(loginId23);
								break;
							case 4:
								logger.info("enter surveyor loginId to delete");
								String loginId14 = scanner.nextLine();
								while (!service.validateLoginId(loginId14)) {
									logger.error("enter valid loginId");
									loginId14 = scanner.nextLine();
								}
								if (surveyorService.requestDelete(loginId14)) {
									logger.info("deleted successfully");
								} else {
									logger.info("failed to delete");
								}
								break;
							case 5:
								logger.info("surveyor Id's            password ");
								logger.info("----------------------------");
								for (Surveyor surveyor : surveyorService.requestGetSurveyorList()) {
									logger.info(surveyor.getLoginId() + "----" + surveyor.getPassword());
								}
								logger.info("----------------------------");
								SurveyorController.surveyor();
								break;
							case 6:
								flag2 = false;
								break;
							default:
								logger.error("enter valid choice [1-4]");
								break;
							}
						} while (flag2);
						break;
					case 4:
						boolean flag3 = true;
						do {
							logger.info("1.create survey");
							logger.info("2.update survey");
							logger.info("3.delete survey");
							logger.info("4.list of surveys");
							logger.info("5.back");
							String choose3 = scanner.nextLine();
							while (!service.validateChoice(choose3)) {
								logger.error("enter valid choice");
								choose3 = scanner.nextLine();
							}
							Integer select3 = Integer.parseInt(choose3);
							switch (select3) {
							case 1:
								SurveyorController.createSurvey();
								break;
							case 2:
								SurveyorController.updateSurvey();
								break;
							case 3:
								SurveyorController.deleteSurvey();
								break;
							case 4:
								SurveyorController.viewSurvey();
								break;
							case 5:
								flag3 = false;
								break;
							default:
								logger.error("enter valid choice [1-5]");
								break;
							}
						} while (flag3);
						break;
					case 5:
						SurveyorController.viewResult();
						break;
					case 6:
						if (!adminService.adminVerifyLoginId(loginId)) {

							logger.info("enter your name [should be first and last name (only chars)]");
							String name13 = scanner.nextLine();
							while (!service.validateName(name13)) {
								logger.error("enter valid name [should be first and last name (only chars)]");
								name13 = scanner.nextLine();
							}
							logger.info("enter your Phone Number [must contains 10 digits]");
							String number13 = scanner.nextLine();
							while (!service.validatePhoneNumber(number13)) {
								logger.error("enter valid phone number [must contains 10 digits]");
								number13 = scanner.nextLine();
							}
							long phoneNumber13 = Long.parseLong(number13);
							logger.info("enter your Gmail [ ex: survey@gmail.com ]");
							String gmail13 = scanner.nextLine();
							while (!service.validateGmail(gmail13)) {
								logger.error("enter valid Gmail [ ex: survey@gmail.com ]");
								gmail13 = scanner.nextLine();
							}
							logger.info("enter password[must contains Symbol,digit,first char Caps & length [6-20]]");
							String newPassword13 = scanner.nextLine();
							while (!service.validatePassword(newPassword13)) {
								logger.error(
										"enter valid password[must contains Symbol,digit,first char Caps & length [6-20]]");
								newPassword13 = scanner.nextLine();
							}
							if (adminService.requestUpdate(loginId, name13, phoneNumber13, gmail13, loginId,
									newPassword13)) {
								logger.info("details updated successfully");
							} else {
								logger.info("failed to update details");
							}
						} else {
							logger.info("adminId not found");
						}
						break;
					case 7:
						logger.info("logout");
						flag = false;
						break;
					default:
						logger.error("enter valid choice");
						break;
					}
				} while (flag);
			} else {
				try {
					if (count == 0) {
						throw new InvalidAdminException();
					}
				} catch (InvalidAdminException e) {
					logger.info(e.getMessage());
				}
				boolean forgot = true;
				do {
					logger.info("1.Login again");
					logger.info("2.Forgot password");
					logger.info("3.Home");
					String choose = scanner.nextLine();
					while (!service.validateChoice(choose)) {
						logger.error("enter valid choice from [1-3]");
						choose = scanner.nextLine();
					}
					int select = Integer.parseInt(choose);
					switch (select) {
					case 1:
						admin();
						forgot = false;
						break;
					case 2:
						logger.info("Enter loginId");
						String loginId2 = scanner.nextLine();
						while (!service.validateLoginId(loginId2)) {
							logger.error("Enter valid loginId [length must contains 5-18 (no space)]");
							loginId2 = scanner.nextLine();
						}
						logger.info("Enter your mailId");
						String mailId = scanner.nextLine();
						while (!service.validateGmail(mailId)) {
							logger.error("Enter valid mail ID");
							mailId = scanner.nextLine();
						}
						if (adminService.requestForgotPassword(loginId2, mailId)) {
							logger.info("Enter new password");
							String newPassword = scanner.nextLine();
							while (!service.validatePassword(newPassword)) {
								logger.error("Enter valid password [should contain caps,small-char,@ symbol]");
								newPassword = scanner.nextLine();
							}
							if (adminService.requestSetPassword(loginId2, mailId, newPassword)) {
								logger.info("Your password changed successfully");
								logger.info("Login with your new Password");
								admin();
								forgot = false;
							} else {
								logger.info("Failed to change password");
							}
						} else {
							logger.error("Input details not matched with system records");
							forgot = false;
						}
						break;
					case 3:
						forgot = false;
						break;
					default:
						logger.error("Enter valid choice");
						break;
					}
				} while (forgot);
			}
		} catch (IOException e) {
			logger.error("Invalid credentials details not found");
		}
	}
}