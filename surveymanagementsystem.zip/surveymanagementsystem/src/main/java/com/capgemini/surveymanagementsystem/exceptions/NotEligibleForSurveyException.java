package com.capgemini.surveymanagementsystem.exceptions;

public class NotEligibleForSurveyException extends RuntimeException {

	/**
	 * this is the customized exceptions created by the programmer and handle the
	 * exceptions
	 */

	private static final long serialVersionUID = 1L;
	String message = "You are not eligible for Survey";

	/**
	 * this constructor will get call when exception throws and initialize exception
	 * message to respective variable
	 * 
	 * @param message
	 */

	public NotEligibleForSurveyException(String message) {
		super();
		this.message = message;
	}

	/**
	 * this method will get call whenever throw the exception
	 */
	@Override
	public String getMessage() {
		return message;
	}

}
