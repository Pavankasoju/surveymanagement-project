package com.capgemini.surveymanagementsystem.bean;

import java.io.Serializable;

public class Questions implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5421264089866697696L;

	public Questions() {

	}

	private String surveyId;
	private String question;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private int questionNumber;

	/**
	 * this method is used to get surveyId
	 * 
	 * @return String
	 */
	public String getSurveyId() {
		return surveyId;
	}

	/**
	 * this method is used to set surveyId
	 * 
	 * @param surveyId
	 */
	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}

	/**
	 * this method is used to get questionNumber
	 * 
	 * @return String
	 */
	public int getQuestionNumber() {
		return questionNumber;
	}

	/**
	 * this method is used to set questionNumber
	 * 
	 * @param questionNumber
	 */
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}

	/**
	 * this method is used to get question
	 * 
	 * @return String
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * this method is used to set question
	 * 
	 * @param question
	 */
	public void setQuestion(String question) {
		this.question = question;
	}

	/**
	 * this method is used to get option1
	 * 
	 * @return String
	 */
	public String getOptionA() {
		return optionA;
	}

	/**
	 * this method is used to set option1
	 * 
	 * @param optionA
	 */
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	/**
	 * this method is used to get option2
	 * 
	 * @return String
	 */
	public String getOptionB() {
		return optionB;
	}

	/**
	 * this method is used to set option2
	 * 
	 * @param optionB
	 */
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	/**
	 * this method is used to get option3
	 * 
	 * @return String
	 */
	public String getOptionC() {
		return optionC;
	}

	/**
	 * this method is used to set option3
	 * 
	 * @param optionC
	 */
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	/**
	 * this method is used to get option4
	 * 
	 * @return String
	 */
	public String getOptionD() {
		return optionD;
	}

	/**
	 * this method is used to set option4
	 * 
	 * @param optionD
	 */
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	@Override
	public String toString() {
		return "\n" + " ---------------------------------------------------" + "\n #.SurveyId = " + surveyId + "\n"
				+ questionNumber + "." + question + "\n a.Option = " + optionA + "\n" + " b.Option = " + optionB + "\n"
				+ " c.Option = " + optionC + "\n" + " d.Option = " + optionD + "\n"

				+ "-----------------------------------------------";
	}

}
