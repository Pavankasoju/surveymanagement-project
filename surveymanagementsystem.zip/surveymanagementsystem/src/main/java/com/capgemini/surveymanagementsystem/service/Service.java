package com.capgemini.surveymanagementsystem.service;

public interface Service {
	
	/**
	 * this is an interface for ServiceImpl, it contains twelve abstract methods
	 * 
	 * @author Pavan kumar
	 *
	 */

	public boolean validateName(String name);

	public boolean validateGmail(String gmail);

	public boolean validatePhoneNumber(String phoneNumber);

	public boolean validateDate(String date);

	public boolean validateChoice(String choice);

	public boolean validatePassword(String password);

	public boolean validateLoginId(String loginId);

	public boolean validateTitle(String title);

	public boolean validateDescription(String description);

	public boolean validateQuestion(String question);

	public boolean validateOption(String option);

	public boolean validateQuestionNumber(String questionNumber);

}
