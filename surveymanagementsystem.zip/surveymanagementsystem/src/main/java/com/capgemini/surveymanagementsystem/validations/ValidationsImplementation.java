package com.capgemini.surveymanagementsystem.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * this is the implementation class of Validations it contains all method
 * implementations
 * 
 * @author Pavan Kumar
 *
 */
public class ValidationsImplementation implements Validations {
	Pattern pat = null;
	Matcher mat = null;

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param name
	 */

	@Override
	public boolean nameValidation(String name) {
		pat = Pattern.compile("[a-z]{1}[a-z]*+\\s+[a-z]*");
		mat = pat.matcher(name);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param mail
	 */

	@Override
	public boolean gmailValidation(String gmail) {
		pat = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		mat = pat.matcher(gmail);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param contactNumber
	 */

	@Override
	public boolean phoneNumberValidation(String phoneNumber) {
		pat = Pattern.compile("^[6789]{1}\\d{9}$");
		mat = pat.matcher(phoneNumber);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param date
	 */

	@Override
	public boolean dateValidation(String date) {
		pat = Pattern.compile("^((19|2[0-9])[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$");
		mat = pat.matcher(date);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param choice
	 */

	@Override
	public boolean choiceValidate(String choice) {
		pat = Pattern.compile("[1-9]");
		mat = pat.matcher(choice);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param password
	 */

	@Override
	public boolean passwordValidation(String password) {
		pat = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
		mat = pat.matcher(password);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param loginId
	 */

	@Override
	public boolean loginIdValidation(String loginId) {
		pat = Pattern.compile("[1-9a-zA-Z]{1}[a-z0-9_-]{4,20}");
		mat = pat.matcher(loginId);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param title
	 */

	@Override
	public boolean surveyTitleValidation(String title) {
		pat = Pattern.compile("[1-9a-zA-Z]{1}[\\w+\\s+\\W]{4,30}");
		mat = pat.matcher(title);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param description
	 */

	@Override
	public boolean surveyDescriptionValidation(String description) {
		pat = Pattern.compile("[1-9a-zA-Z]{1}[\\w+\\s+\\W]{9,400}");
		mat = pat.matcher(description);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param question
	 */
        
	@Override
	public boolean questionValidation(String question) {
		pat = Pattern.compile("[1-9a-zA-Z]{1}[\\w+\\s+\\W]{9,200}");
		mat = pat.matcher(question);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param option
	 */

	@Override
	public boolean optionValidation(String option) {
		pat = Pattern.compile("[0-9a-zA-Z]{1}[\\w+\\s+\\W]{0,200}");
		mat = pat.matcher(option);
		return mat.matches();
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param number
	 */

	@Override
	public boolean questionNumberValidate(String questionNumber) {
		pat = Pattern.compile("[1-4]");
		mat = pat.matcher(questionNumber);
		return mat.matches();
	}

}