package com.capgemini.surveymanagementsystem.bean;

import java.io.Serializable;
import java.time.LocalDate;

public class SurveyTopics implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -173120336867031852L;

	public SurveyTopics() {

	}

	private String surveyName;
	private String description;
	private String surveyId;
	private LocalDate fromDate;
	private LocalDate toDate;

	/**
	 * this method is used to get surveyId
	 * 
	 * @return String
	 */
	public String getSurveyId() {
		return surveyId;
	}

	/**
	 * this method is used to set surveyId
	 * 
	 * @param surveyId
	 */
	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}

	/**
	 * this method is used to get surveyName
	 * 
	 * @return String
	 */
	public String getSurveyName() {
		return surveyName;
	}

	/**
	 * this method is used to set surveyName
	 * 
	 * @param surveyName
	 */
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}

	/**
	 * this method is used to get description
	 * 
	 * @return String
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * this method is used to set description
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * this method is used to get fromDate
	 * 
	 * @return LocalDate
	 */
	public LocalDate getFromDate() {
		return fromDate;
	}

	/**
	 * this method is used to set fromDate
	 * 
	 * @param fromDate
	 */
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * this method is used to get toDate
	 * 
	 * @return LocalDate
	 */
	public LocalDate getToDate() {
		return toDate;
	}

	/**
	 * this method is used to set toDate
	 * 
	 * @param toDate
	 */
	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	@Override
	public String toString() {
		return "\n" + " ---------------------------------------------------" + "\n 1.SurveyID = " + surveyId
				+ "\n 2.Survey name = " + surveyName + "\n" + " 3.Description = " + description + "\n"
				+ " 4.Strat Date = " + fromDate + "\n" + " 5.End Date = " + toDate + "\n"

				+ "-----------------------------------------------";
	}
}
