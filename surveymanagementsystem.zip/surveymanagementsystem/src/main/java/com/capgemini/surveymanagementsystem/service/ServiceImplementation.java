package com.capgemini.surveymanagementsystem.service;

import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.validations.Validations;

/**
 * this is the implementation class of Service it contains all method
 * implementations
 * this class is used to get the information from respective controllers and send information to Dao
 * 
 * @author Pavan Kumar
 *
 */
public class ServiceImplementation implements Service {

	Validations validation = Factory.validationsInstance();

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param name
	 */
	@Override
	public boolean validateName(String name) {
		return validation.nameValidation(name);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param mail
	 */
	@Override
	public boolean validateGmail(String gmail) {
		return validation.gmailValidation(gmail);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param phoneNumber
	 */
	@Override
	public boolean validatePhoneNumber(String phoneNumber) {
		return validation.phoneNumberValidation(phoneNumber);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param date
	 */
	@Override
	public boolean validateDate(String date) {
		return validation.dateValidation(date);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param choice
	 */
	@Override
	public boolean validateChoice(String choice) {
		return validation.choiceValidate(choice);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param password
	 */

	@Override
	public boolean validatePassword(String password) {
		return validation.passwordValidation(password);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param loginId
	 */
	@Override
	public boolean validateLoginId(String loginId) {
		return validation.loginIdValidation(loginId);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param title
	 */
	@Override
	public boolean validateTitle(String title) {
		return validation.surveyTitleValidation(title);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param description
	 */
	@Override
	public boolean validateDescription(String description) {
		return validation.surveyDescriptionValidation(description);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param question
	 */
	@Override
	public boolean validateQuestion(String question) {
		return validation.questionValidation(question);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param option
	 */
	@Override
	public boolean validateOption(String option) {
		return validation.optionValidation(option);
	}

	/**
	 * this method is to check whether the given String is matched or not
	 * 
	 * @param number
	 */
	@Override
	public boolean validateQuestionNumber(String questionNumber) {
		return validation.questionNumberValidate(questionNumber);
	}
}
