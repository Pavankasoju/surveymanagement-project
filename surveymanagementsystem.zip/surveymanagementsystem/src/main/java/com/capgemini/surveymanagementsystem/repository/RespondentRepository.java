package com.capgemini.surveymanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this class contains dummy data of Respondents
 * 
 * @author Admin
 *
 */
public class RespondentRepository {

	protected static List<Respondent> respondentList = new ArrayList<Respondent>();

	public List<Respondent> getRespondentList() {

		Respondent respondentInfo1 = Factory.respondentInfoInstance();
		Respondent respondentInfo2 = Factory.respondentInfoInstance();
		Respondent respondentInfo3 = Factory.respondentInfoInstance();
		Respondent respondentInfo4 = Factory.respondentInfoInstance();
		Respondent respondentInfo5 = Factory.respondentInfoInstance();
		Respondent respondentInfo6 = Factory.respondentInfoInstance();
		Respondent respondentInfo7 = Factory.respondentInfoInstance();
		Respondent respondentInfo8 = Factory.respondentInfoInstance();
		Respondent respondentInfo9 = Factory.respondentInfoInstance();
		Respondent respondentInfo10 = Factory.respondentInfoInstance();
		Respondent respondentInfo11 = Factory.respondentInfoInstance();
		Respondent respondentInfo12 = Factory.respondentInfoInstance();
		Respondent respondentInfo13 = Factory.respondentInfoInstance();
		Respondent respondentInfo14 = Factory.respondentInfoInstance();
		Respondent respondentInfo15 = Factory.respondentInfoInstance();
		Respondent respondentInfo16 = Factory.respondentInfoInstance();
		Respondent respondentInfo17 = Factory.respondentInfoInstance();
		Respondent respondentInfo18 = Factory.respondentInfoInstance();
		Respondent respondentInfo19 = Factory.respondentInfoInstance();
		Respondent respondentInfo20 = Factory.respondentInfoInstance();

		respondentInfo1.setSurveyId1("flipkart555");
		respondentInfo1.setSurveyId2("freekart555");
		respondentInfo1.setName("one one");
		respondentInfo1.setPhoneNumber(9876543201l);
		respondentInfo1.setMail("one@gmail.com");
		respondentInfo1.setLoginId("one-one");
		respondentInfo1.setPassword("One@123");

		respondentInfo2.setSurveyId1("flipkart555");
		respondentInfo2.setSurveyId2("freekart555");
		respondentInfo2.setName("two two");
		respondentInfo2.setPhoneNumber(9876543202l);
		respondentInfo2.setMail("two@gmail.com");
		respondentInfo2.setLoginId("two-two");
		respondentInfo2.setPassword("Two@123");

		respondentInfo3.setSurveyId1("flipkart555");
		respondentInfo3.setSurveyId2("freekart555");
		respondentInfo3.setName("three three");
		respondentInfo3.setPhoneNumber(9876543203l);
		respondentInfo3.setMail("three@gmail.com");
		respondentInfo3.setLoginId("three-three");
		respondentInfo3.setPassword("Three@123");

		respondentInfo4.setSurveyId1("flipkart555");
		respondentInfo4.setSurveyId2("freekart555");
		respondentInfo4.setName("four four");
		respondentInfo4.setPhoneNumber(9876543204l);
		respondentInfo4.setMail("four@gmail.com");
		respondentInfo4.setLoginId("four-four");
		respondentInfo4.setPassword("Four@123");

		respondentInfo5.setSurveyId1("flipkart555");
		respondentInfo5.setSurveyId2("freekart555");
		respondentInfo5.setName("five five");
		respondentInfo5.setPhoneNumber(9876543205l);
		respondentInfo5.setMail("five@gmail.com");
		respondentInfo5.setLoginId("five-five");
		respondentInfo5.setPassword("Five@123");

		respondentInfo6.setSurveyId1("amazon555");
		respondentInfo6.setSurveyId2("americanswan555");
		respondentInfo6.setName("six six");
		respondentInfo6.setPhoneNumber(9876543206l);
		respondentInfo6.setMail("six@gmail.com");
		respondentInfo6.setLoginId("six-six");
		respondentInfo6.setPassword("Six@123");

		respondentInfo7.setSurveyId1("amazon555");
		respondentInfo7.setSurveyId2("americanswan555");
		respondentInfo7.setName("seven seven");
		respondentInfo7.setPhoneNumber(9876543207l);
		respondentInfo7.setMail("seven@gmail.com");
		respondentInfo7.setLoginId("seven-seven");
		respondentInfo7.setPassword("Seven@123");

		respondentInfo8.setSurveyId1("amazon555");
		respondentInfo8.setSurveyId2("americanswan555");
		respondentInfo8.setName("eight eight");
		respondentInfo8.setPhoneNumber(9876543208l);
		respondentInfo8.setMail("eight@gmail.com");
		respondentInfo8.setLoginId("eight-eight");
		respondentInfo8.setPassword("Eight@123");

		respondentInfo9.setSurveyId1("amazon555");
		respondentInfo9.setSurveyId2("americanswan555");
		respondentInfo9.setName("nine nine");
		respondentInfo9.setPhoneNumber(9876543209l);
		respondentInfo9.setMail("nine@gmail.com");
		respondentInfo9.setLoginId("nine-nine");
		respondentInfo9.setPassword("Nine@123");

		respondentInfo10.setSurveyId1("amazon555");
		respondentInfo10.setSurveyId2("americanswan555");
		respondentInfo10.setName("ten ten");
		respondentInfo10.setPhoneNumber(9876543210l);
		respondentInfo10.setMail("ten@gmail.com");
		respondentInfo10.setLoginId("ten-ten");
		respondentInfo10.setPassword("Ten@123");

		respondentInfo11.setSurveyId1("myntra555");
		respondentInfo11.setSurveyId2("mirraw555");
		respondentInfo11.setName("eleven eleven");
		respondentInfo11.setPhoneNumber(9876543211l);
		respondentInfo11.setMail("eleven@gmail.com");
		respondentInfo11.setLoginId("eleven-eleven");
		respondentInfo11.setPassword("Eleven@123");

		respondentInfo12.setSurveyId1("myntra555");
		respondentInfo12.setSurveyId2("mirraw555");
		respondentInfo12.setName("twelve twelve");
		respondentInfo12.setPhoneNumber(9876543212l);
		respondentInfo12.setMail("twelve@gmail.com");
		respondentInfo12.setLoginId("twelve-twelve");
		respondentInfo12.setPassword("Twelve@123");

		respondentInfo13.setSurveyId1("myntra555");
		respondentInfo13.setSurveyId2("mirraw555");
		respondentInfo13.setName("thirteen thirteen");
		respondentInfo13.setPhoneNumber(9876543213l);
		respondentInfo13.setMail("thirteen@gmail.com");
		respondentInfo13.setLoginId("thirteen-thirteen");
		respondentInfo13.setPassword("Thirteen@123");

		respondentInfo14.setSurveyId1("myntra555");
		respondentInfo14.setSurveyId2("mirraw555");
		respondentInfo14.setName("fourteen fourteen");
		respondentInfo14.setPhoneNumber(9876543214l);
		respondentInfo14.setMail("fourteen@gmail.com");
		respondentInfo14.setLoginId("fourteen-fourteen");
		respondentInfo14.setPassword("Fourteen@123");

		respondentInfo15.setSurveyId1("myntra555");
		respondentInfo15.setSurveyId2("mirraw555");
		respondentInfo15.setName("fifteen fifteen");
		respondentInfo15.setPhoneNumber(9876543215l);
		respondentInfo15.setMail("fifteen@gmail.com");
		respondentInfo15.setLoginId("fifteen-fifteen");
		respondentInfo15.setPassword("Fifteen@123");

		respondentInfo16.setSurveyId1("ajio555");
		respondentInfo16.setSurveyId2("abof555");
		respondentInfo16.setName("sixteen sixteen");
		respondentInfo16.setPhoneNumber(9876543216l);
		respondentInfo16.setMail("sixteen@gmail.com");
		respondentInfo16.setLoginId("sixteen-sixteen");
		respondentInfo16.setPassword("Sixteen@123");

		respondentInfo17.setSurveyId1("ajio555");
		respondentInfo17.setSurveyId2("abof555");
		respondentInfo17.setName("seventeen seventeen");
		respondentInfo17.setPhoneNumber(9876543217l);
		respondentInfo17.setMail("seventeen@gmail.com");
		respondentInfo17.setLoginId("seventeen-seventeen");
		respondentInfo17.setPassword("Seventeen@123");

		respondentInfo18.setSurveyId1("ajio555");
		respondentInfo18.setSurveyId2("abof555");
		respondentInfo18.setName("eighteen eighteen");
		respondentInfo18.setPhoneNumber(9876543218l);
		respondentInfo18.setMail("eighteen@gmail.com");
		respondentInfo18.setLoginId("eighteen-eighteen");
		respondentInfo18.setPassword("Eighteen@123");

		respondentInfo19.setSurveyId1("ajio555");
		respondentInfo19.setSurveyId2("abof555");
		respondentInfo19.setName("ninteen ninteen");
		respondentInfo19.setPhoneNumber(9876543219l);
		respondentInfo19.setMail("ninteen@gmail.com");
		respondentInfo19.setLoginId("ninteen-ninteen");
		respondentInfo19.setPassword("Ninteen@123");

		respondentInfo20.setSurveyId1("ajio555");
		respondentInfo20.setSurveyId2("abof555");
		respondentInfo20.setName("twenty twenty");
		respondentInfo20.setPhoneNumber(9876543220l);
		respondentInfo20.setMail("twenty@gmail.com");
		respondentInfo20.setLoginId("twenty-twenty");
		respondentInfo20.setPassword("Twenty@123");

		respondentList.add(respondentInfo1);
		respondentList.add(respondentInfo2);
		respondentList.add(respondentInfo3);
		respondentList.add(respondentInfo4);
		respondentList.add(respondentInfo5);
		respondentList.add(respondentInfo6);
		respondentList.add(respondentInfo7);
		respondentList.add(respondentInfo8);
		respondentList.add(respondentInfo9);
		respondentList.add(respondentInfo10);
		respondentList.add(respondentInfo11);
		respondentList.add(respondentInfo12);
		respondentList.add(respondentInfo13);
		respondentList.add(respondentInfo14);
		respondentList.add(respondentInfo15);
		respondentList.add(respondentInfo16);
		respondentList.add(respondentInfo17);
		respondentList.add(respondentInfo18);
		respondentList.add(respondentInfo19);
		respondentList.add(respondentInfo20);

		return respondentList;

	}

}
