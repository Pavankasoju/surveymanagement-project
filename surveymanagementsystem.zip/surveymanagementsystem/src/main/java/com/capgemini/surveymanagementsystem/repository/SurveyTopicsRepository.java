package com.capgemini.surveymanagementsystem.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this class contains dummy data of Survey Topics
 * 
 * @author Admin
 *
 */
public class SurveyTopicsRepository {

	protected static List<SurveyTopics> surveyTopicsList = new ArrayList<SurveyTopics>();

	public List<SurveyTopics> getSurveyTopicsList() {

		SurveyTopics surveyTopicsInfo1 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo2 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo3 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo4 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo5 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo6 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo7 = Factory.surveyTopicsInfoInstance();
		SurveyTopics surveyTopicsInfo8 = Factory.surveyTopicsInfoInstance();

		surveyTopicsInfo1.setSurveyId("flipkart555");
		surveyTopicsInfo1.setSurveyName("Flipkart survey");
		surveyTopicsInfo1.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo1.setFromDate(LocalDate.of(2020, 05, 15));
		surveyTopicsInfo1.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo2.setSurveyId("freekart555");
		surveyTopicsInfo2.setSurveyName("Freekart survey");
		surveyTopicsInfo2.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo2.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo2.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo3.setSurveyId("amazon555");
		surveyTopicsInfo3.setSurveyName("Amazon survey");
		surveyTopicsInfo3.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo3.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo3.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo4.setSurveyId("americanswan555");
		surveyTopicsInfo4.setSurveyName("americanswan survey");
		surveyTopicsInfo4.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo4.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo4.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo5.setSurveyId("myntra555");
		surveyTopicsInfo5.setSurveyName("Myntra survey");
		surveyTopicsInfo5.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo5.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo5.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo6.setSurveyId("mirraw555");
		surveyTopicsInfo6.setSurveyName("mirraw survey");
		surveyTopicsInfo6.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo6.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo6.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo7.setSurveyId("ajio555");
		surveyTopicsInfo7.setSurveyName("Ajio survey");
		surveyTopicsInfo7.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo7.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo7.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsInfo8.setSurveyId("abof555");
		surveyTopicsInfo8.setSurveyName("Abof survey");
		surveyTopicsInfo8.setDescription("the survey wants to know about the Website review");
		surveyTopicsInfo8.setFromDate(LocalDate.of(2020, 05, 06));
		surveyTopicsInfo8.setToDate(LocalDate.of(2020, 06, 03));

		surveyTopicsList.add(surveyTopicsInfo1);
		surveyTopicsList.add(surveyTopicsInfo2);
		surveyTopicsList.add(surveyTopicsInfo3);
		surveyTopicsList.add(surveyTopicsInfo4);
		surveyTopicsList.add(surveyTopicsInfo5);
		surveyTopicsList.add(surveyTopicsInfo6);
		surveyTopicsList.add(surveyTopicsInfo7);
		surveyTopicsList.add(surveyTopicsInfo8);

		return surveyTopicsList;

	}

}
