package com.capgemini.surveymanagementsystem.bean;

import java.io.Serializable;

public class SurveyReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8835637142036778954L;

	public SurveyReport() {
	}

	private int option1;
	private int option2;
	private int option3;
	private int option4;
	private int questionNumber;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String question;
	private String surveyId;

	/**
	 * this method is used to get question
	 * 
	 * @return String
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * this method is used to set question
	 * 
	 * @param question
	 */
	public void setQuestion(String question) {
		this.question = question;
	}

	/**
	 * this method is used to get surveyId
	 * 
	 * @return String
	 */
	public String getSurveyId() {
		return surveyId;
	}

	/**
	 * this method is used to set surveyId
	 * 
	 * @param surveyId
	 */
	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}

	/**
	 * this method is used to get option1
	 * 
	 * @return integer
	 */
	public int getOption1() {
		return option1;
	}

	/**
	 * this method is used to set opt1
	 * 
	 * @param option1
	 */
	public void setOption1(int option1) {
		this.option1 = option1;
	}

	/**
	 * this method is used to get opt2
	 * 
	 * @return integer
	 */
	public int getOption2() {
		return option2;
	}

	/**
	 * this method is used to set opt2
	 * 
	 * @param option2
	 */
	public void setOption2(int option2) {
		this.option2 = option2;
	}

	/**
	 * this method is used to get opt3
	 * 
	 * @return integer
	 */
	public int getOption3() {
		return option3;
	}

	/**
	 * this method is used to set opt3
	 * 
	 * @param option3
	 */
	public void setOption3(int option3) {
		this.option3 = option3;
	}

	/**
	 * this method is used to get opt4
	 * 
	 * @return integer
	 */
	public int getOption4() {
		return option4;
	}

	/**
	 * this method is used to set opt4
	 * 
	 * @param option4
	 */
	public void setOption4(int option4) {
		this.option4 = option4;
	}

	/**
	 * this method is used to get questionNo
	 * 
	 * @return String
	 */
	public int getQuestionNumber() {
		return questionNumber;
	}

	/**
	 * this method is used to set questionNo
	 * 
	 * @param questionNumber
	 */
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}

	/**
	 * this method is used to get opt1name
	 * 
	 * @return String
	 */
	public String getOptionA() {
		return optionA;
	}

	/**
	 * this method is used to set opt1name
	 * 
	 * @param optionA
	 */
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	/**
	 * this method is used to get opt2name
	 * 
	 * @return String
	 */
	public String getOptionB() {
		return optionB;
	}

	/**
	 * this method is used to set opt2name
	 * 
	 * @param optionB
	 */
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	/**
	 * this method is used to get opt3name
	 * 
	 * @return
	 */
	public String getOptionC() {
		return optionC;
	}

	/**
	 * this method is used to set opt3name
	 * 
	 * @param optionC
	 */
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	/**
	 * this method is used to get opt4name
	 * 
	 * @return
	 */
	public String getOptionD() {
		return optionD;
	}

	/**
	 * this method is used to set opt4name
	 * 
	 * @param optionD
	 */
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	@Override
	public String toString() {
		return "\n" + " -----------------Final Results------------------" + "\n #.surveyId = " + surveyId + "\n"
				+ questionNumber + "." + question + "\n" + optionA + " = " + option1 * 10 + "%" + "\n" + optionB + "= "
				+ option2 * 10 + "%" + "\n" + optionC + "= " + option3 * 10 + "%" + "\n" + optionD + " = "
				+ option4 * 10 + "%" + "\n" + "-----------------------------------------------";
	}

}
