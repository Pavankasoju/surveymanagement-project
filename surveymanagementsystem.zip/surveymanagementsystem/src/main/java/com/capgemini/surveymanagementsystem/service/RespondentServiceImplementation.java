package com.capgemini.surveymanagementsystem.service;

import java.util.List;

import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.dao.Dao;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this is the implementation class of RespondentService it contains all method
 * implementations
 * this class is used to get the information from respective controllers and send information to Dao
 * 
 * @author Pavan Kumar
 *
 */
public class RespondentServiceImplementation implements RespondentService {

	Dao dao = Factory.daoInstance();

	/**
	 * this method is used to login respondent module

	 * @param loginId
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean requestLogin(String loginId, String password) {
		return dao.respondentLogin(loginId, password);
	}

	/**
	 * this method is used to verifies the responded password 
	 * @param loginId
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean requestForgotPassword(String loginId, String gmail) {
		return dao.respondentForgotPassword(loginId, gmail);
	}

	/**
	 * this method is used to set new password for respondent
	 * @param loginId
	 * @param gmail
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean requestSetPassword(String loginId, String gmail, String password) {
		return dao.respondentSetPassword(loginId, gmail, password);
	}

	/**
	 * this method is used to get respondent eligible surveyId1
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public SurveyTopics requestRespondentEligibleSurveys1(String loginId) {
		return dao.respondentEligibleSurveys1(loginId);
	}

	/**
	 * this method is used to get respondent eligible surveyId1
	 * @paramloginId
	 * @return true or false
	 */
	@Override
	public SurveyTopics requestRespondentEligibleSurveys2(String loginId) {
		return dao.respondentEligibleSurveys2(loginId);
	}

	/**
	 * this method is used to get result of survey responded respondents
	 * @paramloginId
	 * @return true or false
	 */
	@Override
	public List<SurveyTopics> requestResponsedSurveys(String loginId) {
		return dao.respondentResponsedSurveys(loginId);
	}

	/**
	 * this method is used to check whether the respondent gave response to the specific survey
	 * @param loginId
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean requestResponseVerification(String loginId, String surveyId) {
		return dao.responseVerification(loginId, surveyId);
	}

	/**
	 * this method is used to access Survey test
	 * @param loginId
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean requestTest(String loginId, String surveyId) {
		return dao.respondentTest(loginId, surveyId);
	}

	
	/**
	 * this method is used to verify respondent loginId
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public boolean requestVerifyLoginId(String loginId) {
		return dao.respondentVerifyLoginId(loginId);
	}

	/**
	 * this method is used to verify respondent gMail
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean requestVerifyGmail(String gmail) {
		return dao.respondentVerifyGmail(gmail);
	}

	/**
	 * this method is used to verify respondent phone number
	 * @param phoneNumber
	 * @return true or false
	 */
	@Override
	public boolean requestVerifyContact(long phoneNumber) {
		return dao.respondentVerifyContact(phoneNumber);
	}

	/**
	 * this method is used to update details of respondent
	 * @param oldLoginId
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true or false
	 *
	 */
	@Override
	public boolean requestUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) {
		return dao.respondentUpdate(oldLoginId, name, phoneNumber, gmail, loginId, password);
	}

	/**
	 * this method is used to check the respondents who are eligible for specific survey
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public List<Respondent> requestSurveyEligible(String surveyId) {

		return dao.respondentSurveyEligible(surveyId);
	}

	/**
	 * this method is used to update eligible surveys for specific respondents
	 * @ loginId
	 * @ surveyId1
	 * @ surveyId2
	 * @return true or false
	 */
	@Override
	public boolean requestUpdateSurveyEligible(String loginId, String surveyId1, String surveyId2) {

		return dao.respondentUpdateSurveyEligible(loginId, surveyId1, surveyId2);
	}

	/**
	 * this method is used to register the respondent
	 * @param surveyId
	 * @param title
	 * @param description
	 * @param fromDate
	 * @param toDate
	 * @return true or false
	 */
	@Override
	public boolean requestRegestration(String name, String gmail, Long phoneNumber, String loginId, String password,
			String surveyId1, String surveyId2) {
		Respondent respondentInfo = Factory.respondentInfoInstance();
		respondentInfo.setName(name);
		respondentInfo.setMail(gmail);
		respondentInfo.setPhoneNumber(phoneNumber);
		respondentInfo.setLoginId(loginId);
		respondentInfo.setPassword(password);
		respondentInfo.setSurveyId1(surveyId1);
		respondentInfo.setSurveyId2(surveyId2);
		
		return dao.respondentRegestration(respondentInfo);
	}

	/**
	 * this method is used to get respondent List
	 * @return List
	 */
	@Override
	public List<Respondent> requestGetRespondentList() {

		return dao.getRespondentList();
	}

	@Override
	public boolean requestDelete(String loginId) {
		return dao.respondentDelete(loginId);
	}


}
