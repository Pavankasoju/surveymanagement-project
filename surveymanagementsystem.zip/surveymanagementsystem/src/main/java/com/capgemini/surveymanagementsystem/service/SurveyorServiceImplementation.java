package com.capgemini.surveymanagementsystem.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.SurveyReport;
import com.capgemini.surveymanagementsystem.bean.SurveyResult;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;
import com.capgemini.surveymanagementsystem.bean.Surveyor;
import com.capgemini.surveymanagementsystem.dao.Dao;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this is the implementation class of SurveyorService it contains all method
 * implementations
 * this class is used to get the information from respective controllers and send information to Dao
 * 
 * @author Pavan Kumar
 *
 */
public class SurveyorServiceImplementation implements SurveyorService {

	Dao dao = Factory.daoInstance();

	/**
	 * this method is used to login surveyor
	 * @param loginId
	 * @param passwors
	 * @return true or false
	 */
	@Override
	public boolean requestLogin(String loginId, String password) {

		return dao.surveyorLogin(loginId, password);
	}

	/**
	 * this method is used to verifies the surveyor password 
	 * @param loginId
	 * @param gmail
	 * @return true or false
	 */
	@Override
	public boolean requestForgotPassword(String loginId, String gmail) {

		return dao.surveyorForgotPassword(loginId, gmail);
	}

	/**
	 * this method is used to set new password for surveyor
	 * @param loginId
	 * @param gmail
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean requestSetPassword(String loginId, String gmail, String password) {
		return dao.surveyorSetPassword(loginId, gmail, password);
	}


	/**
	 * this method is used to verify surveyor loginId
	 * @param loginId
	 * @return true or false
	 */
	@Override
	public boolean requestVerifyLoginId(String loginId) {

		return dao.surveyorVerifyLoginId(loginId);
	}

	/**
	 * this method is used to update details of surveyor
	 * @param oldLoginId
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true or false
	 *
	 */
	@Override
	public boolean requestUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) {

		return dao.surveyorUpdate(oldLoginId, name, phoneNumber, gmail, loginId, password);
	}

	/**
	 * this method is used to register the surveyor
	 * @param name
	 * @paramphNumber
	 * @param gmail
	 * @param loginId
	 * @param password
	 * @return true
	 */
	@Override
	public boolean requestRegestration(String name, String gmail, Long phoneNumber, String loginId, String password) {
		Surveyor surveyorInfo = Factory.surveyorInfoInstance();
		surveyorInfo.setLoginId(loginId);
		surveyorInfo.setMail(gmail);
		surveyorInfo.setName(name);
		surveyorInfo.setPassword(password);
		surveyorInfo.setPhoneNumber(phoneNumber);
		return dao.surveyorRegestration(surveyorInfo);
	}

	/**
	 * this method is used to get Surveyor List
	 * @return List
	 */
	@Override
	public List<Surveyor> requestGetSurveyorList() {
		return dao.getSurveyorList();
	}
	
	@Override
	public boolean requestDelete(String loginId) {
		return dao.surveyorDelete(loginId);
	}


	// surveys
	
	/**
	 * this method is used to verify surveyId
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean requestVerifySurvey(String surveyId) {

		return dao.verifySurvey(surveyId);
	}

	/**
	 * this method is used to create distribution survey
	 * @param surveyId
	 * @param title
	 * @param description
	 * @param fromDate
	 * @param toDate
	 * @return true
	 */
	@Override
	public boolean requestAddSurvey(String surveyId, String title, String description, LocalDate fromDate,
			LocalDate toDate) {

		SurveyDistribution surveyDistributionInfo = Factory.surveyDistributionInfoInstance();
		surveyDistributionInfo.setSurveyName(title);
		surveyDistributionInfo.setDescription(description);
		surveyDistributionInfo.setSurveyId(surveyId);
		surveyDistributionInfo.setFromDate(fromDate);
		surveyDistributionInfo.setToDate(toDate);
		return dao.addSurvey(surveyDistributionInfo);
	}

	/**
	 * this method is used to verify survey to access update operation
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean requestSurveyUpdateVerify(String surveyId) {

		return dao.surveyUpdateVerify(surveyId);
	}

	/**
	 * this method is used to update survey
	 * @param surveyId
	 * @param title
	 * @param description
	 * @param fromDate
	 * @param toDate
	 * @return true or false
	 */
	@Override
	public boolean requestSurveyUpdate(String surveyId, String title, String description, LocalDate fromDate,
			LocalDate toDate) {

		return dao.surveyUpdate(surveyId, title, description, fromDate, toDate);
	}

	/**
	 * this method is used to delete an specific survey
	 * @param surveyId
	 * @return true or false
	 * 
	 */
	@Override
	public boolean deleteSurvey(String surveyId) {

		return dao.deleteSurvey(surveyId);
	}

	/**
	 * this method is used to get surveyTopicsList
	 * @return surveyTopicsList
	 */
	@Override
	public List<SurveyTopics> requestGetAllSurveys() {
		return dao.getAllSurveys();
	}

	// distribution surveys

	/**
	 * this method is used to get surveyDistributionList
	 * @return surveyDistributionList
	 */
	@Override
	public List<SurveyDistribution> requestGetDistributionSurveys() {
		return dao.getDistributionSurveys();
	}

	/**
	 * this method is used to distribute the survey and delete the survey
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean requestDistributeSurveys(String surveyId) {
		return dao.distributeSurveys(surveyId);
	}

	// Questions
	
	/**
	 * this method is used to access surveyTest
	 * @param surveyId
	 * @param respondentId
	 * @return testQuestionsList
	 */
	@Override
	public List<Questions> questionsTest(String surveyId, String respondentId) {
		return dao.questionsTest(surveyId, respondentId);
	}

	/**
	 * this method is used to create questions for surveys
	 * @param Object
	 * @return true
	 */
	@Override
	public boolean createQuestions(String surveyId, int questionNumber, String question, String option1, String option2,
			String option3, String option4) {
		Questions questionsInfo = Factory.questionsInfoInstance();
		questionsInfo.setOptionA(option1);
		questionsInfo.setOptionB(option2);
		questionsInfo.setOptionC(option3);
		questionsInfo.setOptionD(option4);
		questionsInfo.setQuestion(question);
		questionsInfo.setQuestionNumber(questionNumber);
		questionsInfo.setSurveyId(surveyId);
		return dao.createQuestions(questionsInfo);
	}

	/**
	 * this method is used to update questions
	 * @param surveyId
	 * @param questionNumber
	 * @param question
	 * @param option1
	 * @param option2
	 * @param option3
	 * @param option4
	 * @return true or false
	 */
	@Override
	public boolean updateQuestions(String surveyId, int questionNumber, String question, String option1, String option2,
			String option3, String option4) {

		return dao.updateQuestions(surveyId, questionNumber, question, option1, option2, option3, option4);
	}

	/**
	 * this method is used to delete the questions
	 * @param surveyId
	 * @return true or false
	 */
	@Override
	public boolean requestDeleteQuestions(String surveyId) {

		return dao.deleteQuestions(surveyId);
	}

	/**
	 * this method is used to generate survey results
	 * @return true
	 */
	
	@Override
	public boolean getResult(int questionNumber, String surveyId, String question, String optionA, String optionB, String optionC, String optionD,
			String respondentId, int option1, int option2, int option3, int option4) {

		return dao.getResult(questionNumber, surveyId, question, optionA, optionB, optionC, optionD, respondentId, option1, option2, option3, option4);
	}

	/**
	 * this method is used to generate report of specific respondent
	 * @param surveyId
	 * @return List
	 */
	@Override
	public List<SurveyReport> report(String surveyId) {

		return dao.report(surveyId);
	}

	///// results
	
	/**
	 * this method is used to generate result of specific respondent
	 * @param respondentId
	 * @return List
	 */
	@Override
	public List<SurveyResult> result(String respondentId) {

		return dao.result(respondentId);
	}

	/**
	 * this method is used to retrieve survey responded respondents of specific survey
	 * @return List  
	 */
	@Override
	public ArrayList<String> requestSurveyRespondedRespondents(String surveyId) {

		return dao.surveyRespondedRespondents(surveyId);
	}

	@Override
	public boolean notification(String notification) {
		return dao.surveyorNotification(notification);
	}

	@Override
	public ArrayList<String> requestNewNotification() {
		return dao.getSurveyorNewNotifications();
	}

	@Override
	public ArrayList<String> requestOldNotification() {
	return dao.getSurveyorOldNotifications();
	}

	@Override
	public boolean requestDeleteNotifications() {
		return dao.deleteSurveyorNotifications();
	}

}