package com.capgemini.surveymanagementsystem.service;

import java.util.List;

import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyTopics;

/**
 * this is an interface for RespondentServiceImpl class, it contains multiple abstract methods
 * @author Admin
 *
 */
public interface RespondentService {

	public boolean requestLogin(String loginId, String password);

	public boolean requestForgotPassword(String loginId, String gmail);

	public boolean requestSetPassword(String loginId, String gmail, String password);

	public SurveyTopics requestRespondentEligibleSurveys1(String loginId);

	public SurveyTopics requestRespondentEligibleSurveys2(String loginId);

	public List<SurveyTopics> requestResponsedSurveys(String loginId);

	public boolean requestResponseVerification(String loginId, String surveyId);

	public boolean requestTest(String loginId, String surveyId);

	public boolean requestVerifyLoginId(String loginId);

	public boolean requestVerifyGmail(String gmail);

	public boolean requestVerifyContact(long phoneNumber);

	public boolean requestUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password);

	public List<Respondent> requestSurveyEligible(String surveyId);

	public boolean requestUpdateSurveyEligible(String loginId, String surveyId1, String surveyId2);

	public boolean requestRegestration(String name, String gmail, Long phoneNumber, String loginId, String password,
			String surveyId1, String surveyId2);

	public List<Respondent> requestGetRespondentList();
	
	public boolean requestDelete(String loginId);
	
	

	//

}
