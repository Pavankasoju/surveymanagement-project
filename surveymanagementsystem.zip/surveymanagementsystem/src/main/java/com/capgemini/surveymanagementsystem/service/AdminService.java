package com.capgemini.surveymanagementsystem.service;

import java.io.IOException;
import java.util.ArrayList;

/**
 * this is an interface for AdminServiceImpl class, it contains abstract methods
 * @author Admin
 *
 */
public interface AdminService {

	public boolean requestLogin(String loginId, String password) throws IOException;

	public boolean requestForgotPassword(String loginId, String gmail);

	public boolean requestSetPassword(String loginId, String gmail, String password) throws IOException;

	public boolean adminVerifyLoginId(String loginId);

	public boolean requestUpdate(String oldLoginId, String name, Long phoneNumber, String gmail, String loginId,
			String password) throws IOException;
	
	public boolean notification(String notificaton);
	
	public ArrayList<String> requestNewNotification();
	
	public ArrayList<String> requestOldNotification();
	
	public boolean requestDeleteNotifications();
	

}
