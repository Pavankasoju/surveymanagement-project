package com.capgemini.surveymanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.factory.Factory;

/**
 * this class contains dummy data of Questions
 * 
 * @author Admin
 *
 */
public class QuestionsRepository {

	protected static List<Questions> questionsList = new ArrayList<Questions>();

	public List<Questions> getQuestionsList() {

		Questions questionsInfo1 = Factory.questionsInfoInstance();
		Questions questionsInfo2 = Factory.questionsInfoInstance();
		Questions questionsInfo3 = Factory.questionsInfoInstance();
		Questions questionsInfo4 = Factory.questionsInfoInstance();
		Questions questionsInfo5 = Factory.questionsInfoInstance();
		Questions questionsInfo6 = Factory.questionsInfoInstance();
		Questions questionsInfo7 = Factory.questionsInfoInstance();
		Questions questionsInfo8 = Factory.questionsInfoInstance();
		Questions questionsInfo9 = Factory.questionsInfoInstance();
		Questions questionsInfo10 = Factory.questionsInfoInstance();
		Questions questionsInfo11 = Factory.questionsInfoInstance();
		Questions questionsInfo12 = Factory.questionsInfoInstance();
		Questions questionsInfo13 = Factory.questionsInfoInstance();
		Questions questionsInfo14 = Factory.questionsInfoInstance();
		Questions questionsInfo15 = Factory.questionsInfoInstance();
		Questions questionsInfo16 = Factory.questionsInfoInstance();
		Questions questionsInfo17 = Factory.questionsInfoInstance();
		Questions questionsInfo18 = Factory.questionsInfoInstance();
		Questions questionsInfo19 = Factory.questionsInfoInstance();
		Questions questionsInfo20 = Factory.questionsInfoInstance();
		Questions questionsInfo21 = Factory.questionsInfoInstance();
		Questions questionsInfo22 = Factory.questionsInfoInstance();
		Questions questionsInfo23 = Factory.questionsInfoInstance();
		Questions questionsInfo24 = Factory.questionsInfoInstance();
		Questions questionsInfo25 = Factory.questionsInfoInstance();
		Questions questionsInfo26 = Factory.questionsInfoInstance();
		Questions questionsInfo27 = Factory.questionsInfoInstance();
		Questions questionsInfo28 = Factory.questionsInfoInstance();
		Questions questionsInfo29 = Factory.questionsInfoInstance();
		Questions questionsInfo30 = Factory.questionsInfoInstance();
		Questions questionsInfo31 = Factory.questionsInfoInstance();
		Questions questionsInfo32 = Factory.questionsInfoInstance();
		Questions questionsInfo33 = Factory.questionsInfoInstance();
		Questions questionsInfo34 = Factory.questionsInfoInstance();
		Questions questionsInfo35 = Factory.questionsInfoInstance();
		Questions questionsInfo36 = Factory.questionsInfoInstance();
		Questions questionsInfo37 = Factory.questionsInfoInstance();
		Questions questionsInfo38 = Factory.questionsInfoInstance();
		Questions questionsInfo39 = Factory.questionsInfoInstance();
		Questions questionsInfo40 = Factory.questionsInfoInstance();
		Questions questionsInfo41 = Factory.questionsInfoInstance();
		Questions questionsInfo42 = Factory.questionsInfoInstance();
		Questions questionsInfo43 = Factory.questionsInfoInstance();
		Questions questionsInfo44 = Factory.questionsInfoInstance();
		Questions questionsInfo45 = Factory.questionsInfoInstance();
		Questions questionsInfo46 = Factory.questionsInfoInstance();
		Questions questionsInfo47 = Factory.questionsInfoInstance();
		Questions questionsInfo48 = Factory.questionsInfoInstance();

		questionsInfo1.setSurveyId("flipkart555");
		questionsInfo1.setQuestionNumber(1);
		questionsInfo1.setQuestion("how is flipkart App");
		questionsInfo1.setOptionA("bad");
		questionsInfo1.setOptionB("not bad");
		questionsInfo1.setOptionC("good");
		questionsInfo1.setOptionD("excellent");

		questionsInfo2.setSurveyId("flipkart555");
		questionsInfo2.setQuestionNumber(2);
		questionsInfo2.setQuestion("how is flipkart discounts");
		questionsInfo2.setOptionA("bad");
		questionsInfo2.setOptionB("not bad");
		questionsInfo2.setOptionC("good");
		questionsInfo2.setOptionD("excellent");

		questionsInfo3.setSurveyId("flipkart555");
		questionsInfo3.setQuestionNumber(3);
		questionsInfo3.setQuestion("how is flipkart delivery");
		questionsInfo3.setOptionA("bad");
		questionsInfo3.setOptionB("not bad");
		questionsInfo3.setOptionC("good");
		questionsInfo3.setOptionD("excellent");

		questionsInfo4.setSurveyId("flipkart555");
		questionsInfo4.setQuestionNumber(4);
		questionsInfo4.setQuestion("how is flipkart services");
		questionsInfo4.setOptionA("bad");
		questionsInfo4.setOptionB("not bad");
		questionsInfo4.setOptionC("good");
		questionsInfo4.setOptionD("excellent");

		questionsInfo5.setSurveyId("amazon555");
		questionsInfo5.setQuestionNumber(1);
		questionsInfo5.setQuestion("how is amazon App");
		questionsInfo5.setOptionA("bad");
		questionsInfo5.setOptionB("not bad");
		questionsInfo5.setOptionC("good");
		questionsInfo5.setOptionD("excellent");

		questionsInfo6.setSurveyId("amazon555");
		questionsInfo6.setQuestionNumber(2);
		questionsInfo6.setQuestion("how is amazon discounts");
		questionsInfo6.setOptionA("bad");
		questionsInfo6.setOptionB("not bad");
		questionsInfo6.setOptionC("good");
		questionsInfo6.setOptionD("excellent");

		questionsInfo7.setSurveyId("amazon555");
		questionsInfo7.setQuestionNumber(3);
		questionsInfo7.setQuestion("how is amazon delivery");
		questionsInfo7.setOptionA("bad");
		questionsInfo7.setOptionB("not bad");
		questionsInfo7.setOptionC("good");
		questionsInfo7.setOptionD("excellent");

		questionsInfo8.setSurveyId("amazon555");
		questionsInfo8.setQuestionNumber(4);
		questionsInfo8.setQuestion("how is amazon services");
		questionsInfo8.setOptionA("bad");
		questionsInfo8.setOptionB("not bad");
		questionsInfo8.setOptionC("good");
		questionsInfo8.setOptionD("excellent");

		questionsInfo9.setSurveyId("myntra555");
		questionsInfo9.setQuestionNumber(1);
		questionsInfo9.setQuestion("how is Myntra App");
		questionsInfo9.setOptionA("bad");
		questionsInfo9.setOptionB("not bad");
		questionsInfo9.setOptionC("good");
		questionsInfo9.setOptionD("excellent");

		questionsInfo10.setSurveyId("myntra555");
		questionsInfo10.setQuestionNumber(2);
		questionsInfo10.setQuestion("how is Myntra discounts");
		questionsInfo10.setOptionA("bad");
		questionsInfo10.setOptionB("not bad");
		questionsInfo10.setOptionC("good");
		questionsInfo10.setOptionD("excellent");

		questionsInfo11.setSurveyId("myntra555");
		questionsInfo11.setQuestionNumber(3);
		questionsInfo11.setQuestion("how is Myntra delivery");
		questionsInfo11.setOptionA("bad");
		questionsInfo11.setOptionB("not bad");
		questionsInfo11.setOptionC("good");
		questionsInfo11.setOptionD("excellent");

		questionsInfo12.setSurveyId("myntra555");
		questionsInfo12.setQuestionNumber(4);
		questionsInfo12.setQuestion("how is Myntra services");
		questionsInfo12.setOptionA("bad");
		questionsInfo12.setOptionB("not bad");
		questionsInfo12.setOptionC("good");
		questionsInfo12.setOptionD("excellent");

		questionsInfo13.setSurveyId("ajio555");
		questionsInfo13.setQuestionNumber(1);
		questionsInfo13.setQuestion("how is Ajio App");
		questionsInfo13.setOptionA("bad");
		questionsInfo13.setOptionB("not bad");
		questionsInfo13.setOptionC("good");
		questionsInfo13.setOptionD("excellent");

		questionsInfo14.setSurveyId("ajio555");
		questionsInfo14.setQuestionNumber(2);
		questionsInfo14.setQuestion("how is Ajio discounts");
		questionsInfo14.setOptionA("bad");
		questionsInfo14.setOptionB("not bad");
		questionsInfo14.setOptionC("good");
		questionsInfo14.setOptionD("excellent");

		questionsInfo15.setSurveyId("ajio555");
		questionsInfo15.setQuestionNumber(3);
		questionsInfo15.setQuestion("how is Ajio delivery");
		questionsInfo15.setOptionA("bad");
		questionsInfo15.setOptionB("not bad");
		questionsInfo15.setOptionC("good");
		questionsInfo15.setOptionD("excellent");

		questionsInfo16.setSurveyId("ajio555");
		questionsInfo16.setQuestionNumber(4);
		questionsInfo16.setQuestion("how is Ajio services");
		questionsInfo16.setOptionA("bad");
		questionsInfo16.setOptionB("not bad");
		questionsInfo16.setOptionC("good");
		questionsInfo16.setOptionD("excellent");

		questionsInfo17.setSurveyId("freekart555");
		questionsInfo17.setQuestionNumber(1);
		questionsInfo17.setQuestion("how is freekart App");
		questionsInfo17.setOptionA("bad");
		questionsInfo17.setOptionB("not bad");
		questionsInfo17.setOptionC("good");
		questionsInfo17.setOptionD("excellent");

		questionsInfo18.setSurveyId("freekart555");
		questionsInfo18.setQuestionNumber(2);
		questionsInfo18.setQuestion("how is freekart discounts");
		questionsInfo18.setOptionA("bad");
		questionsInfo18.setOptionB("not bad");
		questionsInfo18.setOptionC("good");
		questionsInfo18.setOptionD("excellent");

		questionsInfo19.setSurveyId("freekart555");
		questionsInfo19.setQuestionNumber(3);
		questionsInfo19.setQuestion("how is freekart delivery");
		questionsInfo19.setOptionA("bad");
		questionsInfo19.setOptionB("not bad");
		questionsInfo19.setOptionC("good");
		questionsInfo19.setOptionD("excellent");

		questionsInfo20.setSurveyId("freekart555");
		questionsInfo20.setQuestionNumber(4);
		questionsInfo20.setQuestion("how is freekart services");
		questionsInfo20.setOptionA("bad");
		questionsInfo20.setOptionB("not bad");
		questionsInfo20.setOptionC("good");
		questionsInfo20.setOptionD("excellent");

		questionsInfo21.setSurveyId("americanswan555");
		questionsInfo21.setQuestionNumber(1);
		questionsInfo21.setQuestion("how is americanswan App");
		questionsInfo21.setOptionA("bad");
		questionsInfo21.setOptionB("not bad");
		questionsInfo21.setOptionC("good");
		questionsInfo21.setOptionD("excellent");

		questionsInfo22.setSurveyId("americanswan555");
		questionsInfo22.setQuestionNumber(2);
		questionsInfo22.setQuestion("how is americanswan discounts");
		questionsInfo22.setOptionA("bad");
		questionsInfo22.setOptionB("not bad");
		questionsInfo22.setOptionC("good");
		questionsInfo22.setOptionD("excellent");

		questionsInfo23.setSurveyId("americanswan555");
		questionsInfo23.setQuestionNumber(3);
		questionsInfo23.setQuestion("how is americanswan delivery");
		questionsInfo23.setOptionA("bad");
		questionsInfo23.setOptionB("not bad");
		questionsInfo23.setOptionC("good");
		questionsInfo23.setOptionD("excellent");

		questionsInfo24.setSurveyId("americanswan555");
		questionsInfo24.setQuestionNumber(4);
		questionsInfo24.setQuestion("how is americanswan services");
		questionsInfo24.setOptionA("bad");
		questionsInfo24.setOptionB("not bad");
		questionsInfo24.setOptionC("good");
		questionsInfo24.setOptionD("excellent");

		questionsInfo25.setSurveyId("mirraw555");
		questionsInfo25.setQuestionNumber(1);
		questionsInfo25.setQuestion("how is mirraw App");
		questionsInfo25.setOptionA("bad");
		questionsInfo25.setOptionB("not bad");
		questionsInfo25.setOptionC("good");
		questionsInfo25.setOptionD("excellent");

		questionsInfo26.setSurveyId("mirraw555");
		questionsInfo26.setQuestionNumber(2);
		questionsInfo26.setQuestion("how is mirraw discounts");
		questionsInfo26.setOptionA("bad");
		questionsInfo26.setOptionB("not bad");
		questionsInfo26.setOptionC("good");
		questionsInfo26.setOptionD("excellent");

		questionsInfo27.setSurveyId("mirraw555");
		questionsInfo27.setQuestionNumber(3);
		questionsInfo27.setQuestion("how is mirraw delivery");
		questionsInfo27.setOptionA("bad");
		questionsInfo27.setOptionB("not bad");
		questionsInfo27.setOptionC("good");
		questionsInfo27.setOptionD("excellent");

		questionsInfo28.setSurveyId("mirraw555");
		questionsInfo28.setQuestionNumber(4);
		questionsInfo28.setQuestion("how is mirraw services");
		questionsInfo28.setOptionA("bad");
		questionsInfo28.setOptionB("not bad");
		questionsInfo28.setOptionC("good");
		questionsInfo28.setOptionD("excellent");

		questionsInfo29.setSurveyId("abof555");
		questionsInfo29.setQuestionNumber(1);
		questionsInfo29.setQuestion("how is abof App");
		questionsInfo29.setOptionA("bad");
		questionsInfo29.setOptionB("not bad");
		questionsInfo29.setOptionC("good");
		questionsInfo29.setOptionD("excellent");

		questionsInfo30.setSurveyId("abof555");
		questionsInfo30.setQuestionNumber(2);
		questionsInfo30.setQuestion("how is abof discounts");
		questionsInfo30.setOptionA("bad");
		questionsInfo30.setOptionB("not bad");
		questionsInfo30.setOptionC("good");
		questionsInfo30.setOptionD("excellent");

		questionsInfo31.setSurveyId("abof555");
		questionsInfo31.setQuestionNumber(3);
		questionsInfo31.setQuestion("how is abof delivery");
		questionsInfo31.setOptionA("bad");
		questionsInfo31.setOptionB("not bad");
		questionsInfo31.setOptionC("good");
		questionsInfo31.setOptionD("excellent");

		questionsInfo32.setSurveyId("abof555");
		questionsInfo32.setQuestionNumber(4);
		questionsInfo32.setQuestion("how is abof services");
		questionsInfo32.setOptionA("bad");
		questionsInfo32.setOptionB("not bad");
		questionsInfo32.setOptionC("good");
		questionsInfo32.setOptionD("excellent");

		questionsInfo33.setSurveyId("snapdeal555");
		questionsInfo33.setQuestionNumber(1);
		questionsInfo33.setQuestion("how is snapdeal App");
		questionsInfo33.setOptionA("bad");
		questionsInfo33.setOptionB("not bad");
		questionsInfo33.setOptionC("good");
		questionsInfo33.setOptionD("excellent");

		questionsInfo34.setSurveyId("snapdeal555");
		questionsInfo34.setQuestionNumber(2);
		questionsInfo34.setQuestion("how is snapdeal discounts");
		questionsInfo34.setOptionA("bad");
		questionsInfo34.setOptionB("not bad");
		questionsInfo34.setOptionC("good");
		questionsInfo34.setOptionD("excellent");

		questionsInfo35.setSurveyId("snapdeal555");
		questionsInfo35.setQuestionNumber(3);
		questionsInfo35.setQuestion("how is snapdeal delivery");
		questionsInfo35.setOptionA("bad");
		questionsInfo35.setOptionB("not bad");
		questionsInfo35.setOptionC("good");
		questionsInfo35.setOptionD("excellent");

		questionsInfo36.setSurveyId("snapdeal555");
		questionsInfo36.setQuestionNumber(4);
		questionsInfo36.setQuestion("how is snapdeal services");
		questionsInfo36.setOptionA("bad");
		questionsInfo36.setOptionB("not bad");
		questionsInfo36.setOptionC("good");
		questionsInfo36.setOptionD("excellent");

		questionsInfo37.setSurveyId("pepperfry555");
		questionsInfo37.setQuestionNumber(1);
		questionsInfo37.setQuestion("how is pepperfry App");
		questionsInfo37.setOptionA("bad");
		questionsInfo37.setOptionB("not bad");
		questionsInfo37.setOptionC("good");
		questionsInfo37.setOptionD("excellent");

		questionsInfo38.setSurveyId("pepperfry555");
		questionsInfo38.setQuestionNumber(2);
		questionsInfo38.setQuestion("how is pepperfry discounts");
		questionsInfo38.setOptionA("bad");
		questionsInfo38.setOptionB("not bad");
		questionsInfo38.setOptionC("good");
		questionsInfo38.setOptionD("excellent");

		questionsInfo39.setSurveyId("pepperfry555");
		questionsInfo39.setQuestionNumber(3);
		questionsInfo39.setQuestion("how is pepperfry delivery");
		questionsInfo39.setOptionA("bad");
		questionsInfo39.setOptionB("not bad");
		questionsInfo39.setOptionC("good");
		questionsInfo39.setOptionD("excellent");

		questionsInfo40.setSurveyId("pepperfry555");
		questionsInfo40.setQuestionNumber(4);
		questionsInfo40.setQuestion("how is pepperfry services");
		questionsInfo40.setOptionA("bad");
		questionsInfo40.setOptionB("not bad");
		questionsInfo40.setOptionC("good");
		questionsInfo40.setOptionD("excellent");

		questionsInfo41.setSurveyId("ebay555");
		questionsInfo41.setQuestionNumber(1);
		questionsInfo41.setQuestion("how is ebay App");
		questionsInfo41.setOptionA("bad");
		questionsInfo41.setOptionB("not bad");
		questionsInfo41.setOptionC("good");
		questionsInfo41.setOptionD("excellent");

		questionsInfo42.setSurveyId("ebay555");
		questionsInfo42.setQuestionNumber(2);
		questionsInfo42.setQuestion("how is ebay discounts");
		questionsInfo42.setOptionA("bad");
		questionsInfo42.setOptionB("not bad");
		questionsInfo42.setOptionC("good");
		questionsInfo42.setOptionD("excellent");

		questionsInfo43.setSurveyId("ebay555");
		questionsInfo43.setQuestionNumber(3);
		questionsInfo43.setQuestion("how is ebay delivery");
		questionsInfo43.setOptionA("bad");
		questionsInfo43.setOptionB("not bad");
		questionsInfo43.setOptionC("good");
		questionsInfo43.setOptionD("excellent");

		questionsInfo44.setSurveyId("ebay555");
		questionsInfo44.setQuestionNumber(4);
		questionsInfo44.setQuestion("how is ebay services");
		questionsInfo44.setOptionA("bad");
		questionsInfo44.setOptionB("not bad");
		questionsInfo44.setOptionC("good");
		questionsInfo44.setOptionD("excellent");

		questionsInfo45.setSurveyId("shopclues555");
		questionsInfo45.setQuestionNumber(1);
		questionsInfo45.setQuestion("how is shopclues App");
		questionsInfo45.setOptionA("bad");
		questionsInfo45.setOptionB("not bad");
		questionsInfo45.setOptionC("good");
		questionsInfo45.setOptionD("excellent");

		questionsInfo46.setSurveyId("shopclues555");
		questionsInfo46.setQuestionNumber(2);
		questionsInfo46.setQuestion("how is shopclues discounts");
		questionsInfo46.setOptionA("bad");
		questionsInfo46.setOptionB("not bad");
		questionsInfo46.setOptionC("good");
		questionsInfo46.setOptionD("excellent");

		questionsInfo47.setSurveyId("shopclues555");
		questionsInfo47.setQuestionNumber(3);
		questionsInfo47.setQuestion("how is shopclues delivery");
		questionsInfo47.setOptionA("bad");
		questionsInfo47.setOptionB("not bad");
		questionsInfo47.setOptionC("good");
		questionsInfo47.setOptionD("excellent");

		questionsInfo48.setSurveyId("shopclues555");
		questionsInfo48.setQuestionNumber(4);
		questionsInfo48.setQuestion("how is shopclues services");
		questionsInfo48.setOptionA("bad");
		questionsInfo48.setOptionB("not bad");
		questionsInfo48.setOptionC("good");
		questionsInfo48.setOptionD("excellent");

		questionsList.add(questionsInfo1);
		questionsList.add(questionsInfo2);
		questionsList.add(questionsInfo3);
		questionsList.add(questionsInfo4);
		questionsList.add(questionsInfo5);
		questionsList.add(questionsInfo6);
		questionsList.add(questionsInfo7);
		questionsList.add(questionsInfo8);
		questionsList.add(questionsInfo9);
		questionsList.add(questionsInfo10);
		questionsList.add(questionsInfo11);
		questionsList.add(questionsInfo12);
		questionsList.add(questionsInfo13);
		questionsList.add(questionsInfo14);
		questionsList.add(questionsInfo15);
		questionsList.add(questionsInfo16);
		questionsList.add(questionsInfo17);
		questionsList.add(questionsInfo18);
		questionsList.add(questionsInfo19);
		questionsList.add(questionsInfo20);
		questionsList.add(questionsInfo21);
		questionsList.add(questionsInfo22);
		questionsList.add(questionsInfo23);
		questionsList.add(questionsInfo24);
		questionsList.add(questionsInfo25);
		questionsList.add(questionsInfo26);
		questionsList.add(questionsInfo27);
		questionsList.add(questionsInfo28);
		questionsList.add(questionsInfo29);
		questionsList.add(questionsInfo30);
		questionsList.add(questionsInfo31);
		questionsList.add(questionsInfo32);
		questionsList.add(questionsInfo33);
		questionsList.add(questionsInfo34);
		questionsList.add(questionsInfo35);
		questionsList.add(questionsInfo36);
		questionsList.add(questionsInfo37);
		questionsList.add(questionsInfo38);
		questionsList.add(questionsInfo39);
		questionsList.add(questionsInfo40);
		questionsList.add(questionsInfo41);
		questionsList.add(questionsInfo42);
		questionsList.add(questionsInfo43);
		questionsList.add(questionsInfo44);
		questionsList.add(questionsInfo45);
		questionsList.add(questionsInfo46);
		questionsList.add(questionsInfo47);
		questionsList.add(questionsInfo48);

		return questionsList;

	}

}
