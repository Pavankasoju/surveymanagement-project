package com.capgemini.surveymanagementsystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.dao.Dao;
import com.capgemini.surveymanagementsystem.factory.Factory;

class DaoImplementationTest {

	Dao dao = Factory.daoInstance();

	@Test
	@DisplayName("testing Invalid surveyor loginId verification")
	void testSurveyorVerifyLoginId2() {
		assertEquals(false, dao.surveyorVerifyLoginId("shiva-reddy"));
	}

	@Test
	@DisplayName("testing valid surveyor set password")
	void testSurveyorSetPassword1() {
		assertEquals(true, dao.surveyorSetPassword("shiva-reddy", "shiva90@gmail.com", "Shiva@123"));
	}

	@Test
	@DisplayName("testing valid forgot password")
	void testSurveyorForgotPassword1() {
		assertEquals(true, dao.surveyorForgotPassword("shiva-reddy", "shiva90@gmail.com"));
	}

	@Test
	@DisplayName("testing valid Surveyor login")
	void testSurveyorLogin1() {
		assertEquals(true, dao.surveyorLogin("shiva-reddy", "Shiva@123"));
	}


	@Test
	@DisplayName("testing valid respondent forgot password")
	void testRespondentForgotPassword1() {
		assertEquals(true, dao.respondentForgotPassword("twelve-twelve", "twelve@gmail.com"));
	}

	@Test
	@DisplayName("testing Invalid respondent forgot password")
	void testRespondentForgotPassword2() {
		assertEquals(false, dao.respondentForgotPassword("twsdf-sdfnty", "twefdvf@.com"));
	}

	
	@Test
	@DisplayName("testing valid respondent gmail verification")
	void testRespondentVerifyGmail1() {
		assertEquals(true, dao.respondentVerifyGmail("gccvb@gmail.com"));
	}

	@Test
	@DisplayName("testing Invalid respondent gmail verification")
	void testRespondentVerifyGmail2() {
		assertEquals(false, dao.respondentVerifyGmail("eight@gmail.com"));
	}

	@Test
	@DisplayName("testing valid respondent update")
	void testRespondentUpdate1() {
		assertEquals(true, dao.respondentUpdate("nine-nine", "hbhb hbhb", 7894567894l, "fhccfch@gchd.com", "scscsdcs",
				"Qweer@123"));
	}

	@Test
	@DisplayName("testing Invalid respondent update")
	void testRespondentUpdate2() {
		assertEquals(false, dao.respondentUpdate("osdsdse", "hfvvb hsvsb", 7894456894l, "fhcdfdfvh@gchd.com",
				"scdfvdcs", "Qwdfr@123"));
	}

	@Test
	@DisplayName("testing Invalid respondent update survey Eligible")
	void testRespondentUpdateSurveyEligible() {
		assertEquals(false, dao.respondentUpdateSurveyEligible("odcccc", "flidfv555", "frdfvvt555"));
	}

	@Test
	@DisplayName("testing valid adminForgotPasswrd")
	void testAdminForgotPassword1() {
		assertEquals(true, dao.adminForgotPassword("vinay-reddy", "vinay20@gmail.com"));
	}

	@Test
	@DisplayName("testing Invalid admin loginId verification")
	void testAdminVerifyLoginId2() {
		assertEquals(false, dao.adminVerifyLoginId("vinay-reddy"));
	}

}
