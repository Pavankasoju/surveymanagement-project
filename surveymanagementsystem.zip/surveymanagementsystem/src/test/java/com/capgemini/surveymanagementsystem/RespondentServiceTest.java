package com.capgemini.surveymanagementsystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.service.RespondentService;

class RespondentServiceTest {

	RespondentService respondentService = Factory.respondentServiceInstance();

	@Test
	@DisplayName("testing valid respondent login")
	void testRespondentLogin1() {
		assertEquals(true, respondentService.requestLogin("twenty-twenty", "Twenty@123"));
	}

	@Test
	@DisplayName("testing Invalid respondent login")
	void testRespondentLogin2() {
		assertEquals(false, respondentService.requestLogin("twedf-ffnty", "Twsffy@123"));
	}

	@Test
	@DisplayName("testing valid respondent forgot password")
	void testRespondentForgotPassword1() {
		assertEquals(true, respondentService.requestForgotPassword("twelve-twelve", "twelve@gmail.com"));
	}

	@Test
	@DisplayName("testing Invalid respondent forgot password")
	void testRespondentForgotPassword2() {
		assertEquals(false, respondentService.requestForgotPassword("twsdf-sdfnty", "twefdvf@.com"));
	}

	@Test
	@DisplayName("testing valid respondent set password")
	void testRespondentSetPassword1() {
		assertEquals(true, respondentService.requestSetPassword("twenty-twenty", "twenty@gmail.com", "Twenty@123"));
	}

	@Test
	@DisplayName("testing Invalid respondent set password")
	void testRespondentSetPassword2() {
		assertEquals(false, respondentService.requestSetPassword("twdsc-dcdcy", "tsdcd@.ailcom", "Twdfv@123"));
	}

	@Test
	@DisplayName("testing valid response verification")
	void testResponseVerification1() {
		assertEquals(true, respondentService.requestResponseVerification("one-one", "flipkart555"));
	}

	@Test
	@DisplayName("testing valid respondentTest")
	void testRespondentTest1() {
		assertEquals(true, respondentService.requestTest("one-one", "flipkart555"));
	}

	@Test
	@DisplayName("testing Invalid respondentTest")
	void testRespondentTest2() {
		assertEquals(false, respondentService.requestTest("onesad", "flipsdc55"));
	}

	

	@Test
	@DisplayName("testing valid respondent loginId verification")
	void testRespondentVerifyLoginId1() {
		assertEquals(true, respondentService.requestVerifyLoginId("onsce-onsde"));
	}

	@Test
	@DisplayName("testing Invalid respondent loginId verification")
	void testRespondentVerifyLoginId2() {
		assertEquals(false, respondentService.requestVerifyLoginId("one-one"));
	}

	@Test
	@DisplayName("testing valid respondent gmail verification")
	void testRespondentVerifyGmail1() {
		assertEquals(true, respondentService.requestVerifyGmail("gccvb@gmail.com"));
	}

	@Test
	@DisplayName("testing Invalid respondent gmail verification")
	void testRespondentVerifyGmail2() {
		assertEquals(false, respondentService.requestVerifyGmail("eight@gmail.com"));
	}

	@Test
	@DisplayName("testing valid respondent survey eligible")
	void testRespondentSurveyEligible1() {
		assertNotNull(respondentService.requestSurveyEligible("flipkart555"));
	}

	@Test
	@DisplayName("testing Invalid respondent survey eligible")
	void testRespondentSurveyEligible2() {
		assertNull(respondentService.requestSurveyEligible("flrt555"));
	}

	@Test
	@DisplayName("testing valid respondent update survey Eligible")
	void testRespondentUpdateSurveyEligible1() {
		assertEquals(true, respondentService.requestUpdateSurveyEligible("one-one", "flipkart555", "freekart555"));
	}

	@Test
	@DisplayName("testing Invalid respondent update survey Eligible")
	void testRespondentUpdateSurveyEligible() {
		assertEquals(false, respondentService.requestUpdateSurveyEligible("odcccc", "flidfv555", "frdfvvt555"));
	}

}
