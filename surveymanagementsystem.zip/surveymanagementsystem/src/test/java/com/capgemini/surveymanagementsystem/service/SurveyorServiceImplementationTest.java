package com.capgemini.surveymanagementsystem.service;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.factory.Factory;

class SurveyorServiceImplementationTest {

	SurveyorService surveyorService = Factory.surveyorServiceInstance();

	@Test
	@DisplayName("testing add survey")
	void testAddSurvey() {
		assertEquals(true, surveyorService.requestAddSurvey("zcddcxz55", "xccxcx cx ", "xcdcsdcds dcdcdscsd",
				LocalDate.of(2020, 06, 06), LocalDate.of(2020, 07, 07)));
	}

	@Test
	@DisplayName("testing valid surveyUpdateVerify")
	void testSurveyUpdateVerify1() {
		assertEquals(true, surveyorService.requestSurveyUpdateVerify("jhvhj555"));
	}

	@Test
	@DisplayName("testing getAllSurveys")
	void testGetAllSurveys() {
		assertNotNull(surveyorService.requestGetAllSurveys());
	}

	@Test
	@DisplayName("testing getDistribution surveys")
	void testGetDistributionSurveys() {
		assertNotNull(surveyorService.requestGetDistributionSurveys());
	}

	@Test
	@DisplayName("testing createQuestions")
	void testCreateQuestions() {
		assertEquals(true, surveyorService.createQuestions("sdcsds44", 1, "sdcdscdssdc", "dc", "dd", "dd", "dd"));
	}

	@Test
	@DisplayName("testing getResult")
	void testGetResult() {
		assertEquals(true, surveyorService.getResult(1, "flipkart555", "sdcdc", "dfvf", "dfv", "ddg", "vvcv", "one-one",
				1, 0, 0, 0));
	}

	@Test
	@DisplayName("testing surveyor registration")
	void testSurveyorRegestration() {
		assertEquals(true, surveyorService.requestRegestration("sdcds sdcds", "dcsd@gmaiil.com", 7897897894l, "dcsdcs",
				"Qdxd@123"));
	}

	@Test
	@DisplayName("testing getSurveyorList")
	void testGetSurveyorList() {
		assertNotNull(surveyorService.requestGetSurveyorList());
	}
}
