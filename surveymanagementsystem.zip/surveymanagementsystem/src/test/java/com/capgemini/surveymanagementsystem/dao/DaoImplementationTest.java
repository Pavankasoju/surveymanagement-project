package com.capgemini.surveymanagementsystem.dao;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import java.time.LocalDate;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.surveymanagementsystem.bean.Questions;
import com.capgemini.surveymanagementsystem.bean.Respondent;
import com.capgemini.surveymanagementsystem.bean.SurveyDistribution;
import com.capgemini.surveymanagementsystem.bean.Surveyor;
import com.capgemini.surveymanagementsystem.factory.Factory;

class DaoImplementationTest {

	Dao dao = Factory.daoInstance();
	Respondent respondentInfo = Factory.respondentInfoInstance();
	SurveyDistribution surveyDistributionInfo = Factory.surveyDistributionInfoInstance();
	Questions questionsInfo = Factory.questionsInfoInstance();
	Surveyor surveyorInfo = Factory.surveyorInfoInstance();

	
	@Test
	@DisplayName("testing valid respondent login")
	void testRespondentLogin1() {
		assertEquals(true, dao.respondentLogin("twenty-twenty", "Twenty@123"));
	}

	@Test
	@DisplayName("testing Invalid respondent login")
	void testRespondentLogin2() {
		assertEquals(false, dao.respondentLogin("twedf-ffnty", "Twsffy@123"));
	}

	@Test
	@DisplayName("testing valid respondent set password")
	void testRespondentSetPassword1() {
		assertEquals(true, dao.respondentSetPassword("twenty-twenty", "twenty@gmail.com", "Twenty@123"));
	}

	@Test
	@DisplayName("testing Invalid respondent set password")
	void testRespondentSetPassword2() {
		assertEquals(false, dao.respondentSetPassword("twdsc-dcdcy", "tsdcd@.ailcom", "Twdfv@123"));
	}

	@Test
	@DisplayName("testing respondent responsed surveys")
	void testRespondentResponsedSurveys() {
		assertNull(dao.respondentResponsedSurveys("sdcdc"));
	}

	@Test
	@DisplayName("testing valid response verification")
	void testResponseVerification1() {
		assertEquals(true, dao.responseVerification("one-one", "flipkart555"));
	}

	@Test
	@DisplayName("testing valid respondentTest")
	void testRespondentTest1() {
		assertEquals(true, dao.respondentTest("one-one", "flipkart555"));
	}

	@Test
	@DisplayName("testing Invalid respondentTest")
	void testRespondentTest2() {
		assertEquals(false, dao.respondentTest("onesad", "flipsdc55"));
	}

	@Test
	@DisplayName("testing valid respondent loginId verification")
	void testRespondentVerifyLoginId1() {
		assertEquals(true, dao.respondentVerifyLoginId("onsce-onsde"));
	}

	@Test
	@DisplayName("testing Invalid respondent loginId verification")
	void testRespondentVerifyLoginId2() {
		assertEquals(false, dao.respondentVerifyLoginId("one-one"));
	}

	@Test
	@DisplayName("testing valid respondent contact validation")
	void testRespondentVerifyContact1() {
		assertEquals(true, dao.respondentVerifyContact(7897897897l));
	}

	@Test
	@DisplayName("testing Invalid respondent contact validation")
	void testRespondentVerifyContact2() {
		assertEquals(false, dao.respondentVerifyContact(9876543208l));
	}

	@Test
	@DisplayName("testing valid respondent survey eligible")
	void testRespondentSurveyEligible1() {
		assertNotNull(dao.respondentSurveyEligible("flipkart555"));
	}

	@Test
	@DisplayName("testing Invalid respondent survey eligible")
	void testRespondentSurveyEligible2() {
		assertNull(dao.respondentSurveyEligible("flrt555"));
	}

	@Test
	@DisplayName("testing valid respondent update survey Eligible")
	void testRespondentUpdateSurveyEligible1() {
		assertEquals(true, dao.respondentUpdateSurveyEligible("one-one", "flipkart555", "freekart555"));
	}

	@Test
	@DisplayName("testing respondent regestration")
	void testRespondentRegestration() {
		assertEquals(true, dao.respondentRegestration(respondentInfo));
	}

	@Test
	@DisplayName("testing getRespondentList")
	void testGetRespondentList() {
		assertNotNull(dao.getRespondentList());
	}

	@Test
	@DisplayName("testing valid surveyTest")
	void testSurveyTest1() {
		assertEquals(true, dao.surveyTest("amazon555", "three-three"));
	}

	@Test
	@DisplayName("testing Invalid surveyTest")
	void testSurveyTest2() {
		assertEquals(false, dao.surveyTest("flit555", "ondfvdfe"));
	}

	@Test
	@DisplayName("testing valid verify Survey")
	void testVerifySurvey1() {
		assertEquals(true, dao.verifySurvey("sffssfv555"));
	}

	@Test
	@DisplayName("testing Invalid verify Survey")
	void testVerifySurvey2() {
		assertEquals(false, dao.verifySurvey("ebay555"));
	}

	@Test
	@DisplayName("testing add survey")
	void testAddSurvey() {
		assertEquals(true, dao.addSurvey(surveyDistributionInfo));
	}

	@Test
	@DisplayName("testing valid surveyUpdateVerify")
	void testSurveyUpdateVerify1() {
		assertEquals(true, dao.surveyUpdateVerify("jhvhj555"));
	}

	@Test
	@DisplayName("testing Invalid surveyUpdateVerify")
	void testSurveyUpdateVerify2() {
		assertEquals(false, dao.surveyUpdateVerify("mirraw555"));
	}

	@Test
	@DisplayName("testing valid surveyUpdate")
	void testSurveyUpdate1() {
		assertEquals(true, dao.surveyUpdate("pepperfry555", "sdcsdcdscddc", "sdcdssdsdcsdsdsdc",
				LocalDate.of(2020, 05, 13), LocalDate.of(2020, 05, 14)));
	}

	@Test
	@DisplayName("testing Invalid surveyUpdate")
	void testSurveyUpdate2() {
		assertEquals(false, dao.surveyUpdate("flipfvfv555", "sdcsdcdscddc", "sdcdssdsdcsdsdsdc",
				LocalDate.of(2020, 05, 13), LocalDate.of(2020, 05, 14)));
	}

	@Test
	@DisplayName("testing valid delete Survey")
	void testDeleteSurvey1() {
		assertEquals(true, dao.deleteSurvey("myntra555"));
	}

	@Test
	@DisplayName("testing Invalid delete Survey")
	void testDeleteSurvey2() {
		assertEquals(false, dao.deleteSurvey("flirt555"));
	}

	@Test
	@DisplayName("testing getAllSurveys")
	void testGetAllSurveys() {
		assertNotNull(dao.getAllSurveys());
	}

	@Test
	@DisplayName("testing getDistribution surveys")
	void testGetDistributionSurveys() {
		assertNotNull(dao.getDistributionSurveys());
	}

	@Test
	@DisplayName("testing valid distributeSurveys")
	void testDistributeSurveys1() {
		assertEquals(true, dao.distributeSurveys("shopclues555"));
	}

	@Test
	@DisplayName("testing Invalid distributeSurveys")
	void testDistributeSurveys2() {
		assertEquals(false, dao.distributeSurveys("ffdvfd555"));
	}

	@Test
	@DisplayName("testing createQuestions")
	void testCreateQuestions() {
		assertEquals(true, dao.createQuestions(questionsInfo));
	}

	@Test
	@DisplayName("testing valid update questions")
	void testUpdateQuestions1() {
		assertEquals(true, dao.updateQuestions("ebay555", 1, "sfsfvfvdffv", "o", "p", "t", "n"));
	}

	@Test
	@DisplayName("testing Invalid update questions")
	void testUpdateQuestions2() {
		assertEquals(false, dao.updateQuestions("flihcvgg55", 1, "sfsfvfvdffv", "o", "p", "t", "n"));
	}

	@Test
	@DisplayName("testing valid delete questions")
	void testDeleteQuestions1() {
		assertEquals(true, dao.deleteQuestions("ajio555"));
	}

	@Test
	@DisplayName("testing valid delete questions")
	void testDeleteQuestions2() {
		assertEquals(false, dao.deleteQuestions("flsdcdd555"));
	}

	@Test
	@DisplayName("testing getResult")
	void testGetResult() {
		assertEquals(true,
				dao.getResult(1, "flipkart555", "sdcdc", "dfvf", "dfv", "ddg", "vvcv", "one-one", 1, 0, 0, 0));
	}

	@Test
	@DisplayName("testing surveyRespondend Respondents")
	void testSurveyRespondedRespondents() {
		assertNull(dao.surveyRespondedRespondents("flipkart555"));
	}

	@Test
	@DisplayName("testing final report")
	void testFinalReport() {
		assertEquals(true, dao.finalReport("flipkart555", "sdcdsdcdccd", "d", "s", "t", "e", 1, 0, 0, 0, 1));
	}

	@Test
	@DisplayName("testing getFinalreport")
	void testGetFinalReport() {
		assertNull(dao.getFinalReport("flipkart555"));
	}

	@Test
	@DisplayName("testing Invalid Surveyor login")
	void testSurveyorLogin2() {
		assertEquals(false, dao.surveyorLogin("shdcdeddy", "Shiva@123"));
	}

	@Test
	@DisplayName("testing Invalid forgot password")
	void testSurveyorForgotPassword2() {
		assertEquals(false, dao.surveyorForgotPassword("shdffvreddy", "shiva90@dfvfdail.com"));
	}

	@Test
	@DisplayName("testing Invalid surveyor set password")
	void testSurveyorSetPassword2() {
		assertEquals(false, dao.surveyorSetPassword("shiva-dy", "shiva90il.com", "Shi@123"));
	}


	@Test
	@DisplayName("testing valid surveyor loginId verification")
	void testSurveyorVerifyLoginId1() {
		assertEquals(true, dao.surveyorVerifyLoginId("sdcsdsd"));
	}

	@Test
	@DisplayName("testing Invalid surveyor update")
	void testSurveyorUpdate2() {
		assertEquals(false,
				dao.surveyorUpdate("shivdcsdcy", "dfff dfvdfv", 7894561237l, "ddfv@sdc.com", "fvvdfv", "Qdda@123"));
	}

	@Test
	@DisplayName("testing surveyor registration")
	void testSurveyorRegestration() {
		assertEquals(true, dao.surveyorRegestration(surveyorInfo));
	}

	@Test
	@DisplayName("testing getSurveyorList")
	void testGetSurveyorList() {
		assertNotNull(dao.getSurveyorList());
	}

	@Test
	@DisplayName("testing valid admin Login")
	void testAdminLogin1() throws IOException {
		assertEquals(true, dao.adminLogin("vinay-reddy", "Vinay@123"));
	}

	@Test
	@DisplayName("testing Invalid admin Login")
	void S() throws IOException {
		assertEquals(false, dao.adminLogin("vdfvfdvfdy", "Vidf@123"));
	}

	@Test
	@DisplayName("testing Invalid adminForgotPasswrd")
	void testAdminForgotPassword2() {
		assertEquals(false, dao.adminForgotPassword("vindfvfdy", "vinfdv20@gmail.com"));
	}

//	@Test
	@DisplayName("testing valid adminSetPassword")
	void testAdminSetPassword1() throws IOException {
		assertEquals(true, dao.adminSetPassword("vinay-reddy", "vinay20@gmail.com", "Vinay@123"));
	}

	@Test
	@DisplayName("testing Invalid adminSetPassword")
	void testAdminSetPassword2() throws IOException {
		assertEquals(false, dao.adminSetPassword("vinxceddy", "vixcy20@gmacl.com", "Vcxay@123"));
	}

	@Test
	@DisplayName("testing valid admin loginId verification")
	void testAdminVerifyLoginId1() {
		assertEquals(true, dao.adminVerifyLoginId("zsdcszxx"));
	}

//	@Test
	@DisplayName("testing valid admin Update")
	void testAdminUpdate() throws IOException {
		assertEquals(true,
				dao.adminUpdate("vinay-reddy", "sdcsc sdcds", 7418529634l, "scsdc@ff.com", "sccsxdc", "Qdvxv@123"));

	}

	@Test
	@DisplayName("testing Invalid admin Update")
	void testAdminUpdate2() throws IOException {
		assertEquals(false,
				dao.adminUpdate("vdfvdfvdy", "sdcsc sdcds", 7418529634l, "scsdc@ff.com", "sccsxdc", "Qdvxv@123"));

	}

}
