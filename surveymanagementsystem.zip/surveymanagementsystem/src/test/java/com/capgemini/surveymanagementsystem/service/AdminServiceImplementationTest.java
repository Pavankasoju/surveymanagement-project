package com.capgemini.surveymanagementsystem.service;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.factory.Factory;

class AdminServiceImplementationTest {

	AdminService adminService = Factory.adminServiceInstance();

	@Test
	@DisplayName("testing valid login request")
	void testRequestLogin1() throws IOException {
		assertEquals(true, adminService.requestLogin("vinay-reddy", "Vinay@123"));
	}

	@Test
	@DisplayName("testing Invalidlogin request")
	void S() throws IOException {
		assertEquals(false, adminService.requestLogin("vinxczeddy", "Vxcy@123"));
	}

	@Test
	@DisplayName("testing valid forgot password request")
	void testRequestForgotPassword2() {
		assertEquals(false, adminService.requestForgotPassword("visvsveddy", "Visdvd@123"));
	}

	@Test
	@DisplayName("testing Invalid setpassword request")
	void testRequestSetPassword2() throws IOException {
		assertEquals(false, adminService.requestSetPassword("vinay-reddy", "vinay@gmail.com", "Vinay@123"));
	}

	@Test
	@DisplayName("testing valid loginId verification")
	void testAdminVerifyLoginId1() {
		assertEquals(true, adminService.adminVerifyLoginId("sdcdccsd"));
	}

	@Test
	@DisplayName("testing Invalid update request")
	void testRequestUpdate2() throws IOException {
		assertEquals(false, adminService.requestUpdate("vindfv-dfvfy", "bjvhb jbvbn", 7894561234l, "sddsd@gmail.com",
				"sdcs-sdcds", "ERxdfx@123"));
	}

}
