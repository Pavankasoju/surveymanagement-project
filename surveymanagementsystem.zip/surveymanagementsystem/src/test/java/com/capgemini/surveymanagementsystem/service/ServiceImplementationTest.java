package com.capgemini.surveymanagementsystem.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.factory.Factory;

class ServiceImplementationTest {

	Service service = Factory.serviceInstance();

	@Test
	@DisplayName("testing valid nameValidation method")
	void testNameValidation1() {
		assertEquals(true, service.validateName("one one"));
	}

	@Test
	@DisplayName("testing Invalid nameValidation method")
	void testNameValidation2() {
		assertEquals(false, service.validateName("onone"));
	}

	@Test
	@DisplayName("testing  valid emailValidation")
	void testEmailValidation1() {
		assertEquals(true, service.validateGmail("one@gmail.com"));
	}

	@Test
	@DisplayName("testing  Invalid emailValidation")
	void testEmailValidation2() {
		assertEquals(false, service.validateGmail("onegmailom"));
	}

	@Test
	@DisplayName("testing  valid contactValidation")
	void testContactValidation1() {
		assertEquals(true, service.validatePhoneNumber("9879879879"));
	}

	@Test
	@DisplayName("testing  valid contactValidation")
	void testContactValidation2() {
		assertEquals(false, service.validatePhoneNumber("9879"));
	}

	@Test
	@DisplayName("testing  valid dateValidation")
	void testDateValidation1() {
		assertEquals(true, service.validateDate("2020-05-06"));
	}

	@Test
	@DisplayName("testing  Invalid dateValidation")
	void testDateValidation2() {
		assertEquals(false, service.validateDate("2024423"));
	}

	@Test
	@DisplayName("testing  valid choiceValidation")
	void testChoiceValidate1() {
		assertEquals(true, service.validateChoice("5"));
	}

	@Test
	@DisplayName("testing  Invalid choiceValidation")
	void testChoiceValidate2() {
		assertEquals(false, service.validateChoice("55"));
	}

	@Test
	@DisplayName("testing  valid passwordValidation")
	void testPasswordValidation1() {
		assertEquals(true, service.validatePassword("Qwerty@123"));
	}

	@Test
	@DisplayName("testing  Invalid passwordValidation")
	void testPasswordValidation2() {
		assertEquals(false, service.validatePassword("sdsddssdc"));
	}

	@Test
	@DisplayName("testing  valid loginIdValidation")
	void testLoginIdValidation1() {
		assertEquals(true, service.validateLoginId("dsfvsf-sfsf"));
	}

	@Test
	@DisplayName("testing  Invalid loginIdValidation")
	void testLoginIdValidation2() {
		assertEquals(false, service.validateLoginId("dhg"));
	}

	@Test
	@DisplayName("testing  valid titleValidation")
	void testSurveyTitleValidation1() {
		assertEquals(true, service.validateTitle("sfcsdfdf dfdf dfdffdcsc"));
	}

	@Test
	@DisplayName("testing  Invalid titleValidation")
	void testSurveyTitleValidation2() {
		assertEquals(false, service.validateTitle("554"));
	}

	@Test
	@DisplayName("testing  valid descriptionValidation")
	void testSurveyDescriptionValidation1() {
		assertEquals(true, service.validateDescription("cjh hsdjh fghfn"));
	}

	@Test
	@DisplayName("testing  Invalid descriptionValidation")
	void testSurveyDescriptionValidation2() {
		assertEquals(false, service.validateDescription("c52dcsf"));
	}

	@Test
	@DisplayName("testing  valid questionValidation")
	void testQuestionValidation1() {
		assertEquals(true, service.validateQuestion("cng vg531jmhm hmhhmvv 5315"));
	}

	@Test
	@DisplayName("testing  Invalid questionValidation")
	void testQuestionValidation2() {
		assertEquals(false, service.validateQuestion("ccc"));
	}

	@Test
	@DisplayName("testing  valid optionValidation")
	void testOptionValidation1() {
		assertEquals(true, service.validateOption("78"));
	}

	@Test
	@DisplayName("testing  Invalid optionValidation")
	void testOptionValidation2() {
		assertEquals(false, service.validateOption(""));
	}

	@Test
	@DisplayName("testing  valid optionValidation")
	void testQuestionNoValidation1() {
		assertEquals(true, service.validateQuestionNumber("2"));
	}

	@Test
	@DisplayName("testing  Invalid optionValidation")
	void testQuestionNoValidation2() {
		assertEquals(false, service.validateQuestionNumber("44"));
	}

}
