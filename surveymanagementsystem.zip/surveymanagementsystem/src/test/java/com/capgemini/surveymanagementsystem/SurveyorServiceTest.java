package com.capgemini.surveymanagementsystem;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.factory.Factory;
import com.capgemini.surveymanagementsystem.service.SurveyorService;

class SurveyorServiceTest {

	SurveyorService surveyorService = Factory.surveyorServiceInstance();

	@Test
	@DisplayName("testing valid verify Survey")
	void testVerifySurvey1() {
		assertEquals(true, surveyorService.requestVerifySurvey("sffssfv555"));
	}

	@Test
	@DisplayName("testing Invalid verify Survey")
	void testVerifySurvey2() {
		assertEquals(false, surveyorService.requestVerifySurvey("ebay555"));
	}

	@Test
	@DisplayName("testing Invalid surveyUpdateVerify")
	void testSurveyUpdateVerify2() {
		assertEquals(false, surveyorService.requestSurveyUpdateVerify("flipkart555"));
	}

	@Test
	@DisplayName("testing valid surveyUpdate")
	void testSurveyUpdate1() {
		assertEquals(true, surveyorService.requestSurveyUpdate("shopclues555", "sdcsdcdscddc", "sdcdssdsdcsdsdsdc",
				LocalDate.of(2020, 05, 13), LocalDate.of(2020, 05, 14)));
	}

	@Test
	@DisplayName("testing Invalid surveyUpdate")
	void testSurveyUpdate2() {
		assertEquals(false, surveyorService.requestSurveyUpdate("flipfvfv555", "sdcsdcdscddc", "sdcdssdsdcsdsdsdc",
				LocalDate.of(2020, 05, 13), LocalDate.of(2020, 05, 14)));
	}

	@Test
	@DisplayName("testing valid delete Survey")
	void testDeleteSurvey1() {
		assertEquals(true, surveyorService.deleteSurvey("americanswan555"));
	}

	@Test
	@DisplayName("testing Invalid delete Survey")
	void testDeleteSurvey2() {
		assertEquals(false, surveyorService.deleteSurvey("flirt555"));
	}

	@Test
	@DisplayName("testing valid distributeSurveys")
	void testDistributeSurveys1() {
		assertEquals(true, surveyorService.requestDistributeSurveys("ebay555"));
	}

	@Test
	@DisplayName("testing Invalid distributeSurveys")
	void testDistributeSurveys2() {
		assertEquals(false, surveyorService.requestDistributeSurveys("ffdvfd555"));
	}

	@Test
	@DisplayName("testing valid update questions")
	void testUpdateQuestions1() {
		assertEquals(true, surveyorService.updateQuestions("ebay555", 1, "sfsfvfvdffv", "o", "p", "t", "n"));
	}

	@Test
	@DisplayName("testing Invalid update questions")
	void testUpdateQuestions2() {
		assertEquals(false, surveyorService.updateQuestions("flihcvgg55", 1, "sfsfvfvdffv", "o", "p", "t", "n"));
	}

	@Test
	@DisplayName("testing valid delete questions")
	void testDeleteQuestions1() {
		assertEquals(true, surveyorService.requestDeleteQuestions("flipkart555"));
	}

	@Test
	@DisplayName("testing valid delete questions")
	void testDeleteQuestions2() {
		assertEquals(false, surveyorService.requestDeleteQuestions("flsdcdd555"));
	}

	@Test
	@DisplayName("testing surveyRespondend Respondents")
	void testSurveyRespondedRespondents() {
		assertNull(surveyorService.requestSurveyRespondedRespondents("flipkart555"));
	}

	@Test
	@DisplayName("testing valid Surveyor login")
	void testSurveyorLogin1() {
		assertEquals(true, surveyorService.requestLogin("shiva-reddy", "Shiva@123"));
	}

	@Test
	@DisplayName("testing Invalid Surveyor login")
	void testSurveyorLogin2() {
		assertEquals(false, surveyorService.requestLogin("shdcdeddy", "Shiva@123"));
	}

	@Test
	@DisplayName("testing valid forgot password")
	void testSurveyorForgotPassword1() {
		assertEquals(true, surveyorService.requestForgotPassword("shiva-reddy", "shiva90@gmail.com"));
	}

	@Test
	@DisplayName("testing Invalid forgot password")
	void testSurveyorForgotPassword2() {
		assertEquals(false, surveyorService.requestForgotPassword("shdffvreddy", "shiva90@dfvfdail.com"));
	}

	@Test
	@DisplayName("testing valid surveyor set password")
	void testSurveyorSetPassword1() {
		assertEquals(true, surveyorService.requestSetPassword("shiva-reddy", "shiva90@gmail.com", "Shiva@123"));
	}

	@Test
	@DisplayName("testing Invalid surveyor set password")
	void testSurveyorSetPassword2() {
		assertEquals(false, surveyorService.requestSetPassword("shiva-dy", "shiva90il.com", "Shi@123"));
	}

	@Test
	@DisplayName("testing valid surveyor loginId verification")
	void testSurveyorVerifyLoginId1() {
		assertEquals(true, surveyorService.requestVerifyLoginId("sdcsdsd"));
	}

	@Test
	@DisplayName("testing Invalid surveyor loginId verification")
	void testSurveyorVerifyLoginId2() {
		assertEquals(false, surveyorService.requestVerifyLoginId("shiva-reddy"));
	}

	@Test
	@DisplayName("testing valid surveyor update")
	void testSurveyorUpdate1() {
		assertEquals(true, surveyorService.requestUpdate("shiva-reddy", "dfff dfvdfv", 7894561237l, "ddfv@sdc.com",
				"fvvdfv", "Qdda@123"));
	}

	@Test
	@DisplayName("testing Invalid surveyor update")
	void testSurveyorUpdate2() {
		assertEquals(false, surveyorService.requestUpdate("shivdcsdcy", "dfff dfvdfv", 7894561237l, "ddfv@sdc.com",
				"fvvdfv", "Qdda@123"));
	}

}
