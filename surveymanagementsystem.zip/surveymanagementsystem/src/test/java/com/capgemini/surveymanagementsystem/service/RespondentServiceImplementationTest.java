package com.capgemini.surveymanagementsystem.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagementsystem.factory.Factory;

class RespondentServiceImplementationTest {

	RespondentService respondentService = Factory.respondentServiceInstance();

	@Test
	@DisplayName("testing respondent responsed surveys")
	void testRespondentResponsedSurveys() {
		assertNull(respondentService.requestResponsedSurveys("sdcdc"));
	}

	@Test
	@DisplayName("testing valid respondent contact validation")
	void testRespondentVerifyContact1() {
		assertEquals(true, respondentService.requestVerifyContact(7897897897l));
	}

	@Test
	@DisplayName("testing Invalid respondent contact validation")
	void testRespondentVerifyContact2() {
		assertEquals(false, respondentService.requestVerifyContact(9876543208l));
	}

	@Test
	@DisplayName("testing respondent regestration")
	void testRespondentRegestration() {
		assertEquals(true, respondentService.requestRegestration("dds sdds", "sdcsd@gmail.com", 7894561237l,
				"fdvfv-dfvfv", "Qgdx@123", "bcbc555", "vnbvnv"));
	}

	@Test
	@DisplayName("testing getRespondentList")
	void testGetRespondentList() {
		assertNotNull(respondentService.requestGetRespondentList());
	}

}
